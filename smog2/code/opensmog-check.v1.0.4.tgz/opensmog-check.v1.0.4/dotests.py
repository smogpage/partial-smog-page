from OpenSMOG import SBM
import simtk.openmm.app as app
import subprocess
import io
import os
import sys
from contextlib import redirect_stdout

# maxreldiff is the max relative deviation allowed
maxreldiff=0.00001
# maxabsdiff is the max absolute deviation allowed
maxabsdiff=0.002


# The name of each test is listed in tests/listoftests
# each line defines a test, which is a subdir of tests/
# each subdirectory has a "flags" file that gives the exact 
# flags used when calling smog2
# energies contains the gromacs-generated (or any reference 
# calculation) energies for the 10 frame..gro files

print(
'''
                      OpenSMOG-check
          For use with OpenSMOG v1.0.4 and SMOG v2.4.1

This script will use the version of SMOG2 that is found in the path
and try to generate OpenSMOG force fields. It will then calculate
the energy using the OpenSMOG force field with any available
version of OpenSMOG that is in the environment for reference 
configurations of each system. Finally, it will check if the 
potential energies are the same as a set of predefined reference 
values (typically from Gromacs).

There are currently no flags required.

For questions/suggestions
email info@smog-server.org
''') 


##### subroutines #####

def alltests():
	# nummatch is the total number of energies that 
	# will need to be close, in order to pass
	# it is incremented as tests are applied
	nummatch=0
	# mcount is the number of matching energies
	mcount=0

	which("smog2")
	print('What platform would you like to test?')
	print("\tOptions: OpenCL, HIP, CUDA, CPU, reference")
	for line in sys.stdin:
		platform = line.rstrip()
		break

	print("Will test platform \""+platform+"\"\n")

	list = open("tests/listoftests", "r")

	for testname in list:
		testname=testname.strip()
		sysname = "tests/"+testname+"/"
		nummatch+=10
		print("STARTING TEST FOR SYSTEM IN "+testname)
		runSMOG(sysname)
		sbm_test = prepOpenSMOG(platform)
		energies = open(sysname+"energies", "r")
		for frame in range(10):
			newgro = app.GromacsGroFile(sysname+"frame."+str(frame)+".gro")
			sbm_test.simulation.context.setPositions(newgro.positions)
			e_pot_frame = sbm_test.simulation.context.getState(getEnergy=True).getPotentialEnergy()
			num=str(e_pot_frame).split(" ",1)[0]
			openv=energies.readline()
			mcount += comparevalues(openv,num)
		print("COMPLETED TEST FOR SYSTEM IN "+testname+"\n")
		subprocess.run('rm opentest*',shell=True)

	print(str(mcount) + " of " + str(nummatch) + " values matched")

	if nummatch == 0:	
		print("\n\nNO TESTS PERFORMED.  SOMETHING WENT WRONG!!!!\n\n")
		sys.exit(1)	
	elif mcount == nummatch:
		print("\n\nPASSED ALL CHECKS!!!!\n\n")
		sys.exit(0)	
	else: 
		print("\n\nFAILED CHECKS!!!!\n\n")
		sys.exit(1)	

def runSMOG(sysname):
	# based on the sysname, find the flags and run SMOG2
	f = open(sysname+"flags", "r")
	flags =f.readline()
	command = ['smog2']
	command.extend(flags.split())
	#todo catch error code.  if smog2 crashes, then exit
	out=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)	

def prepOpenSMOG(platform):
	# make and return a system.  This script always uses the same file names
	f = open(os.devnull, 'w')
	with redirect_stdout(f):
		sbm_test = SBM(name='testss', time_step=0.002, collision_rate=1.0, r_cutoff=1.2, temperature=0.1)
		sbm_test.setup_openmm(platform=platform,GPUindex='default')
		sbm_test.saveFolder('.')
		sbm_test.loadSystem(Grofile='opentest.gro', Topfile='opentest.top', Xmlfile='opentest.xml')
		sbm_test.createSimulation()
	return sbm_test

def comparevalues(ref,open):
	absdiff=abs(float(ref)-float(open))
	reldiff=abs(absdiff/float(ref))
	if absdiff < maxabsdiff or reldiff < maxreldiff:
		return 1
	else:
		print("BAD VALUES:"+ref.rstrip()+" (reference) and "+open+"(openSMOG)")
		return 0 

def which(exe):
	for dir in os.getenv("PATH").split(':'):
		if (os.path.exists(os.path.join(dir, exe))):
			print ('SMOG2 version found:%s/%s\n' % (dir, exe))
			return

	print ("Could not find smog2 in path")
	print("quitting")
	sys.exit(1)	
			
#end of subroutines

# call main program
alltests()
