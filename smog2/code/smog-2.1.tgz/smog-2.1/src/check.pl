#!/usr/bin/perl
 use Test::Vars;
#    vars_ok('templateParser.pm');

    # Check all libs that are listed in the MANIFEST file
   all_vars_ok();
