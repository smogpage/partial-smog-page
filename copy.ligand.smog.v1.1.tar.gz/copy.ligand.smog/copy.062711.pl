#!/opt/local/bin/perl

print "What is the gro file for the system?\n";
$GRO=<STDIN>;
chomp($GRO);
print "\t $GRO will be read\n";
print "What is the top file for the system?\n";
$TOP=<STDIN>;
print "\t $TOP will be read\n";
chomp($TOP);
print "What is the index file that contains the atoms to be duplicated?\n";
$NDX=<STDIN>;
print "\t $NDX will be read\n";
chomp($NDX);
print "How many copies do you want to make?\n";
$CN=<STDIN>;
chomp($CN);
print "\t $CN copies will be made\n";


# how close can the duplicated atoms be from the original system?  1.0=1 nm
$THRESH=1.0;


# get the atom numbers

open(NDX,"$NDX") or die "can\'t find $NDX\n";
$Catoms=0;
while(<NDX>){
	$LINE=$_;
	chomp($LINE);
	# set value to 1 if we want to duplicate it
	$IN[$LINE]=1;
	$IN2[$Catoms]=$LINE-1;
	$Catoms++;
}

# read the gro file
open(GRO,"$GRO") or die "can\'t find $GRO\n";
open(GROOUT,">$GRO.copy_$CN") or die "can\'t open $GRO.copy_$CN\n";

$LINE=<GRO>;
print GROOUT "This gro file used $GRO and copied the atoms in $NDX, $CN times\n";
$AN=<GRO>;
	$AN =~ s/^\s+//;
	$AN =~ s/\s+$//;
print "$AN atoms found in $GRO\n\n";
$ANOLD=$AN;
##$ATOMSHIFT=$ANOLD-$IN2[0]+1;
$AN+=$CN*$Catoms;
print GROOUT "$AN\n";



for($I=0;$I<$ANOLD;$I++){
	$LINE=<GRO>;
	print GROOUT "$LINE";
	chomp($LINE);
	$X[$I]=substr($LINE,20,8);
	$Y[$I]=substr($LINE,28,8);
	$Z[$I]=substr($LINE,36,8);
	$RESN[$I]=substr($LINE,0,5);
	$RESNAME[$I]=substr($LINE,7,3);
	$ATOMNAME[$I]=substr($LINE,11,4);
}


$DIMS=<GRO>;
chomp($DIMS);
$XB=substr($DIMS,0,11);
$YB=substr($DIMS,16,11);
$ZB=substr($DIMS,31,11);

print "Gro and Top files used: $GRO, $TOP\n\n";
print "output files $GRO.copy_$CN $TOP.copy_$CN\n\n";
print "Copying atoms defined in $NDX ($Catoms atoms).  $CN copies will be made, and scattered across the box, of dimensions <$XB,$YB,$ZB>.\n\n";

# make a prototype of the subregion and put it's COM at 0,0,0
$XCM=0;
$YCM=0;
$ZCM=0;
	$Rtemp=$RESN[$IN2[0]];
	$Rlast=$RESN[$ANOLD-1];
for($J=0;$J<$Catoms;$J++){
	$XCM+=$X[$IN2[$J]];
	$YCM+=$Y[$IN2[$J]];
	$ZCM+=$Z[$IN2[$J]];
	$RESN[$IN2[$J]]-=$Rtemp;
}
$XCM=$XCM/$Catoms;
$YCM=$YCM/$Catoms;
$ZCM=$ZCM/$Catoms;

for($J=0;$J<$Catoms;$J++){
	$X[$IN2[$J]]-=$XCM;
	$Y[$IN2[$J]]-=$YCM;
	$Z[$IN2[$J]]-=$ZCM;
}

# now, let's copy the atoms

#for($I=0;$I<$CN;$I++){
$I=0;
$AAold=$ANOLD;
$ANorig=$ANOLD;
while($I<$CN){

	# make a candidate position
	$XC = rand()*$XB;
	$YC = rand()*$YB;
	$ZC = rand()*$ZB;

	$KEEP=0;
	for($J=0;$J<$Catoms;$J++){
		$XCAN[$J]=$X[$IN2[$J]]+$XC;
		##print "$X[$IN2[$J]],$XC\n";
		$YCAN[$J]=$Y[$IN2[$J]]+$YC;
		$ZCAN[$J]=$Z[$IN2[$J]]+$ZC;
		if($XCAN[$J] >= $XB-$THRESH || $YCAN[$J] >= $YB-$THRESH || $ZCAN[$J] >= $ZB-$THRESH || $XCAN[$J] <= $THRESH || $YCAN[$J] <= $THRESH || $ZCAN[$J] <= $THRESH){
			$KEEP=1;
		} 

		for($K=0;$K<$ANOLD;$K++){

			$R2=($XCAN[$J]-$X[$K])**2+($YCAN[$J]-$Y[$K])**2+($ZCAN[$J]-$Z[$K])**2;

			if($R2 <$THRESH){
				$KEEP=1;
			} 

		}

	}


	# if it passed all tests, add it to the system
	if($KEEP == 0){

		$I++;
		#ADD HERE
		$RNEW=$Rlast+$I*($RESN[$IN2[$Catoms-1]]+1);
		#print "$RNEW $RESN[$AAold-1],$I, $RESN[$IN2[$Catoms-1]],$Catoms $IN2[$Catoms-1]\n";

			for($J=0;$J<$Catoms;$J++){
				$RNEW2=$RNEW+$RESN[$IN2[$J]];
				$ANOLD+=1;
				$X[$ANOLD]=$XCAN[$J];
				$Y[$ANOLD]=$YCAN[$J];
				$Z[$ANOLD]=$ZCAN[$J];
				printf GROOUT ("%5i  %3s %-4s%5i%8.3f%8.3f%8.3f\n", $RNEW2,$RESNAME[$IN2[$J]], $ATOMNAME[$IN2[$J]],$ANOLD,$X[$ANOLD],$Y[$ANOLD],$Z[$ANOLD]);
			}
		print "generating coordinates for copy $I...\n";

		##print "$XC $YC $ZC\n";
	}#else{
	#	print "failed $I\n";
	#}
}
print GROOUT "$DIMS\n";


# now do the top file

print "generating energy terms for the copies...\n";

open(TOP,"$TOP") or die "can\'t open $TOP\n";
open(TOPOUT,">$TOP.copy_$CN") or die "can\'t open $TOP\n";

#copy the header
##$LINE=<TOP>;
##$FIELD=substr($LINE,3,5);
until($FIELD eq "atoms"){
	##print TOPOUT $LINE;
	$LINE=<TOP>;
	$FIELD=substr($LINE,3,5);
	print TOPOUT $LINE;

}


# copy the atoms that were copied in the gro file

$I=0;
$GGG=<TOP>;
	$LINE=<TOP>;
	print TOPOUT $LINE;
	$LINE=<TOP>;
until($LINE eq " \n"){
	##print TOPOUT $LINE;
##	$LINE=<TOP>;
##	$FIELD=substr($LINE,3,5);
	print TOPOUT $LINE;
	$LINE=<TOP>;
	
	$INDEX=substr($LINE,0,6);
 	$INDEX =~ s/^\s+//;
        $INDEX =~ s/\s+$//;

	if($IN[$INDEX]==1){
		$LINE2=$LINE;
		chomp($LINE2);
		$STORE[$I]=substr($LINE2,6,55);
		$I++;
	}
}

	

for($I=0;$I<$CN;$I++){
	for($J=0;$J<$Catoms;$J++){
		$AAold++;
		##print "$AAold\n";
		$A=substr($STORE[$J],0,6);
		$B=substr($STORE[$J],6,6)+$I+1;
		$C=substr($STORE[$J],12,11);
		$D=substr($STORE[$J],23,6)+$I+1;
		$E=substr($STORE[$J],29,16);

		printf TOPOUT ("%6i%6s%6i%-11s%6i%12s\n",$AAold,$A,$B,$C,$AAold,$E);
	}
}

print TOPOUT "\n";
$LL=<TOP>;
print TOPOUT "$LL";

# copy the contacts

$II=0;
        $LINE=<TOP>;
until($LINE eq " \n"){
        ##print TOPOUT $LINE;
##      $LINE=<TOP>;
##      $FIELD=substr($LINE,3,5);
        print TOPOUT $LINE;
        $LINE=<TOP>;
##	print $LINE;	
        $INDEX1=substr($LINE,0,6);
        $INDEX1 =~ s/^\s+//;
        $INDEX1 =~ s/\s+$//;
        $INDEX2=substr($LINE,7,6);
        $INDEX2 =~ s/^\s+//;
        $INDEX2 =~ s/\s+$//;
	

        if($IN[$INDEX1]==1 || $IN[$INDEX2]==1){
		$PAIR[$II][0]=$INDEX1;
		$PAIR[$II][1]=$INDEX2;
                $LINE2=$LINE;
                chomp($LINE2);
		$PAIR[$II][2]=substr($LINE2,13,30);
##		print  "$II $PAIR[$II][0]  $PAIR[$II][1]  $PAIR[$II][2]\n";
                $II++;
        }

}

	$COPYPAIRS=$II;
for($I=0;$I<$CN;$I++){
##print "$I $CN\n";
$ATOMSHIFT=$ANorig-$IN2[0]+$I*$Catoms;
        for($J=0;$J<$COPYPAIRS;$J++){

		$A=$PAIR[$J][0];
		if($IN[$A] ==1){
			$A+=$ATOMSHIFT;
		}
		$B=$PAIR[$J][1];
		if($IN[$B] ==1){
			$B+=$ATOMSHIFT;
		}
		$C=$PAIR[$J][2];

		
                printf TOPOUT ("%6i %6i%-30s\n",$A,$B,$C);
        }
}


print TOPOUT "\n";
$LL=<TOP>;
print TOPOUT "$LL";
$LL=<TOP>;
print TOPOUT "$LL";
# copy the bonds

$II=0;
        $LINE=<TOP>;
until($LINE eq " \n"){
        ##print TOPOUT $LINE;
##      $LINE=<TOP>;
##      $FIELD=substr($LINE,3,5);
        print TOPOUT $LINE;
        $LINE=<TOP>;
##	print $LINE;	
        $INDEX1=substr($LINE,0,6);
        $INDEX1 =~ s/^\s+//;
        $INDEX1 =~ s/\s+$//;
        $INDEX2=substr($LINE,7,6);
        $INDEX2 =~ s/^\s+//;
        $INDEX2 =~ s/\s+$//;
	

        if($IN[$INDEX1]==1 || $IN[$INDEX2]==1){
		$PAIR[$II][0]=$INDEX1;
		$PAIR[$II][1]=$INDEX2;
                $LINE2=$LINE;
                chomp($LINE2);
		$PAIR[$II][2]=substr($LINE2,13,30);
##		print  "$II $PAIR[$II][0]  $PAIR[$II][1]  $PAIR[$II][2]\n";
                $II++;
        }

}

	$COPYPAIRS=$II;
for($I=0;$I<$CN;$I++){
$ATOMSHIFT=$ANorig-$IN2[0]+$I*$Catoms;
##print "$I $CN $ATOMSHIFT, $ANOLD, $IN2[0], $Catoms\n";

        for($J=0;$J<$COPYPAIRS;$J++){

		$A=$PAIR[$J][0];
		if($IN[$A] ==1){
			$A+=$ATOMSHIFT;
		}
		$B=$PAIR[$J][1];
		if($IN[$B] ==1){
			$B+=$ATOMSHIFT;
		}
		$C=$PAIR[$J][2];

		
                printf TOPOUT ("%6i %6i%-30s\n",$A,$B,$C);
        }
}


print TOPOUT "\n";

$LL=<TOP>;
print TOPOUT "$LL";
$LL=<TOP>;
print TOPOUT "$LL";

# copy the exclusions

$II=0;
        $LINE=<TOP>;
until($LINE eq " \n"){
        ##print TOPOUT $LINE;
##      $LINE=<TOP>;
##      $FIELD=substr($LINE,3,5);
        print TOPOUT $LINE;
        $LINE=<TOP>;
##	print $LINE;	
        $INDEX1=substr($LINE,0,6);
        $INDEX1 =~ s/^\s+//;
        $INDEX1 =~ s/\s+$//;
        $INDEX2=substr($LINE,7,6);
        $INDEX2 =~ s/^\s+//;
        $INDEX2 =~ s/\s+$//;
	

        if($IN[$INDEX1]==1 || $IN[$INDEX2]==1){
		$PAIR[$II][0]=$INDEX1;
		$PAIR[$II][1]=$INDEX2;
##		print  "$II $PAIR[$II][0]  $PAIR[$II][1]  $PAIR[$II][2]\n";
                $II++;
        }

}

	$COPYPAIRS=$II;
for($I=0;$I<$CN;$I++){
$ATOMSHIFT=$ANorig-$IN2[0]+$I*$Catoms;
##print "$I $CN $ATOMSHIFT, $ANOLD, $IN2[0], $Catoms\n";

        for($J=0;$J<$COPYPAIRS;$J++){

		$A=$PAIR[$J][0];
		if($IN[$A] ==1){
			$A+=$ATOMSHIFT;
		}
		$B=$PAIR[$J][1];
		if($IN[$B] ==1){
			$B+=$ATOMSHIFT;
		}
		
                printf TOPOUT ("%6i %6i\n",$A,$B);
        }
}



print TOPOUT "\n";

$LL=<TOP>;
print TOPOUT "$LL";
$LL=<TOP>;
print TOPOUT "$LL";
# copy the angles

$II=0;
        $LINE=<TOP>;
until($LINE eq " \n"){
        ##print TOPOUT $LINE;
##      $LINE=<TOP>;
##      $FIELD=substr($LINE,3,5);
        print TOPOUT $LINE;
        $LINE=<TOP>;
##	print $LINE;	
        $INDEX1=substr($LINE,0,6);
        $INDEX1 =~ s/^\s+//;
        $INDEX1 =~ s/\s+$//;
        $INDEX2=substr($LINE,7,6);
        $INDEX2 =~ s/^\s+//;
        $INDEX2 =~ s/\s+$//;
        $INDEX3=substr($LINE,14,6);
        $INDEX3 =~ s/^\s+//;
        $INDEX3 =~ s/\s+$//;
	

        if($IN[$INDEX1]==1 || $IN[$INDEX2]==1 ||  $IN[$INDEX3]==1 ){
		$PAIR[$II][0]=$INDEX1;
		$PAIR[$II][1]=$INDEX2;
		$PAIR[$II][2]=$INDEX3;
                $LINE2=$LINE;
                chomp($LINE2);
                $PAIR[$II][3]=substr($LINE2,20,30);
##		print  "$II $PAIR[$II][0]  $PAIR[$II][1]  $PAIR[$II][2]\n";
                $II++;
        }

}

	$COPYPAIRS=$II;
for($I=0;$I<$CN;$I++){
$ATOMSHIFT=$ANorig-$IN2[0]+$I*$Catoms;
##print "$I $CN $ATOMSHIFT, $ANOLD, $IN2[0], $Catoms\n";

        for($J=0;$J<$COPYPAIRS;$J++){

		$A=$PAIR[$J][0];
		if($IN[$A] ==1){
			$A+=$ATOMSHIFT;
		}
		$B=$PAIR[$J][1];
		if($IN[$B] ==1){
			$B+=$ATOMSHIFT;
		}
		$C=$PAIR[$J][2];
		if($IN[$C] ==1){
			$C+=$ATOMSHIFT;
		}
		
                printf TOPOUT ("%6i %6i %6i%-30s\n",$A,$B,$C,$PAIR[$J][3]);
        }
}





print TOPOUT "\n";

$LL=<TOP>;
print TOPOUT "$LL";
$LL=<TOP>;
print TOPOUT "$LL";
# copy the angles

$II=0;
        $LINE=<TOP>;
until($LINE eq " \n"){
        ##print TOPOUT $LINE;
##      $LINE=<TOP>;
##      $FIELD=substr($LINE,3,5);
        print TOPOUT $LINE;
        $LINE=<TOP>;
##	print $LINE;	
        $INDEX1=substr($LINE,0,6);
        $INDEX1 =~ s/^\s+//;
        $INDEX1 =~ s/\s+$//;
        $INDEX2=substr($LINE,7,6);
        $INDEX2 =~ s/^\s+//;
        $INDEX2 =~ s/\s+$//;
        $INDEX3=substr($LINE,14,6);
        $INDEX3 =~ s/^\s+//;
        $INDEX3 =~ s/\s+$//;
        $INDEX4=substr($LINE,21,6);
        $INDEX4 =~ s/^\s+//;
        $INDEX4 =~ s/\s+$//;
	

        if($IN[$INDEX1]==1 || $IN[$INDEX2]==1 ||  $IN[$INDEX3]==1  ||  $IN[$INDEX4]==1){
		$PAIR[$II][0]=$INDEX1;
		$PAIR[$II][1]=$INDEX2;
		$PAIR[$II][2]=$INDEX3;
		$PAIR[$II][3]=$INDEX4;
                $LINE2=$LINE;
                chomp($LINE2);
                $PAIR[$II][4]=substr($LINE2,27,30);
##		print  "$II $PAIR[$II][0]  $PAIR[$II][1]  $PAIR[$II][2]\n";
                $II++;
        }

}

	$COPYPAIRS=$II;
for($I=0;$I<$CN;$I++){
$ATOMSHIFT=$ANorig-$IN2[0]+$I*$Catoms;
##print "$I $CN $ATOMSHIFT, $ANOLD, $IN2[0], $Catoms\n";

        for($J=0;$J<$COPYPAIRS;$J++){

		$A=$PAIR[$J][0];
		if($IN[$A] ==1){
			$A+=$ATOMSHIFT;
		}
		$B=$PAIR[$J][1];
		if($IN[$B] ==1){
			$B+=$ATOMSHIFT;
		}
		$C=$PAIR[$J][2];
		if($IN[$C] ==1){
			$C+=$ATOMSHIFT;
		}
		$D=$PAIR[$J][3];
		if($IN[$D] ==1){
			$D+=$ATOMSHIFT;
		}
		
                printf TOPOUT ("%6i %6i %6i %6i%-30s\n",$A,$B,$C,$D,$PAIR[$J][4]);
        }
}



print TOPOUT "\n";
while(<TOP>){
	$LINE=$_;
	print TOPOUT "$LINE";

}





