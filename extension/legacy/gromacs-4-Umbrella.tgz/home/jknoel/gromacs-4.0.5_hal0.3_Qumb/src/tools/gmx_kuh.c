/*
 * $Id: gmx_bond.c,v 1.3.2.2 2007/09/19 10:54:49 spoel Exp $
 * 
 *                This source code is part of
 * 
 *                 G   R   O   M   A   C   S
 * 
 *          GROningen MAchine for Chemical Simulations
 * 
 *                        VERSION 3.3.2
 * Written by David van der Spoel, Erik Lindahl, Berk Hess, and others.
 * Copyright (c) 1991-2000, University of Groningen, The Netherlands.
 * Copyright (c) 2001-2007, The GROMACS development team,
 * check out http://www.gromacs.org for more information.

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * If you want to redistribute modifications, please consider that
 * scientific software is very special. Version control is crucial -
 * bugs must be traceable. We will be happy to consider code for
 * inclusion in the official distribution, but derived work must not
 * be called official GROMACS. Details are found in the README & COPYING
 * files - if they are missing, get the official version at www.gromacs.org.
 * 
 * To help us fund GROMACS development, we humbly ask that you cite
 * the papers on the package - you can find them in the top README file.
 * 
 * For more info, check our website at http://www.gromacs.org
 * 
 * And Hey:
 * Groningen Machine for Chemical Simulation
 */
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <math.h>
#include <string.h>
#include "sysstuff.h"
#include "typedefs.h"
#include "smalloc.h"
#include "macros.h"
#include "vec.h"
#include "pbc.h"
#include "xvgr.h"
#include "copyrite.h"
#include "gmx_fatal.h"
#include "futil.h"
#include "statutil.h"
#include "index.h"
#include "gstat.h"
#include "confio.h"

// from gmx_rmsdist.c
static void calc_dists(int ncont,atom_id index[],rvec x[],
                       int ePBC,matrix box, real *d)
{
  int     i,ci;
  rvec    dx;
  t_pbc   pbc;

  set_pbc(&pbc,ePBC,box);
  i=0;
  for(ci=0; (ci<ncont); ++ci ) {
    pbc_dx(&pbc,x[index[i]],x[index[i+1]],dx);
    d[ci]=norm(dx);
//    fprintf(stderr,"%6d%8d%8d%14.5f\n",ci+1,index[i]+1,index[i+1]+1,d[ci]);
    i+=2;
  }
}

static void do_contacts(char *fn,char *fqval,char *fqimap,
		        bool bQi, bool bIJ, int gnx,atom_id index[], int ePBC,
		        int ncont, real *natdist,
                        real cutval, bool bAbs, bool bSym )
{
  FILE *qout, *iout = NULL ;
  real t ;
  rvec *x ;
  matrix box ;
  real *aktdist ;
  int status, natoms, nframes,
      ci, nformed ;
  bool formed ;

  qout = ffopen(fqval,"w") ;
  if ( bQi )
    iout = ffopen(fqimap,"w") ;

  snew( aktdist, ncont ) ;  
  natoms=read_first_x(&status,fn,&t,&x,box);
  if (natoms == 0)
    gmx_fatal(FARGS,"No atoms in trajectory!");

  nframes = 0 ;
  do{
    ++nframes ;
    calc_dists( ncont, index, x, ePBC, box, aktdist ) ;
    
    nformed = 0 ;
    for ( ci=0 ; ci<ncont ; ++ci )
      {
      if ( bAbs )
        {
        formed = aktdist[ci] - natdist[ci] <= cutval ;
        if ( bSym )
          {
          if ( formed && aktdist[ci] - natdist[ci] < -cutval )
            formed = FALSE ;
          }
        }
      else // relative
        {
        formed = aktdist[ci] <= (1.0+cutval)*natdist[ci] ;
        if ( bSym )
          {
          if ( formed && aktdist[ci] < (1.0-cutval)*natdist[ci] )
            formed = FALSE ;
          }
        } // ! if bAbs
      if ( formed )
        {
        ++nformed ;
        if ( bQi )
          {
          if ( bIJ )
            {  // I mean 2*ci and 2*ci+1 of course
            fprintf( iout, "%d %d\n", index[ci+ci]+1, index[ci+ci+1]+1 ) ;
            }
          else
            fprintf( iout, "%d\n",ci+1 ) ;
          }
        }
      } // for i
      fprintf( qout, "%d\n", nformed ) ;
      if ( bQi && bIJ )
        fprintf( iout, "0 0\n" );
    }
  while( read_next_x(status,&t,natoms,x,box) ) ;
  close_trj(status);

  ffclose(qout);
  if (bQi)
    ffclose(iout);
}

int gmx_kuh(int argc,char *argv[])
{
  static char *desc[] = {
    "g_kuh is very neat."
  };
  static char *bugs[] = {
    "r u kidding?"
  };
  static bool bAbs = TRUE, bSym = TRUE, bQi = TRUE, bIJ = FALSE ;
  static real cutval ;
  t_pargs pa[] = {
    { "-cut", FALSE, etREAL, {&cutval},
      "Contact cutoff" },
    { "-abscut", FALSE, etBOOL, {&bAbs},
      "use absolute cutoff (instead of relative)" },
    { "-shortcut", FALSE, etBOOL, {&bSym},
      "use cutoff also at short distances" },
    { "-qimap", FALSE, etBOOL, {&bQi},
      "output individual contacts" },
    { "-ijformat", FALSE, etBOOL, {&bIJ},
      "write pairs of atom indices into qimap (& terminate frames by 0 0)" }
  };
  FILE      *fp;
  char      *grpname, *qiname ;
  int       gnx;
  atom_id   *index;
  matrix    box;
 
  char      title[STRLEN]; 
  int       natoms, ePBC ;
  t_atoms   atoms ;
  rvec      *xn ;
  int       ncont ;
  real      *natdist ;

  t_filenm fnm[] = {
    { efSTX, "-s", "native", ffREAD  },
    { efTRX, "-f", NULL, ffREAD  },
    { efNDX, NULL, NULL, ffREAD  },
    { efOUT, "-o", "qvals", ffWRITE },
    { efOUT, "-i", "qimap", ffOPTWR }
  };
#define NFILE asize(fnm)

//  CopyRight(stderr,argv[0]);
  parse_common_args(&argc,argv, PCA_CAN_TIME | PCA_BE_NICE , // PCA_CAN_VIEW
		    NFILE,fnm,asize(pa),pa,asize(desc),desc,asize(bugs),bugs);
  
  get_stx_coordnum(ftp2fn(efSTX,NFILE,fnm),&natoms);
  init_t_atoms(&atoms,natoms,TRUE);
  snew(xn,natoms);
  read_stx_conf( ftp2fn(efSTX,NFILE,fnm), title, &atoms, xn, NULL, &ePBC, box);
//ePBC = -1 ;

  rd_index(ftp2fn(efNDX,NFILE,fnm),1,&gnx,&index,&grpname);
  if ( !even(gnx) )
    fprintf(stderr,"WARNING: odd number of atoms (%d) in group!\n",gnx);
  fprintf(stderr,"Will gather information on %d contacts\n",gnx/2);
  ncont = gnx/2 ;
  snew( natdist, ncont ) ;

  calc_dists( ncont, index, xn, ePBC, box, natdist ) ;

  do_contacts(ftp2fn(efTRX,NFILE,fnm),opt2fn("-o",NFILE,fnm),
              opt2fn("-i",NFILE,fnm),bQi,bIJ,gnx,index,ePBC,ncont,natdist,
              cutval,bAbs,bSym );
  
  thanx(stderr);
  
  return 0;
}
 
