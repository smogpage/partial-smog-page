/*
 * $Id: gmx_genbox.c,v 1.1.2.6 2007/09/19 10:54:49 spoel Exp $
 * 
 *                This source code is part of
 * 
 *                 G   R   O   M   A   C   S
 * 
 *          GROningen MAchine for Chemical Simulations
 * 
 *                        VERSION 3.3.2
 * Written by David van der Spoel, Erik Lindahl, Berk Hess, and others.
 * Copyright (c) 1991-2000, University of Groningen, The Netherlands.
 * Copyright (c) 2001-2007, The GROMACS development team,
 * check out http://www.gromacs.org for more information.

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * If you want to redistribute modifications, please consider that
 * scientific software is very special. Version control is crucial -
 * bugs must be traceable. We will be happy to consider code for
 * inclusion in the official distribution, but derived work must not
 * be called official GROMACS. Details are found in the README & COPYING
 * files - if they are missing, get the official version at www.gromacs.org.
 * 
 * To help us fund GROMACS development, we humbly ask that you cite
 * the papers on the package - you can find them in the top README file.
 * 
 * For more info, check our website at http://www.gromacs.org
 * 
 * And Hey:
 * Groningen Machine for Chemical Simulation
 */
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif


#include "sysstuff.h"
#include "typedefs.h"
#include "smalloc.h"
#include "string2.h"
#include "physics.h"
#include "confio.h"
#include "copyrite.h"
#include "txtdump.h"
#include "math.h"
#include "macros.h"
#include "random.h"
#include "futil.h"
#include "atomprop.h"
#include "names.h"
#include "vec.h"
#include "gmx_fatal.h"
#include "statutil.h"
#include "vec.h"
#include "gbutil.h"
#include "addconf.h"
#include "pdbio.h"
#include "pbc.h"
#include "mdatoms.h"
#include "mtop_util.h"
#include "force.h"
#include "nrnb.h"
#include "ns.h"

#ifdef DEBUG
void print_stat(rvec *x,int natoms,matrix box)
{
  int i,m;
  rvec xmin,xmax;
  for(m=0;(m<DIM);m++) {
    xmin[m]=x[0][m];
    xmax[m]=x[0][m];
  }
  for(i=0;(i<natoms);i++) {
    for (m=0;m<DIM;m++) {
      xmin[m]=min(xmin[m],x[i][m]);
      xmax[m]=max(xmax[m],x[i][m]);
    }   
  }
  for(m=0;(m<DIM);m++)
    fprintf(stderr,"DIM %d XMIN %8.3f XMAX %8.3f BOX %8.3f\n",
	    m,xmin[m],xmax[m],box[m][m]);
}
#endif

// from addconf.c:
static t_forcerec *fr=NULL;

void do_nsgrid(FILE *fp,bool bVerbose,
               matrix box,rvec x[],t_atoms *atoms, t_blocka *excls, real rlong)
{
  static bool bFirst = TRUE;
  static gmx_mtop_t *mtop;
  static gmx_localtop_t *top;
  static t_mdatoms  *md;
  static t_block    *cgs;
  static t_inputrec *ir;
  static t_nrnb     nrnb;
  static t_commrec  *cr;
  static int        *cg_index;

  gmx_moltype_t *molt;
  gmx_ffparams_t *ffp;
  int        i,m,natoms;
  ivec       *nFreeze;
  rvec       box_size;
  real       lambda=0,dvdlambda=0;

  natoms = atoms->nr;

  if (bFirst) {
    /* Charge group index */
    snew(cg_index,natoms);
    for(i=0; (i<natoms); i++)
      cg_index[i]=i;

    /* Topology needs charge groups and exclusions */
    snew(mtop,1);
    init_mtop(mtop);
    mtop->natoms = natoms;
    /* Make one moltype that contains the whol system */
    mtop->nmoltype = 1;
    snew(mtop->moltype,mtop->nmoltype);
    molt = &mtop->moltype[0];
    molt->name  = mtop->name;
    molt->atoms = *atoms;
    stupid_fill_block(&molt->cgs,mtop->natoms,FALSE);
//    stupid_fill_blocka(&molt->excls,natoms); // be less stupid here:
    copy_blocka( excls, &molt->excls );
  
    /* Make one molblock for the whole system */
    mtop->nmolblock = 1;
    snew(mtop->molblock,mtop->nmolblock);
    mtop->molblock[0].type = 0;
    mtop->molblock[0].nmol = 1;
    mtop->molblock[0].natoms_mol = natoms;
    /* Initialize a single energy group */
    mtop->groups.grps[egcENER].nr = 1;
    mtop->groups.ngrpnr[egcENER]  = 0;
    mtop->groups.grpnr[egcENER]   = NULL;

    ffp = &mtop->ffparams;

    ffp->ntypes = 1;
    ffp->atnr   = 1;
    snew(ffp->functype,1);
    snew(ffp->iparams,1);
    ffp->iparams[0].lj.c6  = 1;
    ffp->iparams[0].lj.c12 = 1;

    top = gmx_mtop_generate_local_top(mtop,ir);

    /* Some nasty shortcuts */
    cgs  = &(top->cgs);

    /* inputrec structure */
    snew(ir,1);
    ir->coulombtype = eelCUT;
    ir->vdwtype     = evdwCUT;
    ir->ndelta      = 2;
    ir->ns_type     = ensGRID;
    snew(ir->opts.egp_flags,1);

    /* mdatoms structure */
    snew(nFreeze,2);
    snew(md,1);
    md = init_mdatoms(fp,mtop,FALSE);
    atoms2md(mtop,ir,0,NULL,0,mtop->natoms,md);
    sfree(nFreeze);

    /* forcerec structure */
    if (fr == NULL)
      fr = mk_forcerec();
    snew(cr,1);
    cr->nnodes   = 1;
    cr->nthreads = 1;

    /*    ir->rlist       = ir->rcoulomb = ir->rvdw = rlong;
    printf("Neighborsearching with a cut-off of %g\n",rlong);
    init_forcerec(stdout,fr,ir,top,cr,md,box,FALSE,NULL,NULL,TRUE);*/
    fr->cg0 = 0;
    fr->hcg = top->cgs.nr;
    fr->nWatMol = 0;

    /* Prepare for neighboursearching */
    init_nrnb(&nrnb);

    bFirst = FALSE;
  }

  /* Init things dependent on parameters */
  ir->rlist = ir->rcoulomb = ir->rvdw = rlong;
  printf("Neighborsearching with a cut-off of %g\n",rlong);
  init_forcerec(stdout,fr,NULL,ir,mtop,cr,box,FALSE,NULL,NULL,NULL,TRUE,-1);
//  if (debug)
//    pr_forcerec(debug,fr,cr);

  /* Calculate new stuff dependent on coords and box */
  for(m=0; (m<DIM); m++)
    box_size[m] = box[m][m];
  calc_shifts(box,fr->shift_vec);
  put_charge_groups_in_box(fp,0,cgs->nr,fr->ePBC,box,cgs,x,fr->cg_cm);

  /* Do the actual neighboursearching */
  init_neighbor_list(fp,fr,md->homenr);
  search_neighbours(fp,fr,x,box,top,
                    &mtop->groups,cr,&nrnb,md,lambda,&dvdlambda,NULL,
                    TRUE,FALSE);

//  if (debug)
//    dump_nblist(debug,cr,fr,0);

//  if (bVerbose)
//    fprintf(stderr,"Succesfully made neighbourlist\n");
}


void min_box( rvec *x, int natoms, real cut, matrix box )
  {
  real min, max, val ;
  int d, i ;
  for ( d=0 ; d<DIM ; ++d )
    {
    min = max = x[0][d] ;
    for ( i=0 ; i<natoms ; ++i )
      {
      val = x[i][d] ;
      if ( val < min )
        min = val ;
      if ( val > max )
        max = val ;
      }
    box[d][d] = ( max - min ) + cut + cut ;
    } // + 2 cut to avoid contacts via pbc
  }


void do_clashes( char *fn,char *fno,char *fnx,char *fnx2, t_topology *top,
                 real cut, int exres, bool bsumres )
  {
  FILE *fout ;
  FILE *fdet = NULL ;
  FILE *fdet2 = NULL ;
  rvec *x ;
  matrix box ;
  real t ; 
  int status, natoms, nframes ;
  t_atoms *atoms = &(top->atoms) ;
  t_nblist *nlist ;

  bool bVerbose = FALSE ;
  real sqcut ;

  fout = fopen(fno,"w") ;
  if ( fnx )
    fdet = fopen(fnx,"w") ;
  if ( fnx2 )
    fdet2 = fopen(fnx2,"w") ;

  sqcut = cut*cut ; // + fudge ? not reqired, each atom is its own chargegroup

  int i, j, j0, j1, inr, jnr ; 
  rvec xi, xj, dx ;
  real n2 ;
  int nres = atoms->nres ;
  int sqnr = nres*nres ;
  int ires, jres, id ;
  int *rhits ;
  int totsum, ressum ;

  natoms=read_first_x(&status,fn,&t,&x,box);
  if (natoms == 0) 
    gmx_fatal(FARGS,"No atoms in trajectory!");
  if( natoms != top->atoms.nr ) 
    gmx_fatal(FARGS,"Wrong number of atoms in trajectory!") ; 
 
  nframes = 0 ;
  do{
    totsum = 0 ;
    snew(rhits,sqnr) ;
    min_box(x,natoms,cut,box) ;
    
    do_nsgrid(stdout,bVerbose,box,x,atoms,&top->excls,cut);

    nlist = &(fr->nblists[0].nlist_sr[eNL_VDW]);
//  int nlist->solvent_opt == 0 is solute-solute
    fprintf(stderr,"nri = %d, nrj = %d\n",nlist->nri,nlist->nrj);
    for(i=0; (i<nlist->nri); i++)
      {
      inr = nlist->iinr[i];
      j0  = nlist->jindex[i];
      j1  = nlist->jindex[i+1];
      rvec_add(x[inr],fr->shift_vec[nlist->shift[i]],xi); // ???
      ires = atoms->atom[inr].resnr ;
      for(j=j0; (j<j1); j++)
        {
        jnr = nlist->jjnr[j];
        copy_rvec(x[jnr],xj);
        rvec_sub(xi,xj,dx);
        n2 = norm2(dx);
        if ( n2 < sqcut )
          {
          jres = atoms->atom[jnr].resnr ;
          if ( abs(jres - ires) >= exres )
            {
            if ( ires<jres )
              id = ires*nres+jres;
            else
              id = jres*nres+ires;    
            ++rhits[id];
            ++totsum ;
            if ( fnx2 )
              fprintf( fdet2, "%8d%8d%8.3f\n", inr, jnr, sqrt(n2) ) ;
            }
          } // n2 < sqcut
        } // for j < j1
      } // for i < nri
    ressum = 0 ;
    if ( bsumres || fnx )
    for ( id=i=0 ; i<nres; ++i )
      for ( j=i, id+=i ; j<nres; ++j, ++id )
        {
        if ( (j-i >= exres) && rhits[id] )
          {
          ++ressum ;
          if ( fnx )
            fprintf(fdet,"%8d%8d%8d\n",i,j,rhits[id]);
          }
        }
    if ( bsumres )
      totsum = ressum ;
    fprintf(fout,"%8d\n",totsum);
    sfree(rhits);
    }
  while( read_next_x(status,&t,natoms,x,box) ) ;
  close_trj(status);

  ffclose(fout) ;
  if ( fnx )
    ffclose(fdet) ;
  if ( fnx2 )
    ffclose(fdet2);
  }


int gmx_clash(int argc,char *argv[])
{
  static char *desc[] = {
  };

  static char *bugs[] = {
    "Give me the creeps",
  };
  
  t_filenm fnm[] = {
    { efTPX, "-s", "topol",     ffREAD  },
    { efTRX, "-f", "traj",     ffREAD  },
    { efOUT, "-o", "clashnum", ffWRITE },
    { efOUT, "-ov", "resclashes", ffOPTWR },
    { efOUT, "-ovv", "atmclashes", ffOPTWR  }
  };
#define NFILE asize(fnm)
  
  static real r_distance = 0.1703 ; // AA-SBM value
  static int exres = 1 ; // adjacent residues
  static bool bsumres = TRUE ;
  t_pargs pa[] = {
    { "-rcut",   FALSE, etREAL, {&r_distance},
      "radius of contact sphere"},
    { "-exres",   FALSE, etINT, {&exres},
      "excluded sequence distance" },
    { "-sumres", FALSE, etBOOL, {&bsumres},
      "count clashes for residues instead of atoms"}
  };

  int i, natoms ;
  real t,l ;
  gmx_mtop_t mtop ;
  t_topology *top ;

  CopyRight(stderr,argv[0]);
  parse_common_args(&argc,argv, PCA_BE_NICE,NFILE,fnm,asize(pa),pa,
		    asize(desc),desc,asize(bugs),bugs);
  
  r_distance += r_distance ; // diameter

  
  read_tpx(ftp2fn(efTPX,NFILE,fnm),&i,&t,&l,NULL,NULL,&natoms,NULL,NULL,NULL,&mtop);
  snew(top,1);
  *top = gmx_mtop_t_to_t_topology(&mtop); 
 
  do_clashes( ftp2fn(efTRX,NFILE,fnm),
              opt2fn("-o",NFILE,fnm),
              opt2fn_null("-ov",NFILE,fnm),
              opt2fn_null("-ovv",NFILE,fnm),
              top, r_distance, exres, bsumres ) ;

  thanx(stderr);
  
  return 0;
}
