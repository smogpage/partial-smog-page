/*
 * $Id: gmx_rmsdist.c,v 1.5.2.2 2007/09/19 10:54:50 spoel Exp $
 * 
 *                This source code is part of
 * 
 *                 G   R   O   M   A   C   S
 * 
 *          GROningen MAchine for Chemical Simulations
 * 
 *                        VERSION 3.3.2
 * Written by David van der Spoel, Erik Lindahl, Berk Hess, and others.
 * Copyright (c) 1991-2000, University of Groningen, The Netherlands.
 * Copyright (c) 2001-2007, The GROMACS development team,
 * check out http://www.gromacs.org for more information.

 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * If you want to redistribute modifications, please consider that
 * scientific software is very special. Version control is crucial -
 * bugs must be traceable. We will be happy to consider code for
 * inclusion in the official distribution, but derived work must not
 * be called official GROMACS. Details are found in the README & COPYING
 * files - if they are missing, get the official version at www.gromacs.org.
 * 
 * To help us fund GROMACS development, we humbly ask that you cite
 * the papers on the package - you can find them in the top README file.
 * 
 * For more info, check our website at http://www.gromacs.org
 * 
 * And Hey:
 * Groningen Machine for Chemical Simulation
 */
#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <math.h>
#include <ctype.h>
#include <string.h>

#include "smalloc.h"
#include "typedefs.h"
#include "copyrite.h"
#include "statutil.h"
#include "tpxio.h"
#include "vec.h"
#include "index.h"
#include "pbc.h"
#include "futil.h"
#include "mtop_util.h"
#include "mdatoms.h"
#include "force.h"
#include "ns.h"
#include "nrnb.h"
#include "types/idef.h"

#define USE_NLIST
// no proof that it helps (for small systems)

static
void swap_ptrs( int **a, int **b )
  {
  int *tmp = *a ;
  *a = *b ;
  *b = tmp ;
  }

static
void swap( int *a, int *b )
  {
  int tmp = *a ;
  *a = *b ;
  *b = tmp ;
  }

static int cmp_bond( const void *ap, const void *bp )
  {
  int *aip = (int*) ap ;
  int *bip = (int*) bp ;
  int d ;
  if ( ( d = *aip - *bip ) != 0 )
    return d ;
  else
    return ( *(aip+1) - *(bip+1) ) ;
  }

static void sort_bonds( int *bonds, int nbonds )
  {
  int i ;
  for ( i=0 ; i<nbonds ; i+=2 )
    if ( bonds[i] > bonds[i+1] )
      swap( &bonds[i], &bonds[i+1] ) ;

  qsort( (void*) bonds, nbonds, 2*sizeof(int), &cmp_bond ) ;
  }

#ifdef USE_NLIST

// from addconf.c:
static t_forcerec *fr=NULL;

static void min_box( rvec *x, int natoms, real cut, matrix box )
  {
  real min, max, val ;
  int d, i ;
  for ( d=0 ; d<DIM ; ++d )
    {
    min = max = x[0][d] ;
    for ( i=0 ; i<natoms ; ++i )
      {
      val = x[i][d] ;
      if ( val < min )
        min = val ;
      if ( val > max )
        max = val ;
      }
    box[d][d] = ( max - min ) + cut + cut ;
    } // + 2 cut to avoid contacts via pbc
  }

static
void do_nsgrid(FILE *fp,bool bVerbose, matrix box,rvec x[],
               t_atoms *atoms, t_blocka *excls, real rlong)
{
  static bool bFirst = TRUE;
  static gmx_mtop_t *mtop;
  static gmx_localtop_t *top;
  static t_mdatoms  *md;
  static t_block    *cgs;
  static t_inputrec *ir;
  static t_nrnb     nrnb;
  static t_commrec  *cr;
  static int        *cg_index;

  gmx_moltype_t *molt;
  gmx_ffparams_t *ffp;
  int        i,m,natoms;
  ivec       *nFreeze;
  rvec       box_size;
  real       lambda=0,dvdlambda=0;

  natoms = atoms->nr;

  if (bFirst) {
    /* Charge group index */
    snew(cg_index,natoms);
    for(i=0; (i<natoms); i++)
      cg_index[i]=i;

    /* Topology needs charge groups and exclusions */
    snew(mtop,1);
    init_mtop(mtop);
    mtop->natoms = natoms;
    /* Make one moltype that contains the whol system */
    mtop->nmoltype = 1;
    snew(mtop->moltype,mtop->nmoltype);
    molt = &mtop->moltype[0];
    molt->name  = mtop->name;
    molt->atoms = *atoms;
    stupid_fill_block(&molt->cgs,mtop->natoms,FALSE);
    if ( excls!=NULL )
      copy_blocka( excls, &molt->excls ) ;
    else
      stupid_fill_blocka(&molt->excls,natoms);
  
    /* Make one molblock for the whole system */
    mtop->nmolblock = 1;
    snew(mtop->molblock,mtop->nmolblock);
    mtop->molblock[0].type = 0;
    mtop->molblock[0].nmol = 1;
    mtop->molblock[0].natoms_mol = natoms;
    /* Initialize a single energy group */
    mtop->groups.grps[egcENER].nr = 1;
    mtop->groups.ngrpnr[egcENER]  = 0;
    mtop->groups.grpnr[egcENER]   = NULL;
  
    ffp = &mtop->ffparams;

    ffp->ntypes = 1;
    ffp->atnr   = 1;
    snew(ffp->functype,1);
    snew(ffp->iparams,1);
    ffp->iparams[0].lj.c6  = 1;
    ffp->iparams[0].lj.c12 = 1;

    top = gmx_mtop_generate_local_top(mtop,ir);

    /* Some nasty shortcuts */
    cgs  = &(top->cgs);

    /* inputrec structure */
    snew(ir,1);
    ir->coulombtype = eelCUT;
    ir->vdwtype     = evdwCUT;
    ir->ndelta      = 2;
    ir->ns_type     = ensGRID;
    snew(ir->opts.egp_flags,1);

    ir->ePBC = epbcNONE ; // HAL EXPERIMENTAL

    /* mdatoms structure */
    snew(nFreeze,2);
    snew(md,1);
    md = init_mdatoms(fp,mtop,FALSE);
    atoms2md(mtop,ir,0,NULL,0,mtop->natoms,md);
    sfree(nFreeze);

    /* forcerec structure */
    if (fr == NULL)
      fr = mk_forcerec();
    snew(cr,1);
    cr->nnodes   = 1;
    cr->nthreads = 1;

    /*    ir->rlist       = ir->rcoulomb = ir->rvdw = rlong;
    printf("Neighborsearching with a cut-off of %g\n",rlong);
    init_forcerec(stdout,fr,ir,top,cr,md,box,FALSE,NULL,NULL,TRUE);*/
    fr->cg0 = 0;
    fr->hcg = top->cgs.nr;
    fr->nWatMol = 0;

    /* Prepare for neighboursearching */
    init_nrnb(&nrnb);

    bFirst = FALSE;
  }

  /* Init things dependent on parameters */
  ir->rlist = ir->rcoulomb = ir->rvdw = rlong;
//  printf("Neighborsearching with a cut-off of %g\n",rlong);
  init_forcerec(NULL,fr,NULL,ir,mtop,cr,box,FALSE,NULL,NULL,NULL,TRUE,-1);

// WILD EXPERIMENT
//  for ( i=0; (i<fr->ntype); i++ )
//    fr->ns.bHaveVdW[i]=1 ;

//  if (debug)
//    pr_forcerec(debug,fr,cr);

  /* Calculate new stuff dependent on coords and box */
  for(m=0; (m<DIM); m++)
    box_size[m] = box[m][m];
  calc_shifts(box,fr->shift_vec);
//  put_charge_groups_in_box(fp,0,cgs->nr,fr->ePBC,box,cgs,x,fr->cg_cm); HAL EXP

  /* Do the actual neighboursearching */
  init_neighbor_list(fp,fr,md->homenr);
  search_neighbours(fp,fr,x,box,top,
                    &mtop->groups,cr,&nrnb,md,lambda,&dvdlambda,NULL,
                    TRUE,FALSE);

//  if (debug)
//    dump_nblist(debug,cr,fr,0);

//  if (bVerbose)
//    fprintf(stderr,"Succesfully made neighbourlist\n");
}


static inline void calc_midpoint( const rvec a, const rvec b, rvec c )
  {
  c[XX] = 0.5*( a[XX] + b[XX] ) ;
  c[YY] = 0.5*( a[YY] + b[YY] ) ;
  c[ZZ] = 0.5*( a[ZZ] + b[ZZ] ) ;
  }

static void set_dummy_atom( t_atoms *atoms, int natoms )
  {
  int i ;
  t_atom *aktatom = atoms->atom ;
  for ( i=0 ; i<natoms ; ++i )
    {
    aktatom->m = 0.0 ;
    aktatom->q = 0.0 ;
    aktatom->mB = 0.0 ;
    aktatom->qB = 0.0 ;
    aktatom->type = 0 ; // really ?
    aktatom->typeB = 0 ; // really ?
    aktatom->ptype = eptAtom ;
    aktatom->resnr = i ; // really ?
    aktatom->atomnumber = i ;
    ++aktatom ;
    }
  }

#endif // USE_NLIST

static double calc_crossval( int ai1, int ai2, int aj1, int aj2, const rvec *x, real *ff1, real *ff2 )
  {
  rvec v1, v2, v12 ;
  rvec tmpv, apara, aperp, ahigh ;
  real invnorm ;
  real para12, perp12 ;
  real para2, perp2, high2=1.0 ;
  real f1, f2 ;

  f2 = f1 = -10 ;

  rvec_sub( x[ai2],x[ai1],v1  );
  rvec_sub( x[aj2],x[aj1],v2  );
  rvec_sub( x[aj1],x[ai1],v12 );
  invnorm = norm2( v1 );
  invnorm = invsqrt( invnorm ) ;
  svmul( invnorm, v1, apara ) ;
  cprod(v1,v12,tmpv);
  unitv(tmpv,ahigh);
  cprod(ahigh,apara,tmpv);
  unitv(tmpv,aperp);

  perp2 = iprod(v2,aperp) ;
  if ( perp2 != 0 )
    {
    para2 = iprod(v2,apara) ;
    high2 = iprod(v2,ahigh) ;
    para12 = iprod(v12,apara) ;
    perp12 = iprod(v12,aperp) ;
// fprintf( stderr, "%f %f %f %f %f %f\n", para1, perp1, high1, para2, perp2, high2 ) ;

    f2 = - perp12 / perp2 ;
    f1 = ( para12 + f2 * para2 ) * invnorm;
    }

  *ff1 = f1 ;
  *ff2 = f2 ;
  return high2 * f2 ;
  }

static void set_cut( const rvec *x, int *bonds, int nbonds2, real *cut )
  {
  int i ;
  real l2 ;
  real maxl2 = 0.0 ;
  for( i=0 ; i<nbonds2 ; i+=2 )
    {
    l2 = distance2( x[bonds[i+1]], x[bonds[i]] ) ;
    if ( l2 > maxl2 )
      maxl2 = l2 ;
    }
  *cut = 1.2*sqrt( maxl2 ) ;
  }

// for mdrun:
void find_bond_crossings( matrix aktbox, int frame, real t, const rvec *x , gmx_mtop_t *top_global, t_idef *idef )
  {
  static bool bFirst = TRUE ;
  static int nbonds, nbonds2, sqnbonds ;
  static int *bonds ;
  static int *valid, *nextvalid ;
  static real *crosstab ;
  static real cut ;
#ifdef USE_NLIST
  static t_atoms *dummyatoms ;
  static rvec *midpoints ;
#endif

  matrix box ;
  t_nblist *nlist ;

  int nr, i, j, j0, j1, bi, bj, bi2, bj2, ai1, ai2, aj1, aj2, id ;

  bool found ;

  real f1, f2 ;
  real crossval ;

  char logline[100] ;
  char buffy[100] ;

  if (bFirst)
    {
    nr = idef->il[F_BONDS].nr ;
    nbonds = nr / 3 ;
    nbonds2 = nbonds + nbonds ; // 2*nbonds
    sqnbonds = nbonds * nbonds ;

    snew( bonds, nbonds2 ) ;
    snew( valid, sqnbonds ) ;
    snew( nextvalid, sqnbonds ) ;
    snew( crosstab, sqnbonds ) ;

    for ( j=i=0 ; i<nr ; i+=3 )
      {
      bonds[ j ]   = idef->il[F_BONDS].iatoms[i+1] ;
      bonds[ j+1 ] = idef->il[F_BONDS].iatoms[i+2] ;
      j += 2 ;
      }

    sort_bonds( bonds, nbonds ) ;

    set_cut( x, bonds, nbonds2, &cut) ;
#ifdef USE_NLIST
    snew( midpoints, nbonds ) ;
    snew( dummyatoms, 1) ;
    init_t_atoms( dummyatoms, nbonds, FALSE ) ;
    set_dummy_atom( dummyatoms, nbonds ) ;
#endif

    bFirst = FALSE ;
    }

  copy_mat( aktbox, box ) ;

  for ( id=0 ; id<sqnbonds ; ++id )
    nextvalid[ id ] = 0 ;
  found = FALSE ;

#ifdef USE_NLIST
  for ( bi=j=0 ; j<nbonds2 ; j+=2 )
    calc_midpoint( x[ bonds[j] ], x[ bonds[j+1] ], midpoints[ bi++ ] ) ;

  min_box(midpoints,nbonds,cut,box) ; 
  do_nsgrid(NULL, FALSE, box, midpoints, dummyatoms, NULL, cut);

  nlist = &(fr->nblists[0].nlist_sr[eNL_VDW]);

  for(i=0; (i<nlist->nri); ++i)
    {
    j0 = nlist->jindex[i];
    j1 = nlist->jindex[i+1];

    for(j=j0; (j<j1); ++j)
      {
      bi = nlist->iinr[i];
      bj = nlist->jjnr[j];
      if ( bi > bj )
        swap(&bi,&bj) ;

      bi2 = bi + bi ; // 2 atoms / bond in array bonds
      bj2 = bj + bj ; // 2 atoms / bond again

      ai1 = bonds[bi2] ;
      ai2 = bonds[bi2+1] ;
      aj1 = bonds[bj2] ;
      aj2 = bonds[bj2+1] ;
#else
  for ( i=0 ; i<nbonds2 ; i+=2 )
    {
    for ( j=i+2 ; j<nbonds2 ; j+=2 )
      {
      ai1 = bonds[i] ;
      ai2 = bonds[i+1] ;
      aj1 = bonds[j] ;
      aj2 = bonds[j+1] ; 
#endif
      if ( ai1 != aj1 && ai1 != aj2 && ai2 != aj1 && ai2 != aj2 ) { // FIXME introduce exclusions

      crossval = calc_crossval( ai1, ai2, aj1, aj2, x, &f1, &f2 ) ;
      if ( f1 > 0 && f1 < 1 && f2 > 0 && f2 < 1 )
        {
#ifdef USE_NLIST
        id = bi * nbonds + bj ;
#else
        id = i/2*nbonds + j/2 ;
#endif
        nextvalid[ id ] = 1 ;
        if ( valid[id] )
        if (  ( crosstab[ id ] > 0 &&  crossval < 0 )
           || ( crosstab[ id ] < 0 &&  crossval > 0 )  )
          { 
          sprintf( logline, "XING: %d %f   %d %d   %d %d   %f %f   %f %f\n", frame, t, ai1, ai2, aj1, aj2, f1, f2, crosstab[ id ], crossval ) ;
          fprintf( stdout, "%s\n", logline ) ;
          found = TRUE ;
          }
        crosstab[ id ] = crossval ;
        }                                                      }  // if ! excluded FIXME
      } // for j
    } // for i
  swap_ptrs( &valid, &nextvalid ) ;
  if ( found )
    {
    sprintf( buffy, "crossing_%d.pdb", frame ) ;
    write_sto_conf_mtop( buffy, logline, top_global, x, NULL, epbcNONE, NULL );
    }

  }

// for g_cross
void do_crossings ( char *of, char* trj, t_atoms *atoms, t_topology *top,
                    int *bonds, int nbonds, t_blocka *excls                )
{
  int          i,j,j0,j1, status, frame, teller, natom ;
  real         t;

  t_nblist     *nlist ;
  matrix       box;
  rvec         *x ;
  FILE         *fp ;

  int      nbonds2, sqnbonds ;
  int      ai1, ai2, aj1, aj2 ;
  int      bi, bi2, bj, bj2 ;
  rvec     dx ;
  real     cut ;
  real     f1, f2 ;
  float    crossval ;
  float    *crosstab ;
  int      *valid, *nextvalid ;
  int      id ;
#ifdef USE_NLIST
  t_atoms  *dummyatoms ;
  rvec     *midpoints ;
#endif

  nbonds2 = nbonds + nbonds ;
  sqnbonds = nbonds * nbonds ;

#ifdef USE_NLIST
  snew( dummyatoms, 1) ;
  init_t_atoms( dummyatoms, nbonds, FALSE ) ;
  set_dummy_atom( dummyatoms, nbonds ) ;
  snew( midpoints, nbonds );
#endif

  /* initialize arrays */
  snew( crosstab, sqnbonds );
  snew( valid, sqnbonds );
  snew( nextvalid, sqnbonds );

  /*open output files*/
  fp=ffopen( of, "w" );
  fprintf( fp, "# N t ai aj ak al f1 f2\n" ) ;
  
  /*do a first step*/
  natom=read_first_x(&status,trj,&t,&x,box);

  set_cut( (const rvec*)x, bonds, nbonds2, &cut ) ; // move up ?

  frame = 0 ;
  do {
    for ( id=0 ; id<sqnbonds ; ++id )
      nextvalid[ id ] = 0 ;

#ifdef USE_NLIST
  for ( bi=j=0 ; j<nbonds2 ; j+=2 )
    calc_midpoint( x[ bonds[j] ], x[ bonds[j+1] ], midpoints[ bi++ ] ) ;

  min_box(midpoints,nbonds,cut,box) ;
  do_nsgrid(NULL, FALSE, box, midpoints, dummyatoms, excls, cut);

  nlist = &(fr->nblists[0].nlist_sr[eNL_VDW]);

  for(i=0; (i<nlist->nri); ++i)
    {
    j0 = nlist->jindex[i];
    j1 = nlist->jindex[i+1];

    for(j=j0; (j<j1); ++j)
      {
      bi = nlist->iinr[i];
      bj = nlist->jjnr[j];
      if ( bi > bj )
        swap(&bi,&bj) ;

      bi2 = bi + bi ; // 2 atoms / bond in array bonds
      bj2 = bj + bj ; // 2 atoms / bond again

      ai1 = bonds[bi2] ;
      ai2 = bonds[bi2+1] ;
      aj1 = bonds[bj2] ;
      aj2 = bonds[bj2+1] ;
#else
  for ( i=0 ; i<nbonds2 ; i+=2 )
    {
    for ( j=i+2 ; j<nbonds2 ; j+=2 )
      {
      ai1 = bonds[i] ;
      ai2 = bonds[i+1] ;
      aj1 = bonds[j] ;
      aj2 = bonds[j+1] ;
#endif

      crossval = calc_crossval( ai1, ai2, aj1, aj2, (const rvec*)x, &f1, &f2 ) ;
      if ( f1 > 0 && f1 < 1 && f2 > 0 && f2 < 1 )
        {
#ifdef USE_NLIST
        id = bi * nbonds + bj ;
#else
        id = i/2*nbonds + j/2 ;
#endif
        nextvalid[ id ] = 1 ;
        if ( valid[id] )
        if (  ( crosstab[ id ] > 0 &&  crossval < 0 )
           || ( crosstab[ id ] < 0 &&  crossval > 0 )  )
          {
          fprintf( fp, "%d %f   %d %d   %d %d   %f %f   %f %f\n", frame, t, ai1, ai2, aj1, aj2, f1, f2, crosstab[ id ], crossval ) ;
          }
        crosstab[ id ] = crossval ;
        }
      } // for j  
    } // for i
    swap_ptrs( &valid, &nextvalid ) ;
    ++frame ;
  } while (read_next_x(status,&t,natom,x,box));
  fprintf(stderr, "\n");

  close_trj(status);
  fclose(fp);

  teller = nframes_read();
}


#ifdef USE_NLIST
#undef USE_NLIST
#endif

static
int cmp_index( const void *ap, const void *bp )
  {
  return *(atom_id*)ap - *(atom_id*)bp ;
  }

// also for g_cross
void generate_bonds( t_atoms *atoms, t_idef *idef,
                     int *index1, int isize1, int *index2, int isize2,
                     int **bonds, int *nbonds, t_blocka **excls        )
  {
  int *allbonds, *goodbonds ;
  int max, nr ;
  int i, j, ai1, ai2, aj1, aj2 ;
  bool bSame,  in1, in2, bEx ;
  int got, got2 ;
  int *class ;
  enum { eNONE, eFIRST, eSECOND, eBOTH } ;
  t_blocka *ex ;

  bSame = ( index2 == index1 ) ;
  qsort( (void*)index1, isize1, sizeof(*index1), &cmp_index ) ;
  if ( ! bSame )
    qsort( (void*)index2, isize2, sizeof(*index2), &cmp_index ) ;

  nr  = idef->il[F_BONDS].nr ;
  max = nr / 3 ;
  snew( allbonds, 2*max ) ;
  snew( goodbonds, 2*max ) ;
  snew( class, max ) ; 
 
  for ( j=i=0 ; i<nr ; i+=3 )
    {
    ai1 = idef->il[F_BONDS].iatoms[i+1] ;
    ai2 = idef->il[F_BONDS].iatoms[i+2] ;
    if ( ai1 > ai2 )
      swap( &ai1, &ai2 ) ;
    allbonds[j]   = ai1 ;
    allbonds[j+1] = ai2 ;
    j += 2 ;
    }
  sort_bonds( allbonds, max ) ;

  got = got2 = 0 ;
  for ( i=0 ; i<2*max ; i+=2 )
    {
    ai1 = allbonds[i] ;
    ai2 = allbonds[i+1] ;

    in1 = (  bsearch( (void*)&ai1, (void*)index1, isize1,
                      sizeof(*index1), &cmp_index       ) != NULL
          && bsearch( (void*)&ai2, (void*)index1, isize1,
                      sizeof(*index1), &cmp_index       ) != NULL ) ;

    if ( bSame )
      in2 = in1 ;
    else
      in2 = (  bsearch( (void*)&ai1, (void*)index2, isize2,
                        sizeof(*index2), &cmp_index       ) != NULL
            && bsearch( (void*)&ai2, (void*)index2, isize2,
                        sizeof(*index2), &cmp_index       ) != NULL ) ;

    if ( in1 || in2 )
      {
      goodbonds[ got2++ ] = ai1 ;
      goodbonds[ got2++ ] = ai2 ;
      if ( in1 )
        class[ got ] += eFIRST ;
      if ( in2 )
        class[ got ] += eSECOND ;
      ++got ;
      }   
    } // for i
  sfree(allbonds) ;

  snew( ex, 1 ) ;
  init_blocka( ex ) ;
  ex->nr = got ;
  srenew( ex->index, ex->nr+1 ) ;
  ex->nalloc_index = ex->nr+1 ;
  snew( ex->a, got*got ) ;
  ex->nalloc_a = got*got ;

  for( i=0 ; i<got ; ++i )
    {
    ai1 = goodbonds[2*i] ;
    ai2 = goodbonds[2*i+1] ;
    for ( j=i+1 ; j<got ; ++j )
      {
      aj1 = goodbonds[2*j] ;
      aj2 = goodbonds[2*j+1] ;
      bEx = ( ai1 == aj1 || ai1 == aj2 || ai2 == aj1 || ai2 == aj2 ) ;
      if ( class[i] == class[j] && class[i] != eBOTH )
        bEx = TRUE ;
    
      if (bEx)
        ex->a[ ex->nra++ ] = j ;
      } // for j
    ex->index[i+1] = ex->nra ;
    } // for i

  srenew( ex->a, ex->nra ) ;
  ex->nalloc_a = ex->nra ;

  sfree(class) ;

  *bonds = goodbonds ;
  *nbonds = got ;
  *excls = ex ;
  }
