
#include <math.h>
#include <string.h>
#include <stdio.h>

#ifndef TESTPROG
#include "smalloc.h"
#include "typedefs.h"
#include "amctables.h"
#endif

static const int amc_ntypes = 4 ;

static int amc_min_delres = 3 ;
static int amc_max_delres = 12 ;
static int amc_nres ; 

static int sumn( int n )
  {
  int x = n * ( n+1 ) ;
  return x / 2 ;
  }

static int amc_num_cont( ) // for one type
  {
  if (amc_nres > amc_max_delres )
    return  ( amc_max_delres - amc_min_delres + 1 )
          * ( amc_nres - amc_max_delres )
          + sumn( amc_max_delres - amc_min_delres );
  else if ( amc_nres > amc_min_delres )
    return sumn( amc_nres - amc_min_delres );
  else 
    return 0 ;
  }


// FIXME check everything imaginable, i, j, t are user input
static int amc_index( int resi, int resj, int type ) // i < j !
  {
  int index ;
  int delres = resj - resi ;
  if ( delres < amc_min_delres || delres > amc_max_delres )
    return -1 ;
  if ( resi + amc_max_delres < amc_nres ) // in full block
    {
    index = ( amc_max_delres - amc_min_delres + 1 ) * resi
            + delres - amc_min_delres
            + type * amc_num_cont() ; 
    }
  else if ( amc_nres > amc_max_delres ) // full block does exist 
    {
    index = ( amc_max_delres - amc_min_delres + 1 ) * resi
          - sumn( amc_max_delres + resi - amc_nres )
          + delres - amc_min_delres
          + type * amc_num_cont() ;
    }
  else // no full block
    {
    index = ( amc_nres - amc_min_delres ) * resi
          - sumn( resi - 1 )
          + delres - amc_min_delres
          + type * amc_num_cont() ;
    }
  return index ;
  }

static void amc_step( int* const resi, int* const resj )
  {
  int i = *resi ;
  int j = *resj ;
  if ( j >= i + amc_max_delres || j >= amc_nres - 1 )
    {
    if ( i >= amc_nres - 1 || i >= amc_nres - amc_min_delres - 1 )
      {
      *resi = amc_nres ;
      *resj = amc_nres ;
      }
    else
      {
      ++(*resi) ;
      *resj = *resi + amc_min_delres ;
      }
    }
  else
    ++(*resj) ;
  }

#ifndef TESTPROG

static amc_contact_t* amc_contacts ;

static void init_amc_contact( amc_contact_t* const cont )
  {
  cont->nmems = 0 ;
  cont->memories = NULL ;
  }

static void amc_add_memory( amc_contact_t* const cont, double dist, double gamma )
  {
  int num = cont->nmems ;
  amc_memory_t* mem ;
  srenew( cont->memories, num+1 ) ;
  mem = &cont->memories[ num ] ;
  mem->dist = dist ;
  mem->gamma = gamma ;
  ++cont->nmems ;
  }

static void amc_set_tabnr( int ftgood, int ftbad, gmx_mtop_t* const mtop )
  {
  const gmx_moltype_t *molt;
  const t_ilist *il;
  int mt, ftype, stride, i, tabnr ;
  int atomi, atomj, resi, resj, type ;
  char *anamei, *anamej ;
  int numused = 0 ;

  molt = &mtop->moltype[0];

    for(ftype=0; ftype<F_NRE; ftype++)
      {
      if ( ftype == ftbad )
        if ( molt->ilist[ftype].nr ) 
          gmx_fatal(FARGS,"AMC tables are incompatible with ftype=%d",ftbad ) ;
      if ( ftype == ftgood )
        {
        il = &molt->ilist[ftype];
        stride = 3 ; // 1 + NRAL(ftype);
        for(i=0; i<il->nr; i+=stride)
          {
//          tabnr = mtop->ffparams.iparams[il->iatoms[i]].tab.table;
//          if ( tabnr >= 0 )
//            gmx_fatal(FARGS,"Unexpected bonded table number %d > 0 for AMC", tabnr) ;
          atomi = il->iatoms[ i+1 ] ;
          atomj = il->iatoms[ i+2 ] ;
          resi = molt->atoms.atom[ atomi ].resnr ;
          resj = molt->atoms.atom[ atomj ].resnr ;
          anamei = *(molt->atoms.atomname[ atomi ]) ;
          anamej = *(molt->atoms.atomname[ atomj ]) ;
// type = 0 - caca, 1 - cacb, 2 - cbca, 3 - cbcb
          type = 0 ; 
          if ( 0 == strcmp( "CB", anamei ) ) type += 2 ;
          else if ( 0 != strcmp( "CA", anamei ) )
            gmx_fatal(FARGS,"AMC contact for unexpected atomname %s", anamei ) ;
          if ( 0 == strcmp( "CB", anamej ) ) type += 1 ;
          else if ( 0 != strcmp( "CA", anamej ) )
            gmx_fatal(FARGS,"AMC contact for unexpected atomname %s", anamej ) ;

          tabnr = amc_index( resi, resj, type ) ;
          if ( ! amc_contacts[ tabnr ].nmems )
            gmx_fatal(FARGS,"No memories given for contact %6d%6d%4s%4s", resi+1, resj+1, anamei, anamej ) ;

          mtop->ffparams.iparams[il->iatoms[i]].tab.table = tabnr ;
          ++numused ;
//          fprintf( stderr,"atoms %8d %8d type %d table %6d memories %6d\n",
//                   atomi,atomj,type,tabnr, amc_contacts[ tabnr ].nmems ) ;
          } //for i
        } // if ftgood
      } // for ftype
  fprintf( stderr, "Assigned %d AMC tables\n", numused ) ;

  } // amc_set_tabnr


static void amc_init( gmx_mtop_t* const mtop )
  {
  const gmx_moltype_t *molt ;
  int c, numcont ;
  if ( mtop->nmoltype != 1 )
    gmx_fatal(FARGS,"AMC supports only a single molecule type") ;

  molt = &mtop->moltype[0];
  amc_nres =  molt->atoms.nres ;
  numcont = amc_num_cont() ;

  snew( amc_contacts, amc_ntypes*numcont ) ;
  for( c=0 ; c<amc_ntypes*numcont ; ++c )
    init_amc_contact( &(amc_contacts[c]) ) ;
  }


static void amc_read_contacts()
  {
  int resi, resj, typei, typej ;
  int index ;
  double dist, gamma ;
  FILE* inf ;
  int got, type ;
    int num = 0 ;

  inf = fopen("AMCcontacts.txt","r") ;
  if ( NULL == inf )
    gmx_fatal(FARGS,"failed to open file AMCcontacts.txt") ;

  do{
    got = fscanf( inf, "%d%d%d%d%lf%lf", &resi, &resj, &typei, &typej, &dist, &gamma ) ;
    if( EOF != got )
      {
      if ( got < 6 )
        gmx_fatal(FARGS,"Not enough values for AMC contact") ;

      --resi ; // GMX numbering starts at 0
      --resj ;
      type = 2*( typei-1 ) + ( typej-1 )  ; // in file : CA=1, CB=2 
      index = amc_index( resi, resj, type ) ;
      amc_add_memory( &(amc_contacts[index]), dist, gamma ) ;
      ++num ;
      }
    }
  while( EOF != got ) ;

  fclose( inf ) ;

  fprintf( stderr,"read %d memories for AMC contacts\n",num );
  }

void amc_setup_contacts( int ftgood, int ftbad, gmx_mtop_t* const mtop )
  {
  amc_init( mtop ) ;
  amc_read_contacts() ;
  amc_set_tabnr( ftgood, ftbad, mtop ) ;
  }

extern bondedtable_t make_amc_table( amc_contact_t const* cont, double scale ) ;

bondedtable_t* make_amc_tables( double scale )
  {
  int c, nmems ;
  int resi, resj, type ;
  int index ;
  int numcont = amc_num_cont() ;
  int ntab = 0 ;
  int usedmems = 0 ;
  amc_contact_t* contacts = amc_contacts ;
  amc_contact_t* aktc ;

  bondedtable_t* tables ;

//  fprintf(stderr,"make_amc_tables()\n");

  snew( tables, amc_ntypes*numcont ) ;

  index = 0 ;
  aktc = contacts ;
  for ( type=0 ; type<amc_ntypes ; ++type )
  {
  resi = 0 ;
  resj = amc_min_delres ;
  for ( c=0 ; c<numcont ; ++c )
    {
    aktc->resi = resi ;
    aktc->resj = resj ;
    nmems = aktc->nmems ;
    
    if ( nmems )
      {
//      fprintf( stderr,"contact %4d %4d type %d, memories %8d\n",
//               resi+1, resj+1, type, nmems );
      tables[ index ] = make_amc_table( aktc, scale ) ;
      ++ntab ;
      usedmems += nmems ;
      }

    amc_step( &resi, &resj ) ;
    ++aktc ;
    ++index ;
    }
  }
  sfree( contacts ) ;

  fprintf(stderr,"populated %d AMC tables using %d memories\n",ntab,usedmems);

  return tables ;
  }

#endif // ! TESTPROG

#ifdef TESTPROG
int test_amc_index()
  {
  int nerr = 0 ;
  int resi = 0 ;
  int resj = resi + amc_min_delres ;
  int count = 0 ;
  int index, num ;
  while( resi < amc_nres && resj < amc_nres )
    {
    index = amc_index( resi, resj ) ;
    if ( index != count )
      {
      ++nerr ;
      fprintf(stderr,"ERROR: index( %d ) != count( %d ) for i=%d, j=%d, min=%d, max=%d, N=%d\n", index, count, resi, resj, amc_min_delres, amc_max_delres, amc_nres ) ;
      }
    amc_step( &resi, &resj ) ;
    ++count ;
    }
  num = amc_num_cont() ;
  if ( num != count )
    {
    ++nerr ;
    fprintf(stderr,"ERROR: num( %d ) != count( %d ) for i=%d, j=%d, min=%d, max=%d, N=%d\n", index, count, resi, resj, amc_min_delres, amc_max_delres, amc_nres ) ;
    }
  }

#define ASIZE( d ) (sizeof(d)/sizeof((d)[0])) 

int main( void )
  {
  int in, imin, imax ;
  int NVALS[] = { 2, 3, 4, 5, 6, 7, 8, 9, 10,
                 11, 12, 13, 14, 15, 30, 50, 100, 327, 500, 1017 } ;
  int ABSMIN[] = { 1, 2, 3, 5, 13, 28 } ;
  int MINTON[] = { -43, -5, -3, -2, -1, 0, 5 } ;
  int MAXTOMIN[] = { 0, 1, 2, 3, 5, 9, 13 } ;
  int MAXTON[] = { -26, -5, -3, -3, -1, 0, 5 } ;

  for ( in=0 ; in<ASIZE( NVALS ) ; ++in )
    {
    amc_nres = NVALS[ in ] ;

    for ( imin=0 ; imin < ASIZE( ABSMIN ) ; ++imin )
      {
      amc_min_delres = ABSMIN[ imin ] ;
      for ( imax=0 ; imax < ASIZE( MAXTOMIN ) ; ++imax )
        {
        amc_max_delres = amc_min_delres + MAXTOMIN[ imax ] ;
        if ( amc_min_delres > 0 && amc_max_delres >= amc_min_delres ) {
          fprintf(stderr,"N=%4d, min=%4d, max=%4d\n",amc_nres,amc_min_delres,amc_max_delres) ;
          test_amc_index() ;  }
        }
      for ( imax=0 ; imax < ASIZE( MAXTON ) ; ++imax )
        {
        amc_max_delres = amc_nres + MAXTON[ imax ] ;
        if ( amc_min_delres > 0 && amc_max_delres >= amc_min_delres ) {
          fprintf(stderr,"N=%4d, min=%4d, max=%4d\n",amc_nres,amc_min_delres,amc_max_delres) ;
          test_amc_index() ;  }
        }
      }

    for ( imin=0 ; imin < ASIZE( MINTON ) ; ++imin )
      {
      amc_min_delres = amc_nres + MINTON[ imin ] ;
      for ( imax=0 ; imax < ASIZE( MAXTOMIN ) ; ++imax )
        {
        amc_max_delres = amc_min_delres + MAXTOMIN[ imax ] ;
        if ( amc_min_delres > 0 && amc_max_delres >= amc_min_delres ) {
          fprintf(stderr,"N=%4d, min=%4d, max=%4d\n",amc_nres,amc_min_delres,amc_max_delres) ;
          test_amc_index() ; }
        }
      for ( imax=0 ; imax < ASIZE( MAXTON ) ; ++imax )
        {
        amc_max_delres = amc_nres + MAXTON[ imax ] ;
        if ( amc_min_delres > 0 && amc_max_delres >= amc_min_delres ) {
          fprintf(stderr,"N=%4d, min=%4d, max=%4d\n",amc_nres,amc_min_delres,amc_max_delres) ;
          test_amc_index() ;  }
        }
      }
    }
  }
#endif // TESTPROG
