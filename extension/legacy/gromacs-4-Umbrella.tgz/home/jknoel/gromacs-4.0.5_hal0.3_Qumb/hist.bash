for i in v1 v2 v3 v4 
do
sed '1,10000d' $i > $i.trim
#awk 'BEGIN{a=0}{if($1==){a=1}if(a && NR%10==0)print $0}' $i > $i.trim
#cat $i.a | awk '{if(NR%1000==0) print $0}' | tail -n 10000 > $i.trim
awk '{
bin[int($2)]++;
}END{
for(i=0;i<500;i++){ if(bin[i]>0)print i,bin[i];}
}' $i.trim > $i.hist1
awk '{
bin[int($2)]+=exp($3/(155/120));
}END{
for(i=0;i<500;i++){ if(bin[i]>0)print i,bin[i];}
}' $i.trim > $i.hist
#find max
max=$(awk 'BEGIN{max=-1}{if($2>max)max=$2}END{print max}' $i.hist)
awk '{print $1,$2/'$max'}' $i.hist > $i.hist.norm
done

