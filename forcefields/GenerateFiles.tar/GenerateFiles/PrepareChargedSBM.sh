#! /bin/bash
# Written by Ryan Hayes on 2012-07-25 to take files from a chargeless SBM and an AMBER representation and put them into the same topology. This will also require combining in the H atom charges.

DIR=`pwd`

# -------------------- BEGIN THESE VARIABLES MUST BE SET -----------------
GD=/Users/ryahayes/Programs/gromacs-4.6.1C/double/bin

SYSIN=ARibo_VSBM
SYSTAGOUT=ARibo

# Mg concentrations (in Molar)
CONCs=(3.2e-5)

# Expected values for Gamma (in total ions) at each concentration
GAMMA_EXPs=(    5.6000)

# Manning condensed K in absence of Mg (will sutract 2*GAMMA_EXP and then
# Rescale Debye Huckel interactions according to this
MCK=20
# KCl concentration (milli Molar - sorry to switch units...)
KClCONC=50
# Charge of RNA
QRNA=70
# Directory for output files
PARDIROUT=$DIR/Test
# Volume in nm^3 of RNA (approximately QRNA/2)
RNAVOL=36
# -------------------- BEGIN THESE VARIABLES MUST BE SET -----------------

mkdir $PARDIROUT

# for i in `awk 'BEGIN {for (i=0; i<'${#CONCs[@]}'; i++) {print i}}'`
for i in `awk 'BEGIN {for (i=0; i<'${#CONCs[@]}'; i++) {print i}}'`
do
CONC=${CONCs[$i]}
GAMMA_EXP=${GAMMA_EXPs[$i]}

SYS=${SYSTAGOUT}_MG${CONC}_MCK${MCK}

DL=`awk 'BEGIN {print sqrt(80*0.008314*300/((4*3.14159265*138.90)*2*('$KClCONC'*0.0006022)))}'` # 0.9742 nm at 100 mM KCl

BULKMG=200
BS=`awk 'BEGIN {i=((int(exp(1/3*log('$RNAVOL'+'$BULKMG'/('$CONC'*0.6022)))/10)+1)*10); print i}'`
MGIONS=`awk 'BEGIN {i=int(0.6022*'$CONC'*('$BS'*'$BS'*'$BS'-'$RNAVOL')+'$GAMMA_EXP'+0.5); print i}'`
rMGMG=0.56
rMGRNA=0.34
rRNARNA=0.170323
CLEANUP="Y"

RNA_RESCALE=`awk 'BEGIN {FACTOR=('$MCK'-2*'$GAMMA_EXP')/'$QRNA'; if (FACTOR<0) {FACTOR=0}; print 1-FACTOR}'`


# # If you don't do this, genbox will build an absurdly large neighbor search grid
# GENBOXCUT=`awk 'BEGIN {i='$BS'/400; j='$rMGRNA'-0.11; if (i>j) {print i} else {print j}}'`
# Use genbigbox now
gcc -o genbigbox.cex genbigbox.c

echo "Concentration is $CONC"
echo "Box size is $BS"
echo "Number of Mg ions is $MGIONS"

DIROUT=$PARDIROUT/$SYS
GRO=$DIR/$SYSIN.gro
GROUT=$DIROUT/$SYS.gro
TOP=$DIR/$SYSIN.top
TOPOUT=$DIROUT/$SYS.top
NDX=$DIROUT/$SYS.ndx

mkdir $PARDIROUT
rm -r $DIROUT
mkdir $DIROUT

cp $DIR/TemplateRun/* $DIROUT/
sed "s/SYSNAMESUB/$SYS/g" $DIR/TemplateRun/run.tcsh > $DIROUT/run.tcsh

echo -e "0\n0\n" > input
OPTIONS="-box $BS $BS $BS -center"
FILES="-f $GRO -s $GRO -o int1.gro"
cat input | $GD/trjconv $OPTIONS $FILES
rm input

echo "Mg ion" > MG.gro
echo "    1" >> MG.gro
echo "    1  MG   MG     1   0.000   0.000   0.000" >> MG.gro
# tail -n 1 int1.gro >> MG.gro
echo "   1.00000   1.00000   1.00000" >> MG.gro

# $GD/genbox -cp int1.gro -ci MG.gro -o $GROUT -nmol $MGIONS -box $BS $BS $BS -vdwd $GENBOXCUT
./genbigbox.cex int1.gro MG.gro $GROUT $MGIONS $rMGMG

# Set up top file
NATOM_PAD=`awk '{if (NR==2) print $0}' $GRO`
NATOM=`echo $NATOM_PAD`
# Put charges in for each atom
awk 'BEGIN {read=-2
format="%6d  %-3s %6d  %-3s  %-3s %6d % 6.4f  % 5.3f\n"
afterTER=1
groline=0
RES=0}
{
if (FILENAME=="'$DIR/SBM/RA_SBM.txt'") RA[$1]=$2
if (FILENAME=="'$DIR/SBM/RC_SBM.txt'") RC[$1]=$2
if (FILENAME=="'$DIR/SBM/RG_SBM.txt'") RG[$1]=$2
if (FILENAME=="'$DIR/SBM/RU_SBM.txt'") RU[$1]=$2
if (FILENAME=="'$DIR/SBM/RA5_SBM.txt'") RA5[$1]=$2
if (FILENAME=="'$DIR/SBM/RC5_SBM.txt'") RC5[$1]=$2
if (FILENAME=="'$DIR/SBM/RG5_SBM.txt'") RG5[$1]=$2
if (FILENAME=="'$DIR/SBM/RU5_SBM.txt'") RU5[$1]=$2
if (FILENAME=="'$DIR/SBM/RA3_SBM.txt'") RA3[$1]=$2
if (FILENAME=="'$DIR/SBM/RC3_SBM.txt'") RC3[$1]=$2
if (FILENAME=="'$DIR/SBM/RG3_SBM.txt'") RG3[$1]=$2
if (FILENAME=="'$DIR/SBM/RU3_SBM.txt'") RU3[$1]=$2
if (FILENAME=="'$DIR/SBM/RA5P_SBM.txt'") RA5P[$1]=$2
if (FILENAME=="'$DIR/SBM/RC5P_SBM.txt'") RC5P[$1]=$2
if (FILENAME=="'$DIR/SBM/RG5P_SBM.txt'") RG5P[$1]=$2
if (FILENAME=="'$DIR/SBM/RU5P_SBM.txt'") RU5P[$1]=$2
if (FILENAME=="'$DIR/SBM/SAM_SBM.txt'") SAM[$1]=$2
if (FILENAME=="'$DIR/SBM/ADE_SBM.txt'") ADE[$1]=$2
if (FILENAME=="'$GRO'") {
  groline++
  if (groline>2) {
    if ($1>RES) {
      RES=$1
      R3[RES]=0
      R5[RES]=0
      RP[RES]=0
    }
    if ($3=="P") RP[RES]=1
    if ($2=="A" || $2=="C" || $2=="G" || $2=="U") {
      ISRNA=1
      LastRES=RES} else {ISRNA=0}
    if (afterTER && ISRNA) {
      R5[RES]=1
      afterTER=0
    }
    if (NF<=3) {
      R3[LastRES]=1
    }
  }
}
if (FILENAME=="'$TOP'") {
  if ($2=="atoms" || read>-2) read++
  if (read>=1 && read <= '$NATOM') {
    if ($4=="A") {
      if (R3[$3]) {Charge=RA3[$2]} else if (R5[$3] && RP[$3]) {Charge=RA5P[$2]}
      else if (R5[$3]) {Charge=RA5[$2]} else {Charge=RA[$2]}}
    else if ($4=="C") {
      if (R3[$3]) {Charge=RC3[$2]} else if (R5[$3] && RP[$3]) {Charge=RC5P[$2]}
      else if (R5[$3]) {Charge=RC5[$2]} else {Charge=RC[$2]}}
    else if ($4=="G") {
      if (R3[$3]) {Charge=RG3[$2]} else if (R5[$3] && RP[$3]) {Charge=RG5P[$2]}
      else if (R5[$3]) {Charge=RG5[$2]} else {Charge=RG[$2]}}
    else if ($4=="U") {
      if (R3[$3]) {Charge=RU3[$2]} else if (R5[$3] && RP[$3]) {Charge=RU5P[$2]}
      else if (R5[$3]) {Charge=RU5[$2]} else {Charge=RU[$2]}}
    else if ($4=="ADE") {
      Charge=ADE[$2]}
    else if ($4=="SAM") {
      Charge=SAM[$2]}
    printf format, $1, $2, $3, $4, $5, $6, Charge, $8
  }
  else {
    print $0 }
}}' $DIR/SBM/RA_SBM.txt $DIR/SBM/RA5_SBM.txt $DIR/SBM/RA3_SBM.txt $DIR/SBM/RA5P_SBM.txt \
$DIR/SBM/RC_SBM.txt $DIR/SBM/RC5_SBM.txt $DIR/SBM/RC3_SBM.txt $DIR/SBM/RC5P_SBM.txt \
$DIR/SBM/RG_SBM.txt $DIR/SBM/RG5_SBM.txt $DIR/SBM/RG3_SBM.txt $DIR/SBM/RG5P_SBM.txt \
$DIR/SBM/RU_SBM.txt $DIR/SBM/RU5_SBM.txt $DIR/SBM/RU3_SBM.txt $DIR/SBM/RU5P_SBM.txt \
$DIR/SBM/SAM_SBM.txt $DIR/SBM/ADE_SBM.txt $GRO $TOP> int2.top

# Ignore atom types for now.

# Put in MG atom type
LINENUMBER=$(( `grep -n " moleculetype " int2.top | cut -d: -f 1` - 2 ))
head -n $LINENUMBER int2.top > int3.top
grep "^ P " $TOP | awk '{gsub(/000    0.000/,"000    0.000"); gsub(/P /,"MG"); print}' >> int3.top
tail -n +$(( $LINENUMBER + 1 )) int2.top >> int3.top

# Set up include files
grep -A 1 moleculetype $TOP > MG.itp
echo "MG        3" >> MG.itp
echo "" >> MG.itp
grep -A 1 "atoms" $TOP >> MG.itp
echo "     1  MG       1  MG   MG       1   2.000   1.000" >> MG.itp
echo "" >> MG.itp
grep -A 1 "system" $TOP >> MG.itp
echo "MG" >> MG.itp
cp MG.itp $DIROUT

LINENUMBER=$(( `grep -n " molecules " int3.top | cut -d: -f 1` - 2 ))
head -n $LINENUMBER int3.top > int4.top
echo -e '\n#include "MG.itp"' >> int4.top
tail -n +$(( $LINENUMBER + 1 )) int3.top >> int4.top
echo "MG  $MGIONS" >> int4.top

# Double bond and angle strengths
awk 'BEGIN {bond=0} {{if ($1=="["){bond=0}} {if ($2=="bonds"){bond=1}} {if (bond) {gsub(/0.200000000E/,"0.400000000E",$0)}} print $0}' int4.top > int5.top
awk 'BEGIN {ang=0} {{if ($1=="["){ang=0}} {if ($2=="angles"){ang=1}} {if (ang) {gsub(/0.400000000E/,"0.800000000E",$0)}} print $0}' int5.top > int6.top

# # Set C12 to 1, so I can use the values in the tables. (C12 in the topology files is multiplied by the tables)
# sed "s/0.596046448E-09/1.000/g" int6.top > int7.top
# That Breaks the contacts

cp int6.top $TOPOUT

# Set up index file
echo -e 'keep 0\n! a MG\nname 1 RNA\na MG\nname 2 MG\nq\n' > input
OPTIONS=""
FILES="-f $GROUT -o $NDX"
cat input | $GD/make_ndx $OPTIONS $FILES
rm input

# Debye Huckel Interaction table
awk 'BEGIN {for (i=0; i<0.02; i+=0.002) print i}' | awk '{printf "%17.10e    %17.10e    %17.10e    %17.10e    %17.10e    %17.10e    %17.10e\n", $1, 0, 0, 0, 0, 0, 0}' > Table_DebyeHuckel1.xvg
awk 'BEGIN {for (i=0.02; i<=35.0; i+=0.002) print i}' | awk 'BEGIN {EPS=80*(300/80); DL='$DL'; RR='$rMGMG'; SIG0=0.596046448E-09} {EXPR=1/EPS*exp(-$1/DL); DLINV=1/DL; RINV=1/$1; RATIO=(RR/$1); R3=RATIO*RATIO*RATIO; R6=R3*R3; R12=R6*R6; printf "%17.10e    %17.10e    %17.10e    %17.10e    %17.10e    %17.10e    %17.10e\n", $1, EXPR*RINV, EXPR*RINV*(RINV+DLINV), 0, 0, R12/SIG0, 12*R12*RINV/SIG0}' >> Table_DebyeHuckel1.xvg
cp Table_DebyeHuckel1.xvg $DIROUT/table_MG_MG.xvg

# Debye Huckel Interaction table
awk 'BEGIN {for (i=0; i<0.02; i+=0.002) print i}' | awk '{printf "%17.10e    %17.10e    %17.10e    %17.10e    %17.10e    %17.10e    %17.10e\n", $1, 0, 0, 0, 0, 0, 0}' > Table_DebyeHuckel2.xvg
# awk 'BEGIN {for (i=0.02; i<=35.0; i+=0.002) print i}' | awk 'BEGIN {EPS=80*(300/80); DL='$DL'; RR='$rMGRNA'; SIG0=0.596046448E-09} {EXPR=1/EPS*exp(-$1/DL); DLINV=1/DL; RINV=1/$1; RATIO=(RR/$1); R3=RATIO*RATIO*RATIO; R6=R3*R3; R12=R6*R6; printf "%17.10e    %17.10e    %17.10e    %17.10e    %17.10e    %17.10e    %17.10e\n", $1, EXPR*RINV, EXPR*RINV*(RINV+DLINV), 0, 0, R12/SIG0, 12*R12*RINV/SIG0}' >> Table_DebyeHuckel2.xvg
awk 'BEGIN {for (i=0.02; i<=35.0; i+=0.002) print i}' | awk 'BEGIN {EPS=80*(300/80)/'$RNA_RESCALE'; DL='$DL'; RR='$rMGRNA'; SIG0=0.596046448E-09} {EXPR=1/EPS*exp(-$1/DL); DLINV=1/DL; RINV=1/$1; RATIO=(RR/$1); R3=RATIO*RATIO*RATIO; R6=R3*R3; R12=R6*R6; printf "%17.10e    %17.10e    %17.10e    %17.10e    %17.10e    %17.10e    %17.10e\n", $1, EXPR*RINV, EXPR*RINV*(RINV+DLINV), 0, 0, R12/SIG0, 12*R12*RINV/SIG0}' >> Table_DebyeHuckel2.xvg
cp Table_DebyeHuckel2.xvg $DIROUT/table_RNA_MG.xvg

# Non-interacting table
awk 'BEGIN {for (i=0; i<0.02; i+=0.002) print i}' | awk '{printf "%17.10e    %17.10e    %17.10e    %17.10e    %17.10e    %17.10e    %17.10e\n", $1, 0, 0, 0, 0, 0, 0}' > Table_NonInteracting.xvg
awk 'BEGIN {for (i=0.02; i<=35.0; i+=0.002) print i}' | awk 'BEGIN {EPS=80*(300/80); DL='$DL'; RR='$rRNARNA'; SIG0=0.596046448E-09} {EXPR=1/EPS*exp(-$1/DL); DLINV=1/DL; RINV=1/$1; RATIO=(1/$1); R3=RATIO*RATIO*RATIO; R6=R3*R3; R12=R6*R6; printf "%17.10e    %17.10e    %17.10e    %17.10e    %17.10e    %17.10e    %17.10e\n", $1, 0, 0, -R6, -6*R6*RINV, R12, 12*R12*RINV}' >> Table_NonInteracting.xvg
cp Table_NonInteracting.xvg $DIROUT/table.xvg

if [ $CLEANUP == "Y" ]
then
    rm int*
    rm \#*
fi

done
