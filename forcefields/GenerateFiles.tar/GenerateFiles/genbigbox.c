/* Written by Ryan Hayes 2013-03-21 to generate a big box of ions, and not take forever doing is like genbox */
/* Example Call genbigbox.cex ARibo.gro MG.gro ARibo_MG1e-8.gro 20 0.35 */

#include <math.h>
#include <stdio.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXCHAR 4096

int mod (int a, int b);

int main(int argc, char *argv[]) {
    FILE *GROIN, *IONIN, *GROUT;
    char fngroin[MAXCHAR], fnionin[MAXCHAR], fngrout[MAXCHAR];
    char line[MAXCHAR], boxline[MAXCHAR], field[MAXCHAR];
    int i, j, k, l;
    int N_i; // Number of ions
    int N_in, N_out, N_ia, N_apm, N_added; // Atoms in input, Atoms in output, Ion atoms, Atoms per ion
    double CUTOFF, CUTOFF2;
    int ****indices, **i_ijk;
    int ***numindices,***allocindices, *ni_ijk, *ai_ijk;
    int allocblock=20;
    char **Is;
    double *Ix,*Iy,*Iz,*OUTx,*OUTy,*OUTz;
    int CUR_a,CUR_r;
    double XBOX,YBOX,ZBOX,MINBOX,dx,dy,dz;
    int dimbin=20;
    int xx, yy, zz, xxmin,yymin,zzmin,xxmax,yymax,zzmax;
    int icont,jcont,kcont,addflag;
    double PROPx,PROPy,PROPz; // Proposed ion coordinate
    double dx_l, dy_l, dz_l, dr2_l;
    int INDECPLACE, F[6], FW[6];
    
    // Save input file name
    strncpy(fngroin,argv[1],MAXCHAR);
    GROIN=fopen(fngroin,"r");
    // Save ion file name
    strncpy(fnionin,argv[2],MAXCHAR);
    IONIN=fopen(fnionin,"r");
    // Save output file name
    strncpy(fngrout,argv[3],MAXCHAR);
    GROUT=fopen(fngrout,"w");
    // Save number of ions
    sscanf(argv[4],"%d",&N_i);
    // Save the cutoff
    sscanf(argv[5],"%lg",&CUTOFF);
    CUTOFF2=CUTOFF*CUTOFF;

    // Title line
    fgets(line,MAXCHAR,GROIN);
    fprintf(GROUT,"%s",line);
    fgets(line,MAXCHAR,IONIN);

    // Number of atoms
    fgets(line,MAXCHAR,GROIN);
    sscanf(line,"%d",&N_in);
    fgets(line,MAXCHAR,IONIN);
    sscanf(line,"%d",&N_apm);
    N_ia=N_i*N_apm;
    N_out=N_in+N_ia;
    fprintf(GROUT,"%d\n",N_out);

    // Read ion file
    Is=calloc(N_apm,sizeof(char*));
    Ix=calloc(N_apm,sizeof(double));
    Iy=calloc(N_apm,sizeof(double));
    Iz=calloc(N_apm,sizeof(double));
    for (i=0; i<N_apm; i++) {
        Is[i]=calloc(11,sizeof(char));
        Is[i][10]='\0';
        fgets(line,MAXCHAR,IONIN);
        sscanf(line,"%*5d%10c%*5d%8lg%8lg%8lg",&Is[i][0],&Ix[i],&Iy[i],&Iz[i]);
    }

    // Read input file
    OUTx=calloc(N_out,sizeof(double));
    OUTy=calloc(N_out,sizeof(double));
    OUTz=calloc(N_out,sizeof(double));
    for (i=0; i<N_in; i++) {
        fgets(line,MAXCHAR,GROIN);
        if (i==0) {
            // Setup field widths
            fprintf(stderr,"Warning: Guessing at field width indicators\n");
            FW[0]=FW[2]=5; //Guess
            FW[1]=10;
            INDECPLACE=3; //Guess
            FW[3]=FW[4]=FW[5]=8; //Guess
            F[0]=0;
            for (j=1;j<6;j++) {
                F[j]=F[j-1]+FW[j-1];
            }
            fprintf(stderr,"%s",line);
            fprintf(stderr,"dddddssssssssssddddd ggg.ggg ggg.ggg ggg.ggg\n");
        }
        fprintf(GROUT,"%s",line);
        // sscanf(line,"%5d %*10c %5d %8.3lg %8.3lg %8.3lg",&CUR_r,&CUR_a,&OUTx[i],&OUTy[i],&OUTz[i]);
        // sscanf(line,"%5d%*10c%5d%8lg%8lg%8lg",&CUR_r,&CUR_a,&OUTx[i],&OUTy[i],&OUTz[i]);
        strncpy(field,&line[F[0]],FW[0]);
        field[FW[0]]='\0';
        sscanf(field,"%d",&CUR_r);
        strncpy(field,&line[F[2]],FW[2]);
        field[FW[2]]='\0';
        sscanf(field,"%d",&CUR_a);
        strncpy(field,&line[F[3]],FW[3]);
        field[FW[3]]='\0';
        sscanf(field,"%lg",&OUTx[i]);
        strncpy(field,&line[F[4]],FW[4]);
        field[FW[4]]='\0';
        sscanf(field,"%lg",&OUTy[i]);
        strncpy(field,&line[F[5]],FW[5]);
        field[FW[5]]='\0';
        sscanf(field,"%lg",&OUTz[i]);
    }
    // fflush(GROUT); //DEBUG

    // Read box size, and set up bins
    fgets(boxline,MAXCHAR,GROIN);
    sscanf(boxline,"%lg %lg %lg",&XBOX,&YBOX,&ZBOX);
    MINBOX= XBOX>YBOX ? YBOX : XBOX;
    MINBOX= MINBOX>ZBOX ? ZBOX : MINBOX;
    if (MINBOX<(((double) dimbin)*CUTOFF)) {
        fprintf(stderr,"Warning, cutoff is too large, box is too small, or code requires revision\n");
    }
    if (N_apm>1) {
        fprintf(stderr,"Warning, genbox is not written to deal with ions containing multiple ions. Please revise code\n");
    }
    dx=(XBOX/((double) dimbin));
    dy=(YBOX/((double) dimbin));
    dz=(ZBOX/((double) dimbin));
    indices=calloc(dimbin,sizeof(int***));
    numindices=calloc(dimbin,sizeof(int**));
    allocindices=calloc(dimbin,sizeof(int**));
    for (i=0;i<dimbin;i++) {
        indices[i]=calloc(dimbin,sizeof(int**));
        numindices[i]=calloc(dimbin,sizeof(int*));
        allocindices[i]=calloc(dimbin,sizeof(int*));
        for (j=0;j<dimbin;j++) {
            indices[i][j]=calloc(dimbin,sizeof(int*));
            numindices[i][j]=calloc(dimbin,sizeof(int));
            allocindices[i][j]=calloc(dimbin,sizeof(int));
            for (k=0;k<dimbin;k++) {
                indices[i][j][k]=calloc(allocblock,sizeof(int));
                allocindices[i][j][k]=allocblock;
            }
        }
    }
    fclose(GROIN);
    fclose(IONIN);

    // Place original IN atoms in bins
    for (i=0; i<N_in; i++) {
        xx=(((int) floor(OUTx[i]/dx)) % dimbin);
        yy=(((int) floor(OUTy[i]/dy)) % dimbin);
        zz=(((int) floor(OUTz[i]/dz)) % dimbin);
        i_ijk=&indices[xx][yy][zz];
        ni_ijk=&numindices[xx][yy][zz];
        ai_ijk=&allocindices[xx][yy][zz];
        if (ni_ijk[0]==ai_ijk[0]) {
            i_ijk[0]=realloc(i_ijk[0],(ai_ijk[0]+dimbin)*sizeof(int));
            ai_ijk[0]+=dimbin;
        }
        i_ijk[0][ni_ijk[0]]=i;
        ni_ijk[0]++;
    }

    // Begin attempting to add atoms
    N_added=0;
    fprintf(stderr,"Warning: No provision for escaping loop if box fills\n");
    while (N_added<N_i) {
        PROPx=XBOX * ((double) rand())/((double) RAND_MAX);
        PROPy=YBOX * ((double) rand())/((double) RAND_MAX);
        PROPz=ZBOX * ((double) rand())/((double) RAND_MAX);
        // xxmin=(((int) floor((PROPx-CUTOFF)/dx)) % dimbin);
        // yymin=(((int) floor((PROPy-CUTOFF)/dy)) % dimbin);
        // zzmin=(((int) floor((PROPz-CUTOFF)/dz)) % dimbin);
        // xxmax=(((int) floor((PROPx+CUTOFF)/dx)) % dimbin);
        // yymax=(((int) floor((PROPy+CUTOFF)/dy)) % dimbin);
        // zzmax=(((int) floor((PROPz+CUTOFF)/dz)) % dimbin);
        xxmin=mod(((int) floor((PROPx-CUTOFF)/dx)) , dimbin);
        yymin=mod(((int) floor((PROPy-CUTOFF)/dy)) , dimbin);
        zzmin=mod(((int) floor((PROPz-CUTOFF)/dz)) , dimbin);
        xxmax=mod(((int) floor((PROPx+CUTOFF)/dx)) , dimbin);
        yymax=mod(((int) floor((PROPy+CUTOFF)/dy)) , dimbin);
        zzmax=mod(((int) floor((PROPz+CUTOFF)/dz)) , dimbin);
        // fprintf(stderr,"Ready to enter first bin\n"); //DEBUG
        icont=1;
        addflag=1; // Try to falsify, if it's still one after loops, add PROP
        for (i=xxmin; (icont && addflag); i=((i+1) % dimbin)) {
            jcont=1;
            for (j=yymin; (jcont && addflag); j=((j+1) % dimbin)) {
                kcont=1;
                for (k=zzmin; (kcont && addflag); k=((k+1) % dimbin)) {
                    // run over all atoms in this bin
                    // fprintf(stderr,"Looping over atoms in bin %d %d %d\n",i,j,k); //DEBUG
                    ni_ijk=&numindices[i][j][k];
                    i_ijk=&indices[i][j][k];
                    for (l=0; ((l<ni_ijk[0]) && addflag); l++) {
                        // fprintf(stderr,"Checking atom %d\n",i_ijk[0][l]); //DEBUG
                        dx_l=(PROPx-OUTx[i_ijk[0][l]]);
                        if ((dx_l<=CUTOFF) && (dx_l>=(-CUTOFF))) {
                            dy_l=(PROPy-OUTy[i_ijk[0][l]]);
                            if ((dy_l<=CUTOFF) && (dy_l>=(-CUTOFF))) {
                                dz_l=(PROPz-OUTz[i_ijk[0][l]]);
                                if ((dz_l<=CUTOFF) && (dz_l>=(-CUTOFF))) {
                                    dr2_l = dx_l*dx_l + dy_l*dy_l + dz_l*dz_l;
                                    if (dr2_l<CUTOFF2) {
                                        addflag=0;
                                    }
                                }
                            }
                        }
                    }
                    kcont=(k==zzmax ? 0 : 1);
                }
                jcont=(j==yymax ? 0 : 1);
            }
            icont=(i==xxmax ? 0 : 1);
        }
        // Add in the ion if indicated
        if (addflag) {
            fprintf(stderr,"%d of %d\n",N_added,N_i);
            N_added++;
            CUR_r++;
            // Loop here if adding multiple atoms per ion residue
            OUTx[CUR_a]=PROPx;
            OUTy[CUR_a]=PROPy;
            OUTz[CUR_a]=PROPz;
            xx=(((int) floor(OUTx[CUR_a]/dx)) % dimbin);
            yy=(((int) floor(OUTy[CUR_a]/dy)) % dimbin);
            zz=(((int) floor(OUTz[CUR_a]/dz)) % dimbin);
            i_ijk=&indices[xx][yy][zz];
            ni_ijk=&numindices[xx][yy][zz];
            ai_ijk=&allocindices[xx][yy][zz];
            if (ni_ijk[0]==ai_ijk[0]) {
                i_ijk[0]=realloc(i_ijk[0],(ai_ijk[0]+dimbin)*sizeof(int));
                ai_ijk[0]+=dimbin;
            }
            i_ijk[0][ni_ijk[0]]=CUR_a;
            ni_ijk[0]++;
            CUR_a+=N_apm;
            fprintf(GROUT,"%5d%10s%5d%8.3f%8.3f%8.3f\n",CUR_r,Is[0],CUR_a,PROPx,PROPy,PROPz);
            // End Loop here
        }
    }

    // Print box size and exit
    fprintf(GROUT,"%s",boxline);
    fclose(GROUT);
}

// From http://stackoverflow.com/questions/4003232/how-to-code-a-modulo-operator-in-c-c-obj-c-that-handles-negative-numbers
int mod (int a, int b)
{
   int ret;
   ret = a % b;
   if(ret < 0) {
     ret+=b;
   }
   return ret;
}
