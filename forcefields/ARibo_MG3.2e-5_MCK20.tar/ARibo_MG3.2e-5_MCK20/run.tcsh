#! /bin/tcsh
# Run grompp and mdrun to submit this job. Written by Ryan Hayes

# Must use double precision, or rounding errors will lead to system heating for the largest boxes.
setenv GROMDIR "/users/ryahayes/Programs/gromacs-4.6.1C/double/bin"
set SYS=ARibo_MG3.2e-5_MCK20

# Setup simulation parameters
set STEPSSUB=250000 # 250 ps
set LOGSUB=5000 # Jeff uses 1000 online, Paul uses 4000
set TAUSUB=2.0 # McCammon's value in water is 0.0167 ps (Divide by 2 because of mass and energy rescaling) We use underdamping to enhance sampling.
set TEMP=80

# Assign the names of the input and output files
set DIR=`pwd`
set MDP="$DIR/q6sbm.mdp" #Molecular Dynamics Parameters
set GRO="$DIR/$SYS.gro" #Input file to grompp
set TOP="$DIR/$SYS.top" #Input file to grompp with potentials
set NDX="$DIR/$SYS.ndx"
cd $DIR

foreach T ($TEMP)

# Set up the temperature specific file names and folders
setenv TDIR "$DIR/${T}"
set MDPR="$TDIR/q6sbmraw.mdp" #Name for modified MDP file
set MDPT="$TDIR/q6sbm${T}.mdp" #Name for modified MDP file
set TPR="$TDIR/$SYS${T}.tpr" #Output file from grompp, input file to mdrun

# Switch into the temperature specific directory
mkdir $TDIR
cd $TDIR

# Replace the values in the MDP file with the appropriate parameters
cp $MDP $MDPR
echo "#define STEPSSUB $STEPSSUB" > $TDIR/options.imp
echo "#define LOGSUB $LOGSUB" >> $TDIR/options.imp
echo "#define TAUSUB $TAUSUB" >> $TDIR/options.imp
echo "#define TEMPSUB $T" >> $TDIR/options.imp
echo "#define T_SD" >> $TDIR/options.imp
cpp $MDPR $MDPT

# Compile the TPR file
$GROMDIR/grompp -c $GRO -p $TOP -n $NDX -f $MDPT -o $TPR -maxwarn 1 #Had to increase max warnings to 1 because there were too many atoms in a charge group.

setenv MDRUNFILES "-s $TPR -cpi state.cpt -cpo state.cpt -table $DIR/table.xvg -tablep $DIR/table.xvg"
# -noddcheck keeps pairs from breaking it within multithreading.
# -pd prevents dynamic load balancing from slowing the process down absurdly, even though it's slower on homogenous systems
setenv MDRUNOPTIONS "-noddcheck -pd -noappend"

# You will probably want to wrap this next line inside a file that you can submit with qsub. Make sure appropriate environment variables like the present working directory, $GROMDIR, $MDRUNFILES, and $MDRUNOPTIONS are passed.
$GROMDIR/mdrun $MDRUNFILES $MDRUNOPTIONS

# Switch back to original directory
cd $DIR

end
