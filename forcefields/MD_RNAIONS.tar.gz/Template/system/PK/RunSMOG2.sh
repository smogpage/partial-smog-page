#! /bin/bash

DIR=`pwd`

cd $DIR/../SMOG2_tigger/SMOG2/SMOG2
export SMOG_PATH=`pwd`
export PERLLIB=$PERLLIB:$SMOG_PATH
cd $DIR

cd $DIR/../SMOG2_tigger/SBM_PARMS
PARMSDIR=`pwd`

cd $DIR

PDB=$DIR/PK.pdb
GRO=$DIR/PK.gro
TOP=$DIR/PK.top

perl $SMOG_PATH/smog2 -i $PDB -tAA $PARMSDIR -o $TOP -g $GRO
