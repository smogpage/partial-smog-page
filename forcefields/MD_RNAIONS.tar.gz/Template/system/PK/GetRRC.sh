#! /bin/bash

TOP=PK.top
GRO=PK.gro
A2R=PK.a2r
AAC=PK.aac
# Redundant Res-Res Contacts
RRRC=PK.rrrc
RRC=PK.rrc
N=28

awk 'BEGIN{Np3=3}
{if (NR==2) {
  Np3=$1+3;
} else if (NR>2 && NR<Np3) {
  print substr($0,16,5),substr($0,1,5);
}}' $GRO > $A2R

awk 'BEGIN{READ=0}
{if (READ==0) {
  if ($2=="exclusions") {READ=1}
} else {
  READ++
  if (NF!=2) {READ=0}
  if (READ>2) {print $0}
}}' $TOP > $AAC

awk '{if (FILENAME=="'$A2R'") {
  R[$1]=$2;
} else {
  print R[$1],R[$2];
}}' $A2R $AAC > $RRRC

awk 'BEGIN{
  I=0;
  N='$N';
  for (i=1; i<=N; i++) {
    C[i]=0;
  }
} {
  if ($1>I) {
    for (i=1; i<=N; i++) {
      if (C[i]>0) {
        print I,i,C[i];
        C[i]=0;
      }
    }
    I=$1;
  }
  C[$2]++;
} END {
  for (i=1; i<=N; i++) {
    if (C[i]>0) {
      print I,i,C[i];
      C[i]=0;
    }
  }
}' $RRRC > $RRC
