// Written to try out different ion condensation competition models

/* Causes program to hang, so that the user can attach gdb for debugging
 * purposes. */
// #define DEBUG

/* Allows trivial parallization of several similar simulations. */
#define MPI

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#ifdef MPI
#include <mpi.h>
#endif
#include <omp.h>
#ifdef DEBUG
#include <signal.h>
#endif
#include <sys/time.h>
// #include <assert.h>

#define MAXLENGTH 4096
// 1 Molar in nm^-3
#define MOLAR 0.6022
#define DIM3 3
#define M_SQRT8PI3 sqrt(8*M_PI*M_PI*M_PI)

// Type Definitions
typedef double vec[3];

typedef unsigned long long gmx_cycles_t;

/* struct_collate allows data to be stored on NID nodes with openMP. The data is
 * stored in the array local[NID][N]. Only the entries from Ni (inclusive) to Nf
 * (exclusive) are used. The local values may be reset with
 * resetlocal_collate(collate,ID), or may be added together to populate the
 * array master[N] with sumlocal_collate(collate,ID)*/
typedef struct
{
  double *master;
  double **local;
  int N;
  int Ni;
  int Nf;
  int NID;
} struct_collate;

// WORKING COMMENT
typedef struct
{
  double N; // Number of coordinates, 3 times number of atoms
  double Ni; // atoms before this are frozen
  double Nf; // This and later atoms are frozen
  double *x;
  double *shift;
  double *v;
  struct_collate *f;
  double *m;
  double *msqrt;
  double *Vs_delay;
} struct_atoms;

typedef void (*potfunc)(double,double,double,double,double,double*,double*);

typedef enum {
  eT_DH00,
  eT_DH01,
  eT_DH02,
  eT_DH11,
  eT_DH12,
  eT_DH22,
  eT_G1,
  eT_G2,
  eT_MAX
} eTABLE;

typedef struct
{
  double A0; // Vi
  double A1; // -h*Fi
  double A2; // 3*(Vi1-Vi+h*Fi)+(h*Fi1-h*Fi)
  double A3; // -2*(Vi1-Vi+h*Fi)-(h*Fi1-h*Fi)
} struct_point;

typedef struct
{
  struct_point (*point)[eT_MAX]; // Debye Huckel
  double hinv; // inverse spacing [nm^-1]
  int N; // number of entries
} struct_tables;

typedef struct sortatom
{
  int index;
  int bin[3];
  long long lbin;
  struct sortatom *pless;
  struct sortatom *pmore;
  int nless;
  int nmore;
} struct_sortatom;

typedef struct
{
  double r;
  vec dr;
  double Eij[eT_MAX];
  double Frij[eT_MAX];
} struct_nldata;

typedef struct
{
// First index is particle i
  int *ii;
  int iimax; // Number of atoms
  int *iitype;
  int **jj; // jj[i][0] inclusive to jj[i][jjmax[i]] exclusive contains the neighbors of atom ii[i]. ij neighbor pairs are listed under i OR j, but not both.
  int *jjmax;// *jjind;
  int *jjsize; // number of entries available in jj
  vec **shiftij;
  struct_nldata **nldata;
  struct_sortatom *sort;
// First index is neither
  int *div; // int vector - box divisions in each direction
  double **rc2;
// First index is number of nodes
  int **checklist;
  vec **shiftlist;
  gmx_cycles_t *cycles_sort;
  gmx_cycles_t *cycles_check;
  gmx_cycles_t *cycles_force;
  gmx_cycles_t *cumcycles_sort;
  gmx_cycles_t *cumcycles_check;
  gmx_cycles_t *cumcycles_check1;
  gmx_cycles_t *cumcycles_check2;
  gmx_cycles_t *cumcycles_force;
  int *imin;
  int *imax;
  int *imin_f;
  int *imax_f;
} struct_nlist;

typedef struct
{
  unsigned long *mt; /* the array for the state vector  */
  int mti; /* mti==N+1 means mt[N] is not initialized */
} struct_mtstate;

typedef struct
{
  int *qlist;
  int nqlist;
  int nqlist_th;
  double *x;
  double *theta;
  double *theta_cl;
  double *eta;
  double *eta_cl;
  double *bP;
  struct_collate *condens_tk;
  struct_collate *condens_tcl;
  struct_collate *condens_ek;
  struct_collate *condens_ecl;
  double *dens_tk;
  double *dens_tcl;
  double *dens_ek;
  double *dens_ecl;
  struct_collate *pot_t;
  struct_collate *pot_e;
  struct_collate *V1eff_inv;
  struct_collate *V2eff_inv;
  double *dGsoftdt_tk;
  double *dGsoftdt_tcl;
  double *dGsoftde_ek;
  double *dGsoftde_ecl;
  double *G;
  double *dGdtk;
  double *dGdtcl;
  double *dGdek;
  double *dGdecl;
  double *dGdtpot;
  double *dGdepot;
  double *dGdV1;
  double *dGdV2;
} struct_qlist;

typedef struct
{
  double dt;
  double gamma;
  double kT;
  double mDiff;
  double SigmaVsVs;
  double XsVsCoeff;
  double CondSigmaXsXs;
  double SigmaVrVr;
  double XrVrCoeff;
  double CondSigmaXrXr;
  double v_vscale;
  double v_ascale;
  double v_Vsscale;
  double x_vscale;
  double x_Xrscale;
} struct_leapparms;

typedef struct
{
  int i;
  int j;
  double k0;
  double r0;
} struct_bondparms;

typedef struct
{
  int i;
  int j;
  int k;
  double k0;
  double t0;
} struct_angleparms;

typedef struct
{
  int i;
  int j;
  int k;
  int l;
  double k0;
  double p0;
  double n;
} struct_dihparms;

typedef struct
{
  int i;
  int j;
  double C6;
  double C12;
} struct_pairparms;

typedef struct
{ // i is assumed by index of pointer.
  int *j;
  int N[3];
  int Nmax;
} struct_exclparms;

typedef struct
{
  int id;
  int offset;
  int flexible; // boolean flag
  double kB;
  double kT;
  double kTr;
  double kT0;
  double kTr0;
  double lB;
  double conc_KCl;
  double conc_K;
  double conc_Cl;
  int arg_N_mg;
  double arg_box;
  char *arg_topfile;
  char *arg_xyzqfile;
  double kappa;
  double gauss_00;
  double gauss_01;
  double gauss_02;
  double gauss_11;
  double gauss_12;
  double gauss_22;
  double V1;
  double V2;
  double k_prohibit;
  double k_soft;
  double rcelec;
  struct_tables *elec_tables;
  double k12;
  double s2[2][2];
  double rcother;
  int t_output;
  int t_ns;
  int anneal1lim;
  int anneal2lim;
  int steplim;
  double dt;
  struct_leapparms *leapparms;
  struct_leapparms *leapparms_anneal1;
  struct_leapparms *leapparms_anneal2;
  struct_leapparms *leapparms_mcc;
  int N_bond;
  int N_angle;
  int N_dih;
  int N_pair;
  int N_excl;
  struct_bondparms *bondparms;
  struct_angleparms *angleparms;
  struct_dihparms *dihparms;
  struct_pairparms *pairparms;
  struct_exclparms *exclparms;
} struct_parms;

typedef struct
{
  int step;
  vec box;
  double *x; // DIM3*N_fixed coordinates followed by DIM3*N_free coordinates
  double *shift;
  double *q;
  int N_fixed;
  int N_free;
  int N_rna;
  int N_mg;
  int N_all;
  struct_qlist *qqlist;
  struct_atoms *atoms;
  struct_collate *Gt;
  struct_collate *Kt;
  struct_atoms *manningcc_tk;
  struct_atoms *manningcc_tcl;
  struct_atoms *manningcc_ek;
  struct_atoms *manningcc_ecl;
  struct_nlist *nlelec;
  struct_nlist *nlother;
  struct_mtstate **mtstate;
} struct_state;

typedef enum {
  eF_log,
  eF_gro,
  eF_theta,
  eF_theta_cl,
  eF_eta,
  eF_eta_cl,
  eF_Gt,
  eF_Kt,
  eF_pot_t,
  eF_pot_e,
  eF_dens_tk,
  eF_dens_tcl,
  eF_dens_ek,
  eF_dens_ecl,
  eF_V1eff_inv,
  eF_V2eff_inv,
//  eF_loclog,
//  eF_locend=eF_loclog+7,
// Example usage:
// fprintf(md->files->fps[eF_loclog+omp_get_thread_num()],"Node %d, step %d, cycle %lld, before barrier, line %d\n",omp_get_thread_num(),md->state->step,gmx_cycles_read(),__LINE__);
  eF_MAX
} eFILE;

typedef struct
{
  FILE **fps;
  int N;
} struct_files;

typedef struct
{
  gmx_cycles_t start;
  gmx_cycles_t stop;
  gmx_cycles_t nsearch;
  gmx_cycles_t force;
  gmx_cycles_t update;
  gmx_cycles_t write;
  double secpcyc;
} struct_times;

typedef struct
{
  struct_parms *parms;
  struct_state *state;
  struct_files *files;
  struct_times *times;
} struct_md;


#ifdef MPI
#ifdef DEBUG
void arrested_development(void) {
  int i, id=0, nid=1;
  char hostname[200];
  MPI_Comm_rank(MPI_COMM_WORLD,&id);
  MPI_Comm_size(MPI_COMM_WORLD,&nid);
  for (i=0; i<nid; i++) {
    MPI_Barrier(MPI_COMM_WORLD);
    if (i==id) {
      gethostname(hostname,200);
      fprintf(stderr,"PID %d rank %d host %s\n",getpid(),id,hostname);
    }
    MPI_Barrier(MPI_COMM_WORLD);
  }
  raise(SIGSTOP); // Identical behavior, uncatchable.
}
#endif
#endif


// Math
void vec_subtract(vec a,vec b,vec c)
{
  c[0]=a[0]-b[0];
  c[1]=a[1]-b[1];
  c[2]=a[2]-b[2];
}


void vec_subpbc(vec a,vec b,vec box,vec c)
{
  int i;
  for (i=0; i<DIM3; i++) {
    c[i]=a[i]-b[i];
    c[i]-=box[i]*floor(c[i]/box[i]+0.5);
  }
}


void vec_subsaveshift(vec a,vec b,vec box,vec shift,vec c)
{
  int i;
  for (i=0; i<DIM3; i++) {
    c[i]=a[i]-b[i];
    shift[i]=-box[i]*floor(c[i]/box[i]+0.5);
    c[i]+=shift[i];
  }
}


void vec_subshift_ns(vec a,vec b,vec sab,vec c) {
  c[0]=a[0]-b[0]+sab[0];
  c[1]=a[1]-b[1]+sab[1];
  c[2]=a[2]-b[2]+sab[2];
}


void vec_subshift(vec a,vec b,vec sa,vec sb,vec sab,vec c) {
  c[0]=a[0]+sa[0]-b[0]-sb[0]+sab[0];
  c[1]=a[1]+sa[1]-b[1]-sb[1]+sab[1];
  c[2]=a[2]+sa[2]-b[2]-sb[2]+sab[2];
}


void vec_subquick(vec a,vec b,vec box,vec c)
{
  int i;
  for (i=0; i<DIM3; i++) {
    c[i]=a[i]-b[i];
    c[i]-=box[i]*((c[i]>box[i]/2)-(c[i]<-box[i]/2));
  }
}


double vec_quickdist2(vec a,vec b,vec box)
{
  int i;
  double c,s=0;
  for (i=0; i<DIM3; i++) {
    c=a[i]-b[i];
    c-=box[i]*((c>box[i]/2)-(c<-box[i]/2));
    s+=c*c;
  }
  return s;
}


double vec_shiftdist2(vec a,vec b,vec shift)
{
  int i;
  double c,s=0;
  for (i=0; i<DIM3; i++) {
    c=a[i]-b[i]+shift[i];
    s+=c*c;
  }
  return s;
}


double vec_mag(vec a)
{
  return sqrt(a[0]*a[0]+a[1]*a[1]+a[2]*a[2]);
}


double vec_mag2(vec a)
{
  return a[0]*a[0]+a[1]*a[1]+a[2]*a[2];
}


double vec_dot(vec a,vec b)
{
  return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
}


void vec_cross(vec a,vec b,vec c)
{
  c[0]=a[1]*b[2]-a[2]*b[1];
  c[1]=a[2]*b[0]-a[0]*b[2];
  c[2]=a[0]*b[1]-a[1]*b[0];
}


void vec_add(vec a,vec b,vec c)
{
  c[0]=a[0]+b[0];
  c[1]=a[1]+b[1];
  c[2]=a[2]+b[2];
}


void vec_scale(vec a,double f,vec x)
{
  a[0]=f*x[0];
  a[1]=f*x[1];
  a[2]=f*x[2];
}


void vec_inc(vec a,vec x)
{
  a[0]+=x[0];
  a[1]+=x[1];
  a[2]+=x[2];
}


void vec_scaleinc(vec a,double f,vec x)
{
  a[0]+=f*x[0];
  a[1]+=f*x[1];
  a[2]+=f*x[2];
}


/*void vec_reset(vec a)
{
  a[0]=0;
  a[1]=0;
  a[2]=0;
}*/


void vec_copy(vec a,vec b)
{
  a[0]=b[0];
  a[1]=b[1];
  a[2]=b[2];
}


void ivec_copy(int* a,int* b)
{
  a[0]=b[0];
  a[1]=b[1];
  a[2]=b[2];
}


int ivec_eq(int* a,int* b)
{
  return a[0]==b[0] && a[1]==b[1] && a[2]==b[2];
}


// Timing
// Stealing gromacs counter
static __inline__ gmx_cycles_t gmx_cycles_read(void)
{
    /* x86 with GCC inline assembly - pentium TSC register */
    gmx_cycles_t   cycle;
    unsigned       low, high;

    __asm__ __volatile__("rdtsc" : "=a" (low), "=d" (high));

    cycle = ((unsigned long long)low) | (((unsigned long long)high)<<32);

    return cycle;
}


double gmx_cycles_calibrate(double sampletime)
{
    /*  generic implementation with gettimeofday() */
    struct timeval t1, t2;
    gmx_cycles_t   c1, c2;
    double         timediff, cyclediff;
    double         d = 0.1; /* Dummy variable so we don't optimize away delay lo
op */
    int            i;

    /* Start a timing loop. We want this to be largely independent
     * of machine speed, so we need to start with a very small number
     * of iterations and repeat it until we reach the requested time.
     *
     * We call gettimeofday an extra time at the start to avoid cache misses.
     */
    gettimeofday(&t1, NULL);
    gettimeofday(&t1, NULL);
    c1 = gmx_cycles_read();

    do
    {
        /* just a delay loop. To avoid optimizing it away, we calculate a number
         * that will underflow to zero in most cases. By conditionally adding it
         * to a result at the end it cannot be removed. n=10000 is arbitrary...
         */
        for (i = 0; i < 10000; i++)
        {
            d = d/(1.0+(double)i);
        }
        /* Read the time again */
        gettimeofday(&t2, NULL);
        c2       = gmx_cycles_read();
        timediff = (double)(t2.tv_sec-t1.tv_sec)+
            (double)(t2.tv_usec-t1.tv_usec)*1e-6;
    }
    while (timediff < sampletime);

    cyclediff = c2-c1;

    /* Add a very small result so the delay loop cannot be optimized away */
    if (d < 1e-30)
    {
        timediff += d;
    }

    /* Return seconds per cycle */
    return timediff/cyclediff;
}


// Load data
int read_xyzq(char *fnm,struct_state* state,int N)
{  
  FILE *fp;
  char s[MAXLENGTH];
  int i;

  fp=fopen(fnm,"r");

  if (N==0) {
    // Count the number of lines
    i=0;
    while (fgets(s,MAXLENGTH,fp) != NULL) {
      i++;
    }
  } else {
    // Read in the data
    i=0;
    while (fgets(s,MAXLENGTH,fp) != NULL) {
      sscanf(s,"%lg %lg %lg %lg",&(state->x[DIM3*i]),&(state->x[DIM3*i+1]),&(state->x[DIM3*i+2]),&(state->q[i]));
      state->x[DIM3*i]+=25; // CONST
      state->x[DIM3*i+1]+=25; // CONST
      state->x[DIM3*i+2]+=25; // CONST
      i++;
    }
  }
    
  fclose(fp);
  return i;
}


void gen_xyzq(struct_state* state)
{
  int i,j;
  int accept;
  vec dr;
  double r;
  double *x=state->x;
  double *q=state->q;
  double *box=state->box;

  for (i=state->N_rna; i<state->N_all; i++) {
    accept=0;
    while (accept==0) {
      accept=1;
      x[DIM3*i]  =box[0]*(((double) rand())/RAND_MAX);
      x[DIM3*i+1]=box[1]*(((double) rand())/RAND_MAX);
      x[DIM3*i+2]=box[2]*(((double) rand())/RAND_MAX);
      q[i]=2;
      for (j=0; j<i; j++) {
        vec_subpbc(x+DIM3*i,x+DIM3*j,box,dr);
        r=vec_mag(dr);
        if (r<0.3) { // CONST
          accept=0;
        }
      }
    }
  }
}


struct_collate* alloc_collate(int N,int Ni,int Nf)
{
  struct_collate *collate;
  int i;

  collate=malloc(sizeof(struct_collate));
  collate->N=N;
  collate->Ni=Ni;
  collate->Nf=Nf;
  collate->NID=omp_get_max_threads();
  collate->master=calloc(N,sizeof(double));
  collate->local=calloc(collate->NID,sizeof(double*));

  for (i=0; i<collate->NID; i++) {
    collate->local[i]=calloc(N,sizeof(double));
  }

  return collate;
}


double* resetlocal_collate(struct_collate* cl,int ID)
{
  int i;

  for (i=0; i<cl->N; i++) {
    cl->local[ID][i]=0;
  }

  return cl->local[ID];
}


double* sumlocal_collate(struct_collate* cl,int ID)
{
  int i,imin,imax,j;

  imin=cl->Ni+((cl->Nf-cl->Ni)*ID)/cl->NID;
  imax=cl->Ni+((cl->Nf-cl->Ni)*(ID+1))/cl->NID;

  for (i=imin; i<imax; i++) {
    cl->master[i]=0;
    for (j=0; j<cl->NID; j++) {
      cl->master[i]+=cl->local[j][i];
    }
  }

  return cl->master;
}


void free_collate(struct_collate* collate)
{
  int i;

  free(collate->master);
  for (i=0; i<collate->NID; i++) {
    free(collate->local[i]);
  }
  free(collate->local);
  free(collate);
}


/*void inittheta(struct_qlist* qqlist)
{
  int i;
  for (i=0; i<qqlist->nqlist; i++) {
    if (qqlist->bP[i]) {
      qqlist->theta[i]=0.76;
      qqlist->theta_cl[i]=0.76;
    }
  }
}*/


struct_qlist* alloc_qlist(struct_state* state)
{
  struct_qlist *qlist;
  int i,n,n_rna,n_th;

  qlist=malloc(sizeof(struct_qlist));

  n=0;
  for (i=0; i<state->N_rna; i++) {
    if (state->q[i] != 0) {
      n++;
    }
  }
  n_rna=n;
  for (i=state->N_rna; i<state->N_all; i++) {
    if (state->q[i] != 0) {
      n++;
    }
  }
  #ifdef MGTHETA
  // Condensation on Mg too
  n_th=n; // CONST
  #elif defined NOTHETA
  // Condensation on RNA only
  n_th=0; // CONST
  #else
  // Condensation on RNA only
  n_th=n_rna; // CONST
  #endif

  qlist->nqlist=n;
  qlist->nqlist_th=n_th;
  qlist->qlist=calloc(n,sizeof(int));
  qlist->x=calloc(DIM3*n,sizeof(double));
  qlist->theta=calloc(n,sizeof(double));
  qlist->theta_cl=calloc(n,sizeof(double));
  qlist->eta=calloc(n,sizeof(double));
  qlist->eta_cl=calloc(n,sizeof(double));
  qlist->bP=calloc(n,sizeof(double));
  qlist->condens_tk=alloc_collate(n,0,n_th);
  qlist->condens_tcl=alloc_collate(n,0,n_th);
  qlist->condens_ek=alloc_collate(n,0,n_th);
  qlist->condens_ecl=alloc_collate(n,0,n_th);
  qlist->dens_tk=calloc(n,sizeof(double));
  qlist->dens_tcl=calloc(n,sizeof(double));
  qlist->dens_ek=calloc(n,sizeof(double));
  qlist->dens_ecl=calloc(n,sizeof(double));
  qlist->pot_t=alloc_collate(n,0,n_th);
  qlist->pot_e=alloc_collate(n,0,n_th);
  qlist->V1eff_inv=alloc_collate(n,0,n_th);
  qlist->V2eff_inv=alloc_collate(n,0,n_th);
  qlist->dGsoftdt_tk=calloc(n,sizeof(double));
  qlist->dGsoftdt_tcl=calloc(n,sizeof(double));
  qlist->dGsoftde_ek=calloc(n,sizeof(double));
  qlist->dGsoftde_ecl=calloc(n,sizeof(double));
  qlist->G=calloc(n,sizeof(double));
  qlist->dGdtk=calloc(n,sizeof(double));
  qlist->dGdtcl=calloc(n,sizeof(double));
  qlist->dGdek=calloc(n,sizeof(double));
  qlist->dGdecl=calloc(n,sizeof(double));
  qlist->dGdtpot=calloc(n,sizeof(double));
  qlist->dGdepot=calloc(n,sizeof(double));
  qlist->dGdV1=calloc(n,sizeof(double));
  qlist->dGdV2=calloc(n,sizeof(double));

  n=0;
  for (i=0; i<state->N_all; i++) {
    if (state->q[i] != 0) {
      qlist->qlist[n]=i;
      qlist->bP[n] = (n<n_th);
      n++;
    }
  }

  return qlist;
}


void update_qlist(struct_qlist* qlist,struct_state* state)
{
  int i,j;
  for (i=0; i<qlist->nqlist; i++) {
    for (j=0; j<DIM3; j++) {
      qlist->x[DIM3*i+j]=state->x[DIM3*qlist->qlist[i]+j];
    }
  }
}


void reset_shifts(struct_md* md)
{
  int i,j;
  for (i=0; i<md->state->N_all; i++) {
    for (j=0; j<DIM3; j++) {
      md->state->shift[DIM3*i+j]=0;
    }
  }
}


void free_qlist(struct_qlist* qlist)
{
  free(qlist->qlist);
  free(qlist->x);
  free(qlist->theta);
  free(qlist->theta_cl);
  free(qlist->eta);
  free(qlist->eta_cl);
  free(qlist->bP);
  free_collate(qlist->condens_tk);
  free_collate(qlist->condens_tcl);
  free_collate(qlist->condens_ek);
  free_collate(qlist->condens_ecl);
  free(qlist->dens_tk);
  free(qlist->dens_tcl);
  free(qlist->dens_ek);
  free(qlist->dens_ecl);
  free_collate(qlist->pot_t);
  free_collate(qlist->pot_e);
  free_collate(qlist->V1eff_inv);
  free_collate(qlist->V2eff_inv);
  free(qlist->dGsoftdt_tk);
  free(qlist->dGsoftdt_tcl);
  free(qlist->dGsoftde_ek);
  free(qlist->dGsoftde_ecl);
  free(qlist->G);
  free(qlist->dGdtk);
  free(qlist->dGdtcl);
  free(qlist->dGdek);
  free(qlist->dGdecl);
  free(qlist->dGdtpot);
  free(qlist->dGdepot);
  free(qlist->dGdV1);
  free(qlist->dGdV2);

  free(qlist);
}


void Gauss00DH(double kT,double lB,double kappa,double sigma,double rij,double* U,double* F_r)
{
  *U=kT*lB/rij*exp(-kappa*rij);
  // Force divided by rij
  *F_r=(*U)*(kappa+1/rij)/rij;
}


void Gauss00DHwR(double kT,double lB,double kappa,double sigma,double rij,double* U,double* F_r)
{
  *U=kT*lB*(1/rij-0.5*kappa)*exp(-kappa*rij);
  // Force divided by rij
  *F_r=kT*lB*(1/rij/rij+kappa/rij-0.5*kappa*kappa)*exp(-kappa*rij)/rij;
}


void GaussDH(double kT,double lB,double kappa,double sigma,double rij,double* U,double* F_r)
{
  double Ap,bp,Bp,dAp,dBp,Am,bm,Bm,dAm,dBm;
  Ap=0.5*kT*lB/rij*exp(0.5*kappa*kappa*sigma*sigma+kappa*rij);
  Am=0.5*kT*lB/rij*exp(0.5*kappa*kappa*sigma*sigma-kappa*rij);
  dAp=(-1.0/rij+kappa)*Ap;
  dAm=(-1.0/rij-kappa)*Am;
  bp=(rij+kappa*sigma*sigma)/(sigma*sqrt(2));
  bm=(-rij+kappa*sigma*sigma)/(sigma*sqrt(2));
  Bp=1-erf(bp);
  Bm=1-erf(bm);
  dBp=-sqrt(2/M_PI)*exp(-bp*bp)/sigma;
  dBm=sqrt(2/M_PI)*exp(-bm*bm)/sigma;
  *U=-Ap*Bp+Am*Bm;
  // Force divided by rij
  *F_r=(Ap*dBp+dAp*Bp-Am*dBm-dAm*Bm)/rij;
}


void GaussDH0(double kT,double lB,double kappa,double sigma,double rij,double* U,double* F_r)
{
  *U=kT*lB*(-kappa*exp(0.5*kappa*kappa*sigma*sigma)*(1-erf(kappa*sigma/sqrt(2)))+sqrt(2/M_PI)/sigma);
  *F_r=0;
}


void GaussDHwR(double kT,double lB,double k,double s,double rij,double* U,double* F_r)
{
  double PF,ap,am,Ap,bp,Bp,dAp,dBp,Am,bm,Bm,dAm,dBm;
  PF=-0.5*kT*lB;
  ap=PF*exp(0.5*k*k*s*s+k*rij);
  am=PF*exp(0.5*k*k*s*s-k*rij);
  Ap=(0.5*k+(1.0+0.5*k*k*s*s)/rij)*ap;
  Am=(0.5*k-(1.0+0.5*k*k*s*s)/rij)*am;
  dAp= (-0.5*k*k-(1.0+0.5*k*k*s*s)*k/rij-(1.0+0.5*k*k*s*s)/rij/rij)*ap;
  dAm=-(-0.5*k*k+(1.0+0.5*k*k*s*s)*k/rij-(1.0+0.5*k*k*s*s)/rij/rij)*am;
  bp=( rij+k*s*s)/(s*sqrt(2));
  bm=(-rij+k*s*s)/(s*sqrt(2));
  Bp=1-erf(bp);
  Bm=1-erf(bm);
  dBp=-sqrt(2/M_PI)*exp(-bp*bp)/s;
  dBm= sqrt(2/M_PI)*exp(-bm*bm)/s;
  *U=Ap*Bp+Am*Bm;
  // Force divided by rij
  *F_r=-(Ap*dBp+dAp*Bp+Am*dBm+dAm*Bm)/rij;
}


void GaussDHwR0(double kT,double lB,double k,double s,double* U,double* F_r)
{
  *U=kT*lB*((1.0+0.5*k*k*s*s)*sqrt(2/M_PI)/s
    -k*(1.5+0.5*k*k*s*s)*exp(0.5*k*k*s*s)*(1-erf(k*s/sqrt(2))));
  *F_r=0;
}


void Gaussian(double kT,double lB,double k,double s,double rij,double* U,double* F_r)
{
  *U=1/(M_SQRT8PI3*s*s*s)*exp(-rij*rij/(2*s*s));
  *F_r=(*U)/(s*s);
}

void tables_interp(struct_tables* tabs,struct_nldata* data)
{
  double hinv=tabs->hinv;
  int i,t; // index, type
  double x,x2,x3;
  struct_point *p; // point

  i=((int) (data->r*hinv));
  p=tabs->point[i];
  x=data->r*hinv-i;
  x2=x*x;
  x3=x2*x;

  for (t=0; t<eT_MAX; t++) {
    data->Eij[t]=p[t].A0+x*p[t].A1+x2*p[t].A2+x3*p[t].A3;
    data->Frij[t]=(p[t].A1+2*x*p[t].A2+3*x2*p[t].A3)*(-hinv/data->r);
  }
}


// CONST
// Table extension
// Maximum distance particles are likely to move between neighbor searches
#define TABEXT 1.0

struct_tables* alloc_tables(double cut,struct_parms* parms)
{
  struct_tables *tables;
  double kT=parms->kT0;
  double lB=parms->lB;
  double kappa=parms->kappa;
  double hinv=1000.0; // CONST
  int N=((int) (hinv*(cut+TABEXT)))+2;
  double r,E,F,E1,F1;
  int i,j;

  potfunc f0[eT_MAX]={Gauss00DH,GaussDH0,GaussDH0,GaussDH0,GaussDH0,GaussDH0,Gaussian,Gaussian};
  potfunc f[eT_MAX]={Gauss00DH,GaussDH,GaussDH,GaussDH,GaussDH,GaussDH,Gaussian,Gaussian};
  double s[eT_MAX]={parms->gauss_00,parms->gauss_01,parms->gauss_02,parms->gauss_11,
    parms->gauss_12,parms->gauss_22,parms->gauss_01,parms->gauss_02};

  tables=malloc(sizeof(struct_tables));
  tables->hinv=hinv;
  tables->N=N;
  tables->point=calloc(N,sizeof(struct_point[eT_MAX]));

  for (i=0; i<eT_MAX; i++) {
    f0[i](kT,lB,kappa,s[i],0,&E1,&F1);
    F1*=0;
    for (j=0; j<N; j++) {
      r=(j+1)/hinv;
      E=E1;
      F=F1;
      f[i](kT,lB,kappa,s[i],r,&E1,&F1);
      F1*=r;
      tables->point[j][i].A0=E;
      tables->point[j][i].A1=-F/hinv;
      tables->point[j][i].A2=3*(E1-E+F/hinv)+(F1-F)/hinv;
      tables->point[j][i].A3=-2*(E1-E+F/hinv)-(F1-F)/hinv;
    }
  }

  return tables;
}


void free_tables(struct_tables* tables)
{
  free(tables->point);
  free(tables);
}


void calcABCD(double slambda,double* A,double* B,double* C,double* D)
{
  double sign,shlambda;
  sign = (slambda>0 ? 1.0 : -1.0);

  if ((slambda/sign)>0.12) {
    // V noise variance
    A[0]=sign*(exp(slambda)-1);
    // related to conditional variance
    B[0]=slambda*(exp(slambda)-1)-4*(exp(slambda/2)-1)*(exp(slambda/2)-1);
    // X noise variance
    C[0]=sign*(slambda-3+4*exp(-slambda/2)-exp(-slambda));
    // VX noise correlation
    D[0]=sign*(2-exp(slambda/2)-exp(-slambda/2));
  } else {
    shlambda=slambda/2;
    // Max As error: 2e-14 at shlambda=0.025; error(0.1)=3e-10
    // As=sign*(2*shlambda+2*shlambda^2+(4./3)*shlambda^3+(2./3)*shlambda^4+(4./15)*shlambda^5+(4./45)*shlambda^6+(8./315)*shlambda^7);
    A[0]=(8./315); // shl^7
    A[0]=(4./45)+A[0]*shlambda; // shl^6
    A[0]=(4./15)+A[0]*shlambda; // shl^5
    A[0]=(2./3)+A[0]*shlambda; // shl^4
    A[0]=(4./3)+A[0]*shlambda; // shl^3
    A[0]=2+A[0]*shlambda; // shl^2
    A[0]=2+A[0]*shlambda; // shl
    A[0]=sign*A[0]*shlambda;
    // Max Bs error: 2e-11 at shlambda=0.08; error(0.1)=1e-10
    // Bs=(1./3)*shlambda^4+(1./3)*shlambda^5+(17./90)*shlambda^6+(7./90)*shlambda^7+(43./1680)*shlambda^8+(107./15120)*shlambda^9+(769./453600)*shlambda^10;
    B[0]=(769./453600); // shl^10;
    B[0]=(107./15120)+B[0]*shlambda; // shl^9
    B[0]=(43./1680)+B[0]*shlambda; // shl^8
    B[0]=(7./90)+B[0]*shlambda; // shl^7
    B[0]=(17./90)+B[0]*shlambda; // shl^6
    B[0]=(1./3)+B[0]*shlambda; // shl^5
    B[0]=(1./3)+B[0]*shlambda; // shl^4
    B[0]=B[0]*shlambda*shlambda*shlambda*shlambda;
    // Max Ds error: 2e-14 at shlambda=0.12; error(0.1)=5e-14
    // Ds=sign*(-shlambda^2-(1./12)*shlambda^4-(1./360)*shlambda^6-(1./20160)*shlambda^8);
    D[0]=-(1./20160); // shl^8
    D[0]=-(1./360)+D[0]*shlambda*shlambda; // shl^6
    D[0]=-(1./12)+D[0]*shlambda*shlambda; // shl^4
    D[0]=-1+D[0]*shlambda*shlambda; // shl^2
    D[0]=sign*D[0]*shlambda*shlambda;
    // Best combined accuracy 1e-11 at shlambda=0.06, from semilogy(shlambda,max(max(abs(Ds1-Ds2)./Ds2,abs(Bs1-Bs2)./Bs2),abs(As1-As2)./As2))*/
  }
}


struct_leapparms* alloc_leapparms(double dt,double gamma,double kT)
{
  struct_leapparms *leapparms;
  double lambda;
  double As, Bs, Cs, Ds;
  double Ar, Br, Cr, Dr;

  leapparms=malloc(sizeof(struct_leapparms));

  // integrator from W. F. Van Gunsteren and H. J. C. Berendsen (1988)
  leapparms->dt=dt;
  leapparms->gamma=gamma;
  leapparms->kT=kT;
  leapparms->mDiff=kT/gamma; // Diffusion * Mass
  lambda=dt*gamma;
  // [t to t+dt/2]
  // Ar prop svv^2; Br=Ar*Cr-Dr^2; Cr prop sxx^2; Dr prop sxv^2
  calcABCD(lambda,&As,&Bs,&Cs,&Ds);
  // Eq 3.19
  leapparms->SigmaVsVs=sqrt(leapparms->mDiff*gamma*As);
  leapparms->XsVsCoeff=Ds/(gamma*As); // Equal to SigmaXsVs^2/SigmaVsVs^2
  leapparms->CondSigmaXsXs=sqrt((leapparms->mDiff/gamma)*Bs/As); // Equal to sqrt(SigmaXsXs^2-SigmaXsVs^4/SigmaVsVs^2)

  // [t+dt/2 to t+dt]
  calcABCD(-lambda,&Ar,&Br,&Cr,&Dr);
  leapparms->SigmaVrVr=sqrt(leapparms->mDiff*gamma*Ar);
  leapparms->XrVrCoeff=Dr/(gamma*Ar); // Equal to SigmaXrVr^2/SigmaVrVr^2
  leapparms->CondSigmaXrXr=sqrt((leapparms->mDiff/gamma)*Br/Ar); // Equal to sqrt(SigmaXrXr^2-SigmaXrVr^4/SigmaVrVr^2)

  // Eq 3.6
  leapparms->v_vscale=exp(-lambda);
  leapparms->v_ascale=dt*Ar/lambda;
  leapparms->v_Vsscale=-exp(-lambda);

  // Eq 3.10
  leapparms->x_vscale=dt*exp(lambda/2)*Ar/lambda;
  leapparms->x_Xrscale=-1;

  return leapparms;
}


void free_leapparms(struct_leapparms* leapparms)
{
  free(leapparms);
}


void topseek(char directive[],FILE *fp)
{
  char s[MAXLENGTH];
  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (strcmp(s,directive) == 0) {
      break;
    }
  }
}


int topbond(int bSave,struct_bondparms *bondparms,FILE *fp)
{
  char s[MAXLENGTH];
  int N=0;
  int i,j;
  double k0,r0;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d 1 %lg %lg",&i,&j,&r0,&k0)==4) {
      if (bSave) {
        bondparms[N].i=i-1;
        bondparms[N].j=j-1;
        bondparms[N].k0=k0;
        bondparms[N].r0=r0;
      }
      N++;
    } else {
      break;
    }
  }
  return N;
}


struct_bondparms* alloc_bondparms(int *N,char fnm[])
{
  struct_bondparms *bondparms;
  FILE *fp;
  int i;

  fp=fopen(fnm,"r");
  topseek("[ bonds ]\n",fp);
  *N=topbond(0,NULL,fp);
  fclose(fp);

  bondparms=calloc(*N,sizeof(struct_bondparms));

  fp=fopen(fnm,"r");
  topseek("[ bonds ]\n",fp);
  *N=topbond(1,bondparms,fp);
  fclose(fp);

  return bondparms;
}


int topangle(int bSave,struct_angleparms *angleparms,FILE *fp)
{
  char s[MAXLENGTH];
  int N=0;
  int i,j,k;
  double k0,t0;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d %d 1 %lg %lg",&i,&j,&k,&t0,&k0)==5) {
      if (bSave) {
        angleparms[N].i=i-1;
        angleparms[N].j=j-1;
        angleparms[N].k=k-1;
        angleparms[N].k0=k0;
        angleparms[N].t0=(M_PI/180)*t0;
      }
      N++;
    } else {
      break;
    }
  }
  return N;
}


struct_angleparms* alloc_angleparms(int *N,char fnm[])
{
  struct_angleparms *angleparms;
  FILE *fp;
  int i;

  fp=fopen(fnm,"r");
  topseek("[ angles ]\n",fp);
  *N=topangle(0,NULL,fp);
  fclose(fp);

  angleparms=calloc(*N,sizeof(struct_angleparms));

  fp=fopen(fnm,"r");
  topseek("[ angles ]\n",fp);
  *N=topangle(1,angleparms,fp);
  fclose(fp);

  return angleparms;
}


int topdih(int bSave,struct_dihparms *dihparms,FILE *fp)
{
  char s[MAXLENGTH];
  int N=0;
  int i,j,k,l,ty,n;
  double k0,p0;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d %d %d %d %lg %lg %d",
                         &i,&j,&k,&l,&ty,&p0,&k0,&n)>=7) {
      if (bSave) {
        dihparms[N].i=i-1;
        dihparms[N].j=j-1;
        dihparms[N].k=k-1;
        dihparms[N].l=l-1;
        dihparms[N].k0=k0;
        dihparms[N].p0=(M_PI/180)*p0;
        if (ty==1) {
          dihparms[N].n=(double) n;
        } else if (ty==2) {
          dihparms[N].n=0;
        } else {
          fprintf(stderr,"Unrecognized Dihedral Type\n");
        }
      }
      N++;
    } else {
      break;
    }
  }
  return N;
}


struct_dihparms* alloc_dihparms(int *N,char fnm[])
{
  struct_dihparms *dihparms;
  FILE *fp;
  int i;

  fp=fopen(fnm,"r");
  topseek("[ dihedrals ]\n",fp);
  *N=topdih(0,NULL,fp);
  fclose(fp);

  dihparms=calloc(*N,sizeof(struct_dihparms));

  fp=fopen(fnm,"r");
  topseek("[ dihedrals ]\n",fp);
  *N=topdih(1,dihparms,fp);
  fclose(fp);

  return dihparms;
}


int toppair(int bSave,struct_pairparms *pairparms,FILE *fp)
{
  char s[MAXLENGTH];
  int N=0;
  int i,j,ty;
  double C6,C12;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d %d %lg %lg",&i,&j,&ty,&C6,&C12)==5) {
      if (bSave) {
        pairparms[N].i=i-1;
        pairparms[N].j=j-1;
        if (ty==1) {
          pairparms[N].C6=C6;
          pairparms[N].C12=C12;
        } else {
          fprintf(stderr,"Unrecognized pair type\n");
        }
      }
      N++;
    } else {
      break;
    }
  }
  return N;
}


struct_pairparms* alloc_pairparms(int *N,char fnm[])
{
  struct_pairparms *pairparms;
  FILE *fp;
  int i;

  fp=fopen(fnm,"r");
  topseek("[ pairs ]\n",fp);
  *N=toppair(0,NULL,fp);
  fclose(fp);

  pairparms=calloc(*N,sizeof(struct_pairparms));

  fp=fopen(fnm,"r");
  topseek("[ pairs ]\n",fp);
  *N=toppair(1,pairparms,fp);
  fclose(fp);

  return pairparms;
}


void addexcl(int in,struct_exclparms *exclparms,int i,int j)
{
  int ij;

  // See if we already have j in i's list
  for (ij=0; ij<exclparms[i].N[in]; ij++) {
    if (exclparms[i].j[ij]==j) {
      return;
    }
  }

  // If not, add j to i's list
  if (exclparms[i].N[in]==exclparms[i].Nmax) {
    exclparms[i].Nmax+=5;
    exclparms[i].j=realloc(exclparms[i].j,exclparms[i].Nmax*sizeof(int));
  }
  exclparms[i].j[exclparms[i].N[in]]=j;
  exclparms[i].N[in]++;
}


int topcount(FILE *fp)
{
  char s[MAXLENGTH];
  int i,N;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d",&i)==1) {
      N=i;
    } else {
      break;
    }
  }
  return N;
}


void topexcl(int in,struct_exclparms *exclparms,FILE *fp)
{
  char s[MAXLENGTH];
  int i,j;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    if (s[0] == ';' || s[1] == ';') {
      // goto next line
      ;
    } else if (sscanf(s,"%d %d",&i,&j)==2) {
      addexcl(in,exclparms,i-1,j-1);
      addexcl(in,exclparms,j-1,i-1);
    } else {
      break;
    }
  }
}


void updateexcl(int in,int N,struct_exclparms *exclparms)
{
  int i,j,k,j1,j2;

  for (i=0; i<N; i++) {
    exclparms[i].N[in]=exclparms[i].N[in-1];
    for (j=0; j<exclparms[i].N[in-1]; j++) {
      j1=exclparms[i].j[j];
      for (k=0; k<exclparms[j1].N[0]; k++) {
        j2=exclparms[j1].j[k];
        addexcl(in,exclparms,i,j2);
      }
    }
  }
}


struct_exclparms* alloc_exclparms(int *N,char fnm[])
{
  struct_exclparms *exclparms;
  FILE *fp;
  int i;

  // Allocate for each atom
  exclparms=calloc(*N,sizeof(struct_exclparms));
  
  fp=fopen(fnm,"r");
  topseek("[ bonds ]\n",fp);
  topexcl(0,exclparms,fp);
  fclose(fp);

  updateexcl(1,*N,exclparms);
  updateexcl(2,*N,exclparms);

  fp=fopen(fnm,"r");
  topseek("[ exclusions ]\n",fp);
  topexcl(2,exclparms,fp);
  fclose(fp);

  return exclparms;
}


void read_parameter_b(int *A,FILE *fp,char *token,int def,int id) {
  char s[MAXLENGTH],ss[MAXLENGTH],token_list[MAXLENGTH];
  char *sbuf;
  char a[MAXLENGTH];
  int i,spos;
  int found=0;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    sscanf(s,"%s = %s",&ss,&a);
    if (strcmp(ss,token) == 0) {
      found=1;
      break;
    }
  }
  rewind(fp);

  if (found==0) {
    strcpy(token_list,token);
    strcat(token_list,"-list");
    while (fgets(s,MAXLENGTH,fp) != NULL) {
      sscanf(s,"%s = %n",&ss,&spos);
      if (strcmp(ss,token_list) == 0) {
        found=1;
        sbuf=s+spos;
        for (i=0;i<=id;i++) {
          sscanf(sbuf,"%s%n",&a,&spos);
          sbuf+=spos;
        }
        break;
      }
    }
  }
  rewind(fp);

  if (found) {
    if (strcmp(a,"yes")==0) {
      *A=1;
    } else if(strcmp(a,"no")==0) {
      *A=0;
    } else {
      *A=def;
    }
  } else {
    *A=def;
  }
}


void read_parameter_i(int *A,FILE *fp,char *token,int def,int id) {
  char s[MAXLENGTH],ss[MAXLENGTH],token_list[MAXLENGTH];
  char *sbuf;
  int a;
  int i,spos;
  int found=0;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    sscanf(s,"%s = %d",&ss,&a);
    if (strcmp(ss,token) == 0) {
      found=1;
      break;
    }
  }
  rewind(fp);

  if (found==0) {
    strcpy(token_list,token);
    strcat(token_list,"-list");
    while (fgets(s,MAXLENGTH,fp) != NULL) {
      sscanf(s,"%s = %n",&ss,&spos);
      if (strcmp(ss,token_list) == 0) {
        found=1;
        sbuf=s+spos;
        for (i=0;i<=id;i++) {
          sscanf(sbuf,"%d%n",&a,&spos);
          sbuf+=spos;
        }
        break;
      }
    }
  }
  rewind(fp);

  if (found) {
    *A=a;
  } else {
    *A=def;
  }
}


void read_parameter_d(double *A,FILE *fp,char *token,double def,int id) {
  char s[MAXLENGTH],ss[MAXLENGTH],token_list[MAXLENGTH];
  char *sbuf;
  double a;
  int i,spos;
  int found=0;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    sscanf(s,"%s = %lg",&ss,&a);
    if (strcmp(ss,token) == 0) {
      found=1;
      break;
    }
  }
  rewind(fp);

  if (found==0) {
    strcpy(token_list,token);
    strcat(token_list,"-list");
    while (fgets(s,MAXLENGTH,fp) != NULL) {
      sscanf(s,"%s = %n",&ss,&spos);
      if (strcmp(ss,token_list) == 0) {
        found=1;
        sbuf=s+spos;
        for (i=0;i<=id;i++) {
          sscanf(sbuf,"%lg%n",&a,&spos);
          sbuf+=spos;
        }
        break;
      }
    }
  }
  rewind(fp);

  if (found) {
    *A=a;
  } else {
    *A=def;
  }
}


void read_parameter_s(char **A,FILE *fp,char *token,char *def,int id) {
  char s[MAXLENGTH],ss[MAXLENGTH],token_list[MAXLENGTH];
  char *sbuf;
  char a[MAXLENGTH];
  int i,spos;
  int found=0;

  while (fgets(s,MAXLENGTH,fp) != NULL) {
    sscanf(s,"%s = %s",&ss,&a);
    if (strcmp(ss,token) == 0) {
      found=1;
      break;
    }
  }
  rewind(fp);

  if (found==0) {
    strcpy(token_list,token);
    strcat(token_list,"-list");
    while (fgets(s,MAXLENGTH,fp) != NULL) {
      sscanf(s,"%s = %n",&ss,&spos);
      if (strcmp(ss,token_list) == 0) {
        found=1;
        sbuf=s+spos;
        for (i=0;i<=id;i++) {
          sscanf(sbuf,"%s%n",&a,&spos);
          sbuf+=spos;
        }
        break;
      }
    }
  }
  rewind(fp);

  if (found) {
    strcpy(*A,a);
  } else {
    strcpy(*A,def);
  }
}

// WORKING HERE
// Allocation/free functions
struct_parms* alloc_parms(int argc, char *argv[])
{
  struct_parms *parms;
  FILE *fp;
  double gamma;

  int id;
  double cMg,cK,cCl;
  double s;
  double Tr,Tr0;

  fp=fopen(argv[1],"r");

  parms=malloc(sizeof(struct_parms));

  #ifdef MPI
  MPI_Comm_rank(MPI_COMM_WORLD,&id);
  // WORKING ERROR
  read_parameter_i(&(parms->offset),fp,"offset",0,id);
  id+=parms->offset;
  parms->id=id;
  #endif

  read_parameter_d(&(parms->arg_box),fp,"box",100,id);
  read_parameter_i(&(parms->arg_N_mg),fp,"N_mg",250,id);
  parms->arg_topfile=calloc(MAXLENGTH,sizeof(char));
  read_parameter_s(&(parms->arg_topfile),fp,"topfile","",id);
  parms->arg_xyzqfile=calloc(MAXLENGTH,sizeof(char));
  read_parameter_s(&(parms->arg_xyzqfile),fp,"xyzqfile","",id);

  // Temperatures
  parms->kB=0.008314; // Boltzmann Constant
  read_parameter_d(&Tr,fp,"ref_t",90,id);
  read_parameter_d(&Tr0,fp,"ref_t0",90,id);
  parms->kT0=parms->kB*300; // Room temperature (Kelvin)
  parms->kTr0=parms->kB*Tr0; // Room temperature (reduced units - 90 for vanilla)
  parms->kTr=parms->kB*Tr; // System temperature (reduced units)
  parms->kT=parms->kTr*parms->kT0/parms->kTr0; // System temperature (Kelvin)

  // Electrostatics
  parms->lB=0.7; // nm
  cMg=parms->arg_N_mg/(parms->arg_box*parms->arg_box*parms->arg_box); // nm^-3
  read_parameter_d(&cK,fp,"conc_KCl",0.05,id);
  cK*=MOLAR; // nm^-3
  parms->conc_K=cK;
  parms->conc_Cl=cCl=cK+2*cMg; // nm^-3
  parms->conc_KCl=cK+2.0*cK*cMg/(cK+cCl); // nm^-3
  parms->kappa=sqrt(4*M_PI*(cK+cCl)*parms->lB); // nm^-1 - inverse DH length
  parms->gauss_00=0; // nm
  parms->gauss_01=0.7; // 0.7 nm is suggested
  parms->gauss_02=0.34; // 0.34 nm is suggested
  parms->gauss_11=sqrt(2*parms->gauss_01*parms->gauss_01);
  parms->gauss_12=sqrt(parms->gauss_01*parms->gauss_01+parms->gauss_02*parms->gauss_02);
  parms->gauss_22=sqrt(2*parms->gauss_02*parms->gauss_02);
  // b=0.167; // nm, xi=4.2
  // parms->xi=lB/b;
  // parms->V=4*M_PI*exp(1)*parms->f_KCl*(parms->lB-b)*b*b;
  // parms->V=1.0;
  parms->V1=M_SQRT8PI3*parms->gauss_01*parms->gauss_01*parms->gauss_01;
  parms->V2=M_SQRT8PI3*parms->gauss_02*parms->gauss_02*parms->gauss_02;
  parms->k_prohibit=1e4; // kT0
  parms->k_soft=1.0; // kT0
  parms->rcelec=5/parms->kappa; // nm - electrostatic force cutoff
  parms->elec_tables=alloc_tables(parms->rcelec,parms);

  // Excluded Volume
  parms->k12=(5.96046e-10/(0.17*0.17*0.17*0.17*0.17*0.17*0.17*0.17*0.17*0.17*0.17*0.17)); // (4./3.)*parms->kT;
  parms->s2[0][0]=0.17*0.17;
  // s=0.34*pow(,(1.0/12.0));
  parms->s2[0][1]=0.34*0.34;
  parms->s2[1][0]=0.34*0.34;
  parms->s2[1][1]=0.56*0.56;
  parms->rcother=1.5; // nm - excluded volume force cutoff

  // Run Control
  read_parameter_i(&(parms->t_output),fp,"nstxout",5000,id); // output frequency
  parms->t_ns=20; // neighbor search frequency
  parms->anneal1lim=1000; // Number of steps for electrostatic equilibration
  parms->anneal2lim=20000; // Number of steps for electrostatic equilibration
  read_parameter_i(&(parms->steplim),fp,"nsteps",200000000,id); // Number of steps

  // Leapfrog parameters
  read_parameter_d(&(parms->dt),fp,"dt",0.002,id); // ps - timestep
  gamma=1; // ps^-1 - drag coefficient for atoms (60 ps^-1 in water)
  parms->leapparms=alloc_leapparms(parms->dt,gamma,parms->kTr);
  gamma=10; // ps^-1 - drag coefficient condensation during equilibration
  parms->leapparms_anneal1=alloc_leapparms(0.1*parms->dt,gamma,0.01*parms->kT);
  gamma=5; // ps^-1 - drag coefficient condensation during equilibration
  parms->leapparms_anneal2=alloc_leapparms(parms->dt,gamma,0.01*parms->kT);
  gamma=0.05; // ps^-1 - drag coefficient condensation during production
  parms->leapparms_mcc=alloc_leapparms(parms->dt,gamma,parms->kT);

  read_parameter_b(&(parms->flexible),fp,"flexible",0,id);

  fclose(fp);

  return parms;
}


void free_parms(struct_parms* parms)
{
  free_tables(parms->elec_tables);
  free_leapparms(parms->leapparms);
  free_leapparms(parms->leapparms_mcc);
  free_leapparms(parms->leapparms_anneal1);
  free_leapparms(parms->leapparms_anneal2);
  free(parms);
}


struct_parms* alloc_topparms(struct_md *md)
{
  // char topfile[]="system/PK_NoNextLocal/PK_NoNextLocal.top";
  // char topfile[]="system/PK/PK.top"; // CONST
  struct_parms *parms=md->parms;
  char *topfile=parms->arg_topfile;

  // fprintf(stderr,"Warning, uncorrected unit mismatch\n");
  parms->bondparms=alloc_bondparms(&(parms->N_bond),topfile);
  parms->angleparms=alloc_angleparms(&(parms->N_angle),topfile);
  parms->dihparms=alloc_dihparms(&(parms->N_dih),topfile);
  parms->pairparms=alloc_pairparms(&(parms->N_pair),topfile);
  parms->N_excl=md->state->N_all;
  parms->exclparms=alloc_exclparms(&(parms->N_excl),topfile);

  return parms;
}


void free_topparms(struct_parms *parms)
{
  int i;
  free(parms->bondparms);
  free(parms->angleparms);
  free(parms->dihparms);
  free(parms->pairparms);
  // fprintf(stderr,"Free exclparms\n");
  for (i=0; i<parms->N_excl; i++) {
    if (parms->exclparms[i].Nmax>0) {
      free(parms->exclparms[i].j);
    }
  }
  free(parms->exclparms);
}

struct_atoms* alloc_atoms(int N,int Ni,int Nf,double* x)
{
  struct_atoms *atoms;

  atoms=malloc(sizeof(struct_atoms));

  atoms->N=N;
  atoms->Ni=Ni;
  atoms->Nf=Nf;
  atoms->x=x;
  atoms->f=alloc_collate(N,Ni,Nf);
  atoms->v=calloc(N,sizeof(double));
  atoms->m=calloc(N,sizeof(double));
  atoms->msqrt=calloc(N,sizeof(double));
  atoms->Vs_delay=calloc(N,sizeof(double));

  return atoms;
}


void free_atoms(struct_atoms* atoms)
{
  free_collate(atoms->f);
  free(atoms->v);
  free(atoms->m);
  free(atoms->msqrt);
  free(atoms->Vs_delay);
  free(atoms);
}


struct_nlist* alloc_nlist(int N,int *iitype,double **rc2)
{
  struct_nlist *nlist;
  int i, NID;

  NID=omp_get_max_threads();

  nlist=malloc(sizeof(struct_nlist));
  nlist->iimax=N;
  nlist->ii=calloc(N,sizeof(int));
  nlist->jjmax=calloc(N,sizeof(int));
  nlist->sort=calloc(N,sizeof(struct_sortatom));
  nlist->iitype=iitype;

  nlist->div=calloc(3,sizeof(int));
  nlist->rc2=rc2;

  nlist->jjsize=calloc(N,sizeof(int));
  nlist->jj=calloc(N,sizeof(int*));
  nlist->nldata=calloc(N,sizeof(struct_nldata*));
  nlist->shiftij=calloc(N,sizeof(vec*));
  for (i=0; i<N; i++) {
    nlist->jjsize[i]=20;
    nlist->jj[i]=calloc(nlist->jjsize[i],sizeof(int));
    nlist->nldata[i]=calloc(nlist->jjsize[i],sizeof(struct_nldata));
    nlist->shiftij[i]=calloc(nlist->jjsize[i],sizeof(vec));
  }

  nlist->cycles_sort=calloc(NID,sizeof(gmx_cycles_t));
  nlist->cycles_check=calloc(NID,sizeof(gmx_cycles_t));
  nlist->cycles_force=calloc(NID,sizeof(gmx_cycles_t));
  nlist->cumcycles_sort=calloc(NID,sizeof(gmx_cycles_t));
  nlist->cumcycles_check=calloc(NID,sizeof(gmx_cycles_t));
  nlist->cumcycles_check1=calloc(NID,sizeof(gmx_cycles_t));
  nlist->cumcycles_check2=calloc(NID,sizeof(gmx_cycles_t));
  nlist->cumcycles_force=calloc(NID,sizeof(gmx_cycles_t));
  nlist->imin=calloc(NID,sizeof(int));
  nlist->imax=calloc(NID,sizeof(int));
  nlist->imin_f=calloc(NID,sizeof(int));
  nlist->imax_f=calloc(NID,sizeof(int));
  nlist->checklist=calloc(NID,sizeof(int*));
  nlist->shiftlist=calloc(NID,sizeof(vec*));
  for (i=0; i<NID; i++) {
    nlist->cycles_sort[i]=1;
    nlist->cycles_check[i]=1;
    nlist->cycles_force[i]=1;
    nlist->cumcycles_sort[i]=0;
    nlist->cumcycles_check[i]=0;
    nlist->cumcycles_check1[i]=0;
    nlist->cumcycles_check2[i]=0;
    nlist->cumcycles_force[i]=0;
    nlist->imin[i]=(N*i)/NID;
    nlist->imax[i]=(N*(i+1))/NID;
    nlist->imin_f[i]=(N*i)/NID;
    nlist->imax_f[i]=(N*(i+1))/NID;
    nlist->checklist[i]=calloc(N,sizeof(int));
    nlist->shiftlist[i]=calloc(N,sizeof(vec));
  }
  
  return nlist;
}


void realloc_nlist(struct_nlist* nlist,int i,int N)
{
  nlist->jjsize[i]=N;
  nlist->jj[i]=realloc(nlist->jj[i],nlist->jjsize[i]*sizeof(int));
  nlist->nldata[i]=realloc(nlist->nldata[i],nlist->jjsize[i]*sizeof(struct_nldata));
  nlist->shiftij[i]=realloc(nlist->shiftij[i],nlist->jjsize[i]*sizeof(vec));
}


void free_nlist(struct_nlist* nlist)
{
  int i,N,NID;

  N=nlist->iimax;
  NID=omp_get_max_threads();

  free(nlist->ii);
  free(nlist->jjmax);
  free(nlist->sort);
  free(nlist->iitype);
  free(nlist->div);
  for (i=0; i<N; i++) {
    free(nlist->jj[i]);
    free(nlist->nldata[i]);
    free(nlist->shiftij[i]);
  }
  free(nlist->jjsize);
  free(nlist->jj);
  free(nlist->nldata);
  free(nlist->shiftij);

  for (i=0; i<NID; i++) {
    free(nlist->checklist[i]);
    free(nlist->shiftlist[i]);
  }
  free(nlist->checklist);
  free(nlist->shiftlist);

  free(nlist->cycles_sort);
  free(nlist->cycles_check);
  free(nlist->cycles_force);
  free(nlist->cumcycles_sort);
  free(nlist->cumcycles_check);
  free(nlist->cumcycles_check1);
  free(nlist->cumcycles_check2);
  free(nlist->cumcycles_force);
  free(nlist->imin);
  free(nlist->imax);

  free(nlist);
}


// Begin Mersenne Twister
// Modified from
// http://www.math.sci.hiroshima-u.ac.jp/~m-mat/MT/MT2002/emt19937ar.html
/* 
   A C-program for MT19937, with initialization improved 2002/1/26.
   Coded by Takuji Nishimura and Makoto Matsumoto.

   Before using, initialize the state by using init_genrand(seed)  
   or init_by_array(init_key, key_length).

   Copyright (C) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura,
   All rights reserved.                          

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

     1. Redistributions of source code must retain the above copyright
        notice, this list of conditions and the following disclaimer.

     2. Redistributions in binary form must reproduce the above copyright
        notice, this list of conditions and the following disclaimer in the
        documentation and/or other materials provided with the distribution.

     3. The names of its contributors may not be used to endorse or promote 
        products derived from this software without specific prior written 
        permission.
   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
   A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER O
R
   CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
   EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
   PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
   PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
   LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


   Any feedback is very welcome.
   http://www.math.sci.hiroshima-u.ac.jp/~m-mat/MT/emt.html
   email: m-mat @ math.sci.hiroshima-u.ac.jp (remove space)
*/

/* Period parameters */
#define MT_N 624
#define MT_M 397
#define MT_MATRIX_A 0x9908b0dfUL   /* constant vector a */
#define MT_UPPER_MASK 0x80000000UL /* most significant w-r bits */
#define MT_LOWER_MASK 0x7fffffffUL /* least significant r bits */

// static unsigned long mt[MT_N]; /* the array for the state vector  */
// static int mti=MT_N+1; /* mti==N+1 means mt[N] is not initialized */

/* initializes mt[N] with a seed */
void init_genrand(unsigned long s, unsigned long mt[MT_N], int* pt_mti)
{
    int mti=pt_mti[0];
    mt[0]= s & 0xffffffffUL;
    for (mti=1; mti<MT_N; mti++) {
        mt[mti] =
            (1812433253UL * (mt[mti-1] ^ (mt[mti-1] >> 30)) + mti);
        /* See Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier. */
        /* In the previous versions, MSBs of the seed affect   */
        /* only MSBs of the array mt[].                        */
        /* 2002/01/09 modified by Makoto Matsumoto             */
        mt[mti] &= 0xffffffffUL;
        /* for >32 bit machines */
    }
    pt_mti[0]=mti;
}

/* initialize by an array with array-length */
/* init_key is the array for initializing keys */
/* key_length is its length */
/* slight change for C++, 2004/2/26 */
void init_by_array(unsigned long init_key[], int key_length, unsigned long mt[MT_N], int* pt_mti)
{
    int i, j, k;
    int mti=pt_mti[0];
    init_genrand(19650218UL,mt,&mti);
    i=1; j=0;
    k = (MT_N>key_length ? MT_N : key_length);
    for (; k; k--) {
        mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1664525UL))
          + init_key[j] + j; /* non linear */
        mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
        i++; j++;
        if (i>=MT_N) { mt[0] = mt[MT_N-1]; i=1; }
        if (j>=key_length) j=0;
    }
    for (k=MT_N-1; k; k--) {
        mt[i] = (mt[i] ^ ((mt[i-1] ^ (mt[i-1] >> 30)) * 1566083941UL))
          - i; /* non linear */
        mt[i] &= 0xffffffffUL; /* for WORDSIZE > 32 machines */
        i++;
        if (i>=MT_N) { mt[0] = mt[MT_N-1]; i=1; }
    }

    mt[0] = 0x80000000UL; /* MSB is 1; assuring non-zero initial array */
    pt_mti[0]=mti;
}

/* generates a random number on [0,0xffffffff]-interval */
unsigned long genrand_int32(unsigned long mt[MT_N],int* pt_mti)
{
    unsigned long y;
    static unsigned long mag01[2]={0x0UL, MT_MATRIX_A};
    /* mag01[x] = x * MATRIX_A  for x=0,1 */
    int mti=pt_mti[0];

    if (mti >= MT_N) { /* generate N words at one time */
        int kk;

        if (mti == MT_N+1)   /* if init_genrand() has not been called, */
            init_genrand(5489UL,mt,&mti); /* a default initial seed is used */

        for (kk=0;kk<MT_N-MT_M;kk++) {
            y = (mt[kk]&MT_UPPER_MASK)|(mt[kk+1]&MT_LOWER_MASK);
            mt[kk] = mt[kk+MT_M] ^ (y >> 1) ^ mag01[y & 0x1UL];
        }
        for (;kk<MT_N-1;kk++) {
            y = (mt[kk]&MT_UPPER_MASK)|(mt[kk+1]&MT_LOWER_MASK);
            mt[kk] = mt[kk+(MT_M-MT_N)] ^ (y >> 1) ^ mag01[y & 0x1UL];
        }
        y = (mt[MT_N-1]&MT_UPPER_MASK)|(mt[0]&MT_LOWER_MASK);
        mt[MT_N-1] = mt[MT_M-1] ^ (y >> 1) ^ mag01[y & 0x1UL];

        mti = 0;
    }

    y = mt[mti++];

    /* Tempering */
    y ^= (y >> 11);
    y ^= (y << 7) & 0x9d2c5680UL;
    y ^= (y << 15) & 0xefc60000UL;
    y ^= (y >> 18);

    pt_mti[0]=mti;
    return y;
}
// End Mersenne Twister


// Returns two random doubles with variance 1 in pointer r
void rand_normal(double* r,struct_mtstate* mtstate)
{
  double a,b;
  a=(((double)genrand_int32(mtstate->mt,&(mtstate->mti))) + 0.5)*(1.0/4294967296.0);
  b=(((double)genrand_int32(mtstate->mt,&(mtstate->mti))) + 0.5)*(1.0/4294967296.0);
  a=sqrt(-2*log(a));
  r[0]=a*cos(2*M_PI*b);
  r[1]=a*sin(2*M_PI*b);
}


struct_mtstate** alloc_mtstate(unsigned long s)
{
  struct_mtstate **mtstate;
  int i, NID;

  NID=omp_get_max_threads();

  mtstate=calloc(NID,sizeof(struct_mtstate*));
  for (i=0; i<NID; i++) {
    mtstate[i]=malloc(sizeof(struct_mtstate));
    mtstate[i]->mt=calloc(MT_N,sizeof(unsigned long));
    mtstate[i]->mti=MT_N+1;
    init_genrand(s+i,mtstate[i]->mt,&(mtstate[i]->mti));
  }

  return mtstate;
}


void free_mtstate(struct_mtstate** mtstate)
{
  int i,NID;

  NID=omp_get_max_threads();

  for (i=0; i<NID; i++) {
    free(mtstate[i]->mt);
    free(mtstate[i]);
  }
  free(mtstate);
}


void set_masses(struct_atoms* atoms,double m)
{
  int i;

  for (i=0; i<atoms->N; i++) {
    atoms->m[i]=m;
    atoms->msqrt[i]=sqrt(atoms->m[i]);
  }
}


void set_velocities(struct_atoms *atoms,struct_mtstate **mtstate,double kT)
{
  int i;
  double nu[2];

  for (i=0; i<atoms->N; i++) {
    rand_normal(nu,mtstate[0]);
    atoms->v[i]=sqrt(kT/atoms->m[i])*nu[0];
  }
}


struct_state* alloc_state(struct_md* md)
{
  struct_state *state;
  int N,Nbuf;
  // int id=0;
  int i;
  int *iitype;
  double **rc2;

  // #ifdef MPI
  // MPI_Comm_rank(MPI_COMM_WORLD,&id);
  // id+=OFFSET;
  // #endif

  state=malloc(sizeof(struct_state));

  state->mtstate=alloc_mtstate(time(NULL)); // CONST

  state->step=0;
  // state->box[0]=state->box[1]=state->box[2]=boxen[id]; // CONST
  state->box[0]=state->box[1]=state->box[2]=md->parms->arg_box;
  // state->box[0]=state->box[1]=state->box[2]=75; // CONST
  // Count atoms in file
  state->N_rna=read_xyzq(md->parms->arg_xyzqfile,state,0);
  state->N_mg=md->parms->arg_N_mg;
  if (md->parms->flexible) {
    state->N_fixed=0; // CONST // Index of first atom that can move in space.
  } else {
    state->N_fixed=state->N_rna; // CONST // Index of first atom that can move in space.
  }
  state->N_all=state->N_rna+state->N_mg;
  state->N_free=state->N_all-state->N_fixed;

  state->x=calloc(state->N_all,DIM3*sizeof(double));
  state->shift=calloc(state->N_all,DIM3*sizeof(double));
  state->q=calloc(state->N_all,sizeof(double));

  // Read atoms in file
  read_xyzq(md->parms->arg_xyzqfile,state,1);
  gen_xyzq(state);

  state->qqlist=alloc_qlist(state);

  state->Gt=alloc_collate(1,0,1);
  state->Kt=alloc_collate(1,0,1);

  N=DIM3*state->N_all;
  Nbuf=DIM3*state->N_fixed;
  // BUG
  // state->atoms=alloc_atoms(N,Nbuf,N,&(state->x[DIM3*state->N_fixed]));
  state->atoms=alloc_atoms(N,Nbuf,N,state->x);
  state->atoms->shift=state->shift;
  N=state->qqlist->nqlist;
  Nbuf=state->qqlist->nqlist_th;
  state->manningcc_tk=alloc_atoms(N,0,Nbuf,state->qqlist->theta);
  state->manningcc_tcl=alloc_atoms(N,0,Nbuf,state->qqlist->theta_cl);
  state->manningcc_ek=alloc_atoms(N,0,Nbuf,state->qqlist->eta);
  state->manningcc_ecl=alloc_atoms(N,0,Nbuf,state->qqlist->eta_cl);

  set_masses(state->atoms,1); // CONST
  set_masses(state->manningcc_tk,15); // CONST
  set_masses(state->manningcc_tcl,15); // CONST
  set_masses(state->manningcc_ek,15); // CONST
  set_masses(state->manningcc_ecl,15); // CONST

  set_velocities(state->atoms,state->mtstate,md->parms->kTr);

  iitype=calloc(state->qqlist->nqlist,sizeof(int));
  rc2=calloc(1,sizeof(double*));
  rc2[0]=calloc(1,sizeof(double));
  rc2[0][0]=md->parms->rcelec*md->parms->rcelec;
  state->nlelec=alloc_nlist(state->qqlist->nqlist,iitype,rc2);

  // WORKING HERE - put rc2 in parms?
  iitype=calloc(state->N_all,sizeof(int));
  for (i=state->N_rna; i<state->N_all; i++) {
    iitype[i]=1;
  }
  rc2=calloc(2,sizeof(double*));
  rc2[0]=calloc(2,sizeof(double));
  rc2[0][0]=0.7*0.7; // CONST
  // fprintf(stderr,"Warning: using rc=0 for RNA-RNA excluded volume\n");
  // rc2[0][0]=0.0*0.0; // CONST
  rc2[0][1]=1.02*1.02; // CONST
  rc2[1]=calloc(2,sizeof(double));
  rc2[1][0]=1.02*1.02; // CONST
  rc2[1][1]=1.5*1.5; // CONST
  state->nlother=alloc_nlist(state->N_all,iitype,rc2);

  return state;
}


void free_state(struct_state* state)
{
  free(state->x);
  free(state->shift);
  free(state->q);
  free_qlist(state->qqlist);
  free_atoms(state->atoms);
  free_atoms(state->manningcc_tk);
  free_atoms(state->manningcc_tcl);
  free_atoms(state->manningcc_ek);
  free_atoms(state->manningcc_ecl);
  // WORKING HERE
  // WARNING state->nlelec->rc2 and state->nlother->rc2 not freed.
  free_nlist(state->nlelec);
  free_nlist(state->nlother);
  free_mtstate(state->mtstate);
  free(state);
}


struct_files* alloc_files(void)
{
  struct_files *files;
  int i;

  files=malloc(sizeof(struct_files));
  files->N=eF_MAX;
  files->fps=calloc(files->N,sizeof(FILE*));
  for (i=0; i<files->N; i++) {
    files->fps[i]=NULL;
  }

  return files;
}


void free_files(struct_files* files)
{
  int i;
  for (i=0; i<files->N; i++) {
    if (files->fps[i] != NULL) {
      fclose(files->fps[i]);
    }
  }
  free(files);
}


struct_times* alloc_times(void)
{
  struct_times *times;

  times=malloc(sizeof(struct_times));
  times->start=0;
  times->stop=0;
  times->nsearch=0;
  times->force=0;
  times->update=0;
  times->write=0;
  return times;
}


void free_times(struct_times* times)
{
  free(times);
}


struct_md* alloc_md(int argc, char *argv[])
{
  struct_md *md;
  md=malloc(sizeof(struct_md));
  md->parms=alloc_parms(argc,argv);
  md->state=alloc_state(md);
  fprintf(stderr,"Warning, two different energy units in code, they are currently handled consistently, as of 2015-01-18\n");
  if (md->parms->flexible) {
    md->parms=alloc_topparms(md);
  }
  md->files=alloc_files();
  md->times=alloc_times();
  return md;
}


void free_md(struct_md* md)
{
  if (md->parms->flexible) {
    free_topparms(md->parms);
  }
  free_parms(md->parms);
  free_state(md->state);
  free_files(md->files);
  free_times(md->times);
  free(md);
}


/*void printxyz(struct_md* md)
{
  FILE *fp=md->files->fp_xyz;
  double *x=md->state->x;
  int i;

  if (fp == NULL) {
    fp=fopen("pos.xyz","w");
    md->files->fp_xyz=fp;
  }
  
  fprintf(fp,"%d\nComment - Frame %d\n",md->state->N_all,md->state->step);
  for (i=0; i<DIM3*md->state->N_all; i+=3) {
    fprintf(fp,"P %g %g %g\n",x[i],x[i+1],x[i+2]);
  }

  // fclose(fp); is called in free_files
}*/


void printgro(struct_md* md)
{
  FILE *fp=md->files->fps[eF_gro];
  double *x=md->state->x;
  double *box=md->state->box;
  char *typeR, *typeA;
  int i;
  int id=0;
  char fnm[100];

  if (fp == NULL) {
    #ifdef MPI
    MPI_Comm_rank(MPI_COMM_WORLD,&id);
    id+=md->parms->offset;
    #endif
    sprintf(fnm,"outfiles/traj.%d.gro",id);
    fp=fopen(fnm,"w");
    md->files->fps[eF_gro]=fp;
  }

  fprintf(fp,"Manning RNA trajectory, t= %g\n",md->state->step*md->parms->dt);
  fprintf(fp,"%d\n",md->state->N_all);
  for (i=0; i<DIM3*md->state->N_all; i+=3) {
    if (i/3 < md->state->N_rna) {
      typeR="RNA";
      typeA="P";
    } else {
      typeR="MG";
      typeA="MG";
    } // WORKING HERE - Read in atom types...
    fprintf(fp,"%5d%-5s%5s%5d%8.3f%8.3f%8.3f\n",
      // "%5d%-5s%5s%5d%8.3f%8.3f%8.3f%8.4f%8.4f%8.4f\n",
      i/3+1,typeR,typeA,i/3+1,x[i],x[i+1],x[i+2]);
  }
  fprintf(fp,"   %g   %g   %g\n",box[0],box[1],box[2]);
}


// printdata(md->state->qqlist->theta,md->state->qqlist->nqlist_rna,"theta",&(md->files->fp_theta))
void printdata(struct_md *md,double* data,int N,char* s,FILE** fp)
{
  int i, id=0;
  char fnm[100];

  if (*fp == NULL) {
    #ifdef MPI
    MPI_Comm_rank(MPI_COMM_WORLD,&id);
    id+=md->parms->offset;
    #endif
    sprintf(fnm,"outfiles/%s.%d.dat",s,id);
    *fp=fopen(fnm,"w");
  }

  for (i=0; i<N; i++) {
    fprintf(*fp," %12g",data[i]);
  }
  fprintf(*fp,"\n");
}


void printheader(struct_md* md)
{
  int i,id=0;
  char fnm[100];
  
  #ifdef MPI
  MPI_Comm_rank(MPI_COMM_WORLD,&id);
  id+=md->parms->offset;
  #endif
  sprintf(fnm,"outfiles/md.%d.log",id);
  md->files->fps[eF_log]=fopen(fnm,"w");

  md->times->secpcyc=gmx_cycles_calibrate(1.0);
  fprintf(md->files->fps[eF_log],"1 second took %g cycles\n",1.0/md->times->secpcyc);

  fprintf(md->files->fps[eF_log],"xyzqfile = %s nm\n",md->parms->arg_xyzqfile);
  fprintf(md->files->fps[eF_log],"topfile = %s nm\n",md->parms->arg_topfile);
  fprintf(md->files->fps[eF_log],"box = %g nm\n",md->parms->arg_box);
  fprintf(md->files->fps[eF_log],"conc_KCl = %g nm^-3\n",md->parms->conc_K);
  fprintf(md->files->fps[eF_log],"N_mg = %d nm\n",md->parms->arg_N_mg);
  fprintf(md->files->fps[eF_log],"(Reduced) Temperature = %g\n",md->parms->kTr/md->parms->kB);
}


void printoutput(struct_md* md)
{
  FILE **fps=md->files->fps;
  struct_qlist *qqlist=md->state->qqlist;
  // int ndata=qqlist->nqlist_rna;
  // int ndata=qqlist->nqlist;
  int ndata=qqlist->nqlist_th;
  // int ndata=qqlist->nqlist;

  #pragma omp master
  {
    md->times->start=gmx_cycles_read();

    printgro(md);
    printdata(md,qqlist->theta,ndata,"theta",&(fps[eF_theta]));
    printdata(md,qqlist->theta_cl,ndata,"theta_cl",&(fps[eF_theta_cl]));
    printdata(md,qqlist->eta,ndata,"eta",&(fps[eF_eta]));
    printdata(md,qqlist->eta_cl,ndata,"eta_cl",&(fps[eF_eta_cl]));
    fprintf(fps[eF_log],"Step %d\n",md->state->step);

    printdata(md,md->state->Gt->master,1,"Gt",&(fps[eF_Gt]));
    printdata(md,md->state->Kt->master,1,"Kt",&(fps[eF_Kt]));

    printdata(md,qqlist->dens_tk,ndata,"dens_tk",&(fps[eF_dens_tk]));
    printdata(md,qqlist->dens_tcl,ndata,"dens_tcl",&(fps[eF_dens_tcl]));
    printdata(md,qqlist->dens_ek,ndata,"dens_ek",&(fps[eF_dens_ek]));
    printdata(md,qqlist->dens_ecl,ndata,"dens_ecl",&(fps[eF_dens_ecl]));
    // printdata(qqlist->pot_t->master,ndata,"pot_t",&(fps[eF_pot_t]));
    // printdata(qqlist->pot_e->master,ndata,"pot_e",&(fps[eF_pot_e]));
    // printdata(qqlist->dV,ndata,"dV",&(fps[eF_dV]));

    printdata(md,qqlist->V1eff_inv->master,ndata,"V1eff_inv",&(fps[eF_V1eff_inv]));
    printdata(md,qqlist->V2eff_inv->master,ndata,"V2eff_inv",&(fps[eF_V2eff_inv]));

    md->times->write+=(gmx_cycles_read()-md->times->start);
  }
  #pragma omp barrier
}


void printsummary(struct_md* md,gmx_cycles_t start)
{
  gmx_cycles_t stop;
  gmx_cycles_t s,si;
  int i,NID;
  FILE *fp=md->files->fps[eF_log];

  NID=omp_get_max_threads();

  stop=gmx_cycles_read();
  fprintf(fp,"Took %lld cycles\n",stop-start);
  fprintf(fp,"Took %g second\n",(stop-start)*md->times->secpcyc);

  fprintf(fp,"Neighbor search %lld cycles\n",md->times->nsearch);
  fprintf(fp,"Force calculation %lld cycles\n",md->times->force);
  fprintf(fp,"Update %lld cycles\n",md->times->update);
  fprintf(fp,"Writing files %lld cycles\n",md->times->write);
  fprintf(fp,"WORKING HERE - put in percentages\n");

  fprintf(fp,"elec sort   ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlelec->cumcycles_sort[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
  fprintf(fp,"elec check  ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlelec->cumcycles_check[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
  fprintf(fp,"elec force  ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlelec->cumcycles_force[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);

  fprintf(fp,"other sort  ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlother->cumcycles_sort[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
  fprintf(fp,"other check ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlother->cumcycles_check[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
  fprintf(fp,"other force ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlother->cumcycles_force[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);

  fprintf(fp,"------------------------------------------------\n");
  fprintf(fp,"elec check1 ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlelec->cumcycles_check1[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
  fprintf(fp,"elec check2 ");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlelec->cumcycles_check2[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
  fprintf(fp,"other check1");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlother->cumcycles_check1[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
  fprintf(fp,"other check2");
  s=0;
  for (i=0; i<NID; i++) {
    si=md->state->nlother->cumcycles_check2[i];
    s+=si;
    fprintf(fp,"%16lld  ",si);
  }
  fprintf(fp,"%16lld\n",s);
}


// Neighbor searching
int tree2index(struct_sortatom* node,int* list,int i)
{
  if (node->pless != NULL) {
    i=tree2index(node->pless,list,i);
  }
  list[i]=node->index;
  i++;
  if (node->pmore != NULL) {
    i=tree2index(node->pmore,list,i);
  }
  return i;
}


void balancenode(void)
{
  // WORKING HERE
}


void neighborbin(struct_nlist* nlist,double rc,int N, double* x,double* box)
{
  int i,j;
  int ID;
  gmx_cycles_t start;
  struct_sortatom *head=NULL;
  struct_sortatom **node;
  struct_sortatom *leaf;
  int compare;

  ID=omp_get_thread_num();

  start=gmx_cycles_read();

  for (i=0; i<DIM3; i++) {
    nlist->div[i]=(int) (box[i]/rc);
  }

  for (i=0; i<N; i++) {
    // Initialize each neighbor
    leaf=&(nlist->sort[i]);
    leaf->index=i;
    for (j=0; j<DIM3; j++) {
      leaf->bin[j]=(int) (nlist->div[j]*x[DIM3*i+j]/box[j]);
    }
    leaf->lbin=((long long) leaf->bin[0]);
    leaf->lbin*=nlist->div[1];
    leaf->lbin+=((long long) leaf->bin[1]);
    leaf->lbin*=nlist->div[2];
    leaf->lbin+=((long long) leaf->bin[2]);
    leaf->pless=NULL;
    leaf->pmore=NULL;
    leaf->nless=0;
    leaf->nmore=0;
    // Sort the neighbors into tree
    node=&head;
    while (*node != NULL) {
      if (leaf->lbin > (*node)->lbin) {
        (*node)->nmore++;
        node=&((*node)->pmore);
      } else if (leaf->lbin < (*node)->lbin) { // compare==-1
        (*node)->nless++;
        node=&((*node)->pless);
      } else if ((*node)->nmore < (*node)->nless) {
        (*node)->nmore++;
        node=&((*node)->pmore);
      } else {
        (*node)->nless++;
        node=&((*node)->pless);
      }
    }
    *node=leaf;
    // WORKING HERE - reorganize tree if it's imbalanced using nmore and nless
  }
  // Use recursive functions to order the tree
  tree2index(head,nlist->ii,0);

  nlist->cycles_sort[ID]+=(gmx_cycles_read()-start);
}


// Find first index for which a bin is >= targbin
// int seekindex(int* ii,struct_sortatom* sort,int N,int* targbin)
int seekindex(int* ii,struct_sortatom* sort,int N,int* div,int* targbin)
{
  int i;
  long long currlbin;
  long long targlbin;
  int ibelow=-1;
  int iabove=N;
  int itest;
  int compare;

  targlbin=((long long) targbin[0]);
  targlbin*=div[1];
  targlbin+=((long long) targbin[1]);
  targlbin*=div[2];
  targlbin+=((long long) targbin[2]);
  while (iabove - ibelow > 1) {
    itest=ibelow+(iabove-ibelow)/2;
    currlbin=sort[ii[itest]].lbin;
    if (currlbin >= targlbin) {
      // search below
      iabove=itest;
    } else {
      // search above
      ibelow=itest;
    }
  }
  return iabove;
}


int addtochecklist(int* checklist,int nchecklist,vec* shiftlist,vec shift,int* ii,int first,int last)
{
  int i;
  for (i=first; i<last; i++) {
    checklist[nchecklist]=ii[i];
    vec_copy(shiftlist[nchecklist],shift);
    nchecklist++;
  }
  return nchecklist;
}


int checkexcl(struct_exclparms *excl,int i,int j,int flexible)
{
  if (flexible) {
    int a;
    if (excl != NULL) {
      for (a=0; a<excl[i].N[2]; a++) {
        if (j==excl[i].j[a]) {
          return 0;
        }
      }
    }
    return 1;
  } else {
    return 1;
  }
}


// void screenchecklist(int i,int* jjlist,int njjlist,struct_nlist* nlist,double rc2,int N,double* x,double* box)
// void screenchecklist(int i,int* jjlist,int njjlist,vec* jjshift,struct_nlist* nlist,int N,double* x,double* box)
void screenchecklist(int i,int* jjlist,int njjlist,vec* jjshift,struct_nlist* nlist,struct_exclparms *excl,int N,double* x,double* box,int flexible)
{
  int ii,j,jj,jjmax;
  // double *shiftij;
  double *rc2;
  vec dr;

  if (njjlist > nlist->jjsize[i]) {
    realloc_nlist(nlist,i,njjlist);
  }

  ii=nlist->ii[i];
  rc2=nlist->rc2[nlist->iitype[ii]];
  jjmax=0;
  for (j=0; j<njjlist; j++) {
    jj=jjlist[j];
    // shiftij=nlist->shiftij[jjind];
    
    // vec_subsaveshift(x+DIM3*ii,x+DIM3*jj,box,shiftij,dr);
    // vec_subquick(x+DIM3*ii,x+DIM3*jj,box,dr);
    // if (vec_mag2(dr)<=rc2[nlist->iitype[jj]]) {
    // assert( (vec_quickdist2(x+DIM3*ii,x+DIM3*jj,box)<=rc2[nlist->iitype[jj]]) == (vec_shiftdist2(x+DIM3*ii,x+DIM3*jj,jjshift[j])<=rc2[nlist->iitype[jj]]) );
    if (vec_shiftdist2(x+DIM3*ii,x+DIM3*jj,jjshift[j])<=rc2[nlist->iitype[jj]]) {
      if (checkexcl(excl,ii,jj,flexible)) {
      nlist->jj[i][jjmax]=jj;
      vec_copy(nlist->shiftij[i][jjmax],jjshift[j]);
      jjmax++;
      }
    }
  }
  nlist->jjmax[i]=jjmax;
}


void neighborcheck(struct_nlist* nlist,struct_exclparms *excl,double rc,int N, double* x,double* box,int flexible)
{
  int ID;
  int *checklist;
  vec *shiftlist;
  double rc2=rc*rc;
  int *div;
  int sbuf;
  int i,j,k;
  int currbin[3],targbin[13][3];
  vec targshift[13];
  vec nullshift={0,0,0};
  int first,last;
  int nchecklist;
  gmx_cycles_t start,stop;
  gmx_cycles_t start_t1,start_t2;

  ID=omp_get_thread_num();
  checklist=nlist->checklist[ID];
  shiftlist=nlist->shiftlist[ID];
  div=nlist->div;

  start=gmx_cycles_read();

  i=nlist->imin[ID];
  nchecklist=0;

  // Set up any other leftovers from earlier in this bin
  ivec_copy(currbin,nlist->sort[nlist->ii[i]].bin);
  first=seekindex(nlist->ii,nlist->sort,N,div,currbin);
  nchecklist=addtochecklist(checklist,nchecklist,shiftlist,nullshift,nlist->ii,first,i);

  while (i<nlist->imax[ID]) {
    start_t1=gmx_cycles_read();
    // copy box index, and indices of 13 boxes to search
    ivec_copy(currbin,nlist->sort[nlist->ii[i]].bin);
    for (j=0; j<13; j++)
      ivec_copy(targbin[j],currbin);
    for (j=0; j<9; j++)
      targbin[j][0]++;
    for (j=0; j<3; j++) {
      targbin[j  ][1]++;
      targbin[j+6][1]--;
      targbin[j+9][1]++;
    }
    for (j=0; j<13; j+=3)
      targbin[j][2]++;
    for (j=2; j<13; j+=3)
      targbin[j][2]--;
    for (j=0; j<13; j++) {
      for (k=0; k<DIM3; k++) {
        sbuf=1-((targbin[j][k]+div[k])/div[k]);
        targbin[j][k]+=div[k]*sbuf;
        targshift[j][k]=box[k]*sbuf;
      }
    }

    // use seekindex again to find bounds of atoms in box and add to checklist
    for (j=0; j<13; j++) {
      first=seekindex(nlist->ii,nlist->sort,N,div,targbin[j]);
      targbin[j][2]++;
      last=seekindex(nlist->ii,nlist->sort,N,div,targbin[j]);
      nchecklist=addtochecklist(checklist,nchecklist,shiftlist,targshift[j],nlist->ii,first,last);
    }
    nlist->cumcycles_check1[ID]+=(gmx_cycles_read()-start_t1);
    // check all atoms on checklist checklist
    start_t2=gmx_cycles_read();
    while (i<nlist->imax[ID] && ivec_eq(currbin,nlist->sort[nlist->ii[i]].bin)) {
      screenchecklist(i,checklist,nchecklist,shiftlist,nlist,excl,N,x,box,flexible);
      nchecklist=addtochecklist(checklist,nchecklist,shiftlist,nullshift,nlist->ii,i,i+1);
      i++;
    }
    nchecklist=0;
    nlist->cumcycles_check2[ID]+=(gmx_cycles_read()-start_t2);
  }

  stop=gmx_cycles_read();
  nlist->cycles_check[ID]+=(stop-start);
}


void loadbalance(struct_nlist* nlist)
{
  int i,NID;
  gmx_cycles_t cycles_prev,cycles;
  int boundary;

  NID=omp_get_max_threads();

  for (i=1;i<NID;i++) {
    cycles_prev=nlist->cycles_check[i-1];
    nlist->cumcycles_sort[i-1]+=nlist->cycles_sort[i-1];
    nlist->cumcycles_check[i-1]+=nlist->cycles_check[i-1];
    nlist->cycles_sort[i-1]=0;
    nlist->cycles_check[i-1]=0;

    cycles=nlist->cycles_check[i];
    boundary=nlist->imin[i];
    if (cycles < cycles_prev && boundary > nlist->imin[i-1]) {
      boundary--;
    } else if (cycles > cycles_prev && boundary < nlist->imax[i]) {
      boundary++;
    }
    nlist->imin[i]=boundary;
    nlist->imax[i-1]=boundary;
  }
  nlist->cumcycles_sort[NID-1]+=nlist->cycles_sort[NID-1];
  nlist->cumcycles_check[NID-1]+=nlist->cycles_check[NID-1];
  nlist->cycles_sort[NID-1]=0;
  nlist->cycles_check[NID-1]=0;
}

void loadbalance_f(struct_nlist* nlist)
{
  int i,NID;
  gmx_cycles_t cycles_prev,cycles;
  int boundary;

  NID=omp_get_max_threads();

  for (i=1;i<NID;i++) {
    cycles_prev=nlist->cycles_force[i-1];
    nlist->cumcycles_force[i-1]+=nlist->cycles_force[i-1];
    nlist->cycles_force[i-1]=0;

    cycles=nlist->cycles_force[i];
    boundary=nlist->imin_f[i];
    if (cycles < cycles_prev && boundary > nlist->imin_f[i-1]) {
      boundary--;
    } else if (cycles > cycles_prev && boundary < nlist->imax_f[i]) {
      boundary++;
    }
    nlist->imin_f[i]=boundary;
    nlist->imax_f[i-1]=boundary;
  }
  nlist->cumcycles_force[NID-1]+=nlist->cycles_force[NID-1];
  nlist->cycles_force[NID-1]=0;
}


void neighborsearch(struct_md* md)
{
#pragma omp master
  md->times->start=gmx_cycles_read();
#pragma omp sections
  {
#pragma omp section
  reset_shifts(md);
#pragma omp section
  {
  update_qlist(md->state->qqlist,md->state);
  neighborbin(md->state->nlelec,md->parms->rcelec,
    md->state->qqlist->nqlist,md->state->qqlist->x,md->state->box);
  }
#pragma omp section
  neighborbin(md->state->nlother,md->parms->rcother,
    md->state->N_all,md->state->x,md->state->box);
#pragma omp section
  loadbalance(md->state->nlelec);
#pragma omp section
  loadbalance(md->state->nlother);
  }
  // There is an implied barrier at the end of a SECTIONS directive, unless the NOWAIT/nowait clause is used

  neighborcheck(md->state->nlelec,NULL,md->parms->rcelec,
    md->state->qqlist->nqlist,md->state->qqlist->x,md->state->box,md->parms->flexible);

  neighborcheck(md->state->nlother,md->parms->exclparms,md->parms->rcother,
    md->state->N_all,md->state->x,md->state->box,md->parms->flexible);

#pragma omp master
  md->times->nsearch+=(gmx_cycles_read()-md->times->start);
#pragma omp barrier
}


// Loop functions
void resetforce(struct_md* md)
{
  int ID;

  ID=omp_get_thread_num();

  resetlocal_collate(md->state->atoms->f,ID);

  resetlocal_collate(md->state->manningcc_tk->f,ID);
  resetlocal_collate(md->state->manningcc_tcl->f,ID);
  resetlocal_collate(md->state->manningcc_ek->f,ID);
  resetlocal_collate(md->state->manningcc_ecl->f,ID);

  resetlocal_collate(md->state->Gt,ID);
  resetlocal_collate(md->state->Kt,ID);
}


double xlnxmx_soft(double x,double xc)
{
  if (x>xc) {
    return x*log(x)-x;
  } else {
    return 0.5*x*x/xc+(log(xc)-1)*x-0.5*xc;
  }
}


// lnx_soft = d/dx xlnxmx_soft
double lnx_soft(double x,double xc)
{
  if (x>xc) {
    return log(x);
  } else {
    return x/xc+(log(xc)-1);
  }
}


void getforce_elec(struct_md* md)
{
  struct_qlist *qqlist=md->state->qqlist;
  int ID,NID,imin,imax;
  int Ni=md->state->manningcc_tk->Ni;
  int Nf=md->state->manningcc_tk->Nf;
  int i,j,ii,jj,iii,jjj;
  vec dr;
  double r,Eij,Frij,cij,Pij;
  struct_nldata *data;
  double qi,qj,ti,tj,ei,ej;
  double tdev;
  double fr_buf,fti_buf,ftj_buf,fei_buf,fej_buf;
  double Gt=0;
  double *x;
  double *shift=md->state->shift;
  double *shiftij;
  double *q;
  double *box;
  double *theta=qqlist->theta;
  double *theta_cl=qqlist->theta_cl;
  double *eta=qqlist->eta;
  double *eta_cl=qqlist->eta_cl;
  double *bP=qqlist->bP;
  double *fx, *ft_k, *ft_cl, *fe_k, *fe_cl;
  double *pot_t, *pot_e;
  double *V1eff_inv,*V2eff_inv;
  double *condens_tk,*condens_tcl;
  double *condens_ek,*condens_ecl;
  double *dens_tk=qqlist->dens_tk;
  double *dens_tcl=qqlist->dens_tcl;
  double *dens_ek=qqlist->dens_ek;
  double *dens_ecl=qqlist->dens_ecl;
  double *dGsoftdt_tk=qqlist->dGsoftdt_tk;
  double *dGsoftdt_tcl=qqlist->dGsoftdt_tcl;
  double *dGsoftde_ek=qqlist->dGsoftde_ek;
  double *dGsoftde_ecl=qqlist->dGsoftde_ecl;
  double dV;
  double Gmix_tk,Gmix_tcl,dGmixdt_tk,dGmixdt_tcl;
  double Ghole_ek,Ghole_ecl,dGholede_ek,dGholede_ecl;
  double Gsoft_tk,Gsoft_tcl,Gsoft_ek,Gsoft_ecl,Gpot;
  double dGpotdpot,dGmixdpot,dGholedpot;
  double dGsoftdV1,dGsoftdV2,dGmixdV1,dGmixdV2,dGpotdV1,dGpotdV2;
  double *G=qqlist->G;
  double *dGdtk=qqlist->dGdtk;
  double *dGdtcl=qqlist->dGdtcl;
  double *dGdek=qqlist->dGdek;
  double *dGdecl=qqlist->dGdecl;
  double *dGdtpot=qqlist->dGdtpot;
  double *dGdepot=qqlist->dGdepot;
  double *dGdV1=qqlist->dGdV1;
  double *dGdV2=qqlist->dGdV2;
  int nqlist;
  int *qlist;
  // double lB,kappa,conc_KCl,f_KCl,V,kT,kT0,kTr0,rc,V1,V2;
  double lB,kappa,conc_KCl,conc_K,conc_Cl,V,kT,kT0,kTr0,rc,V1,V2;
  // double gauss_00=md->parms->gauss_00;
  // double gauss_01=md->parms->gauss_01;
  // double gauss_02=md->parms->gauss_02;
  // double gauss_11=md->parms->gauss_11;
  // double gauss_12=md->parms->gauss_12;
  // double gauss_22=md->parms->gauss_22;
  double k_prohibit=md->parms->k_prohibit;
  double k_soft=md->parms->k_soft;
  // Table variables
  struct_tables *tab=md->parms->elec_tables;
  // int Ntab=tab->N;
  // double hinv=tab->hinv;
  // int itab;
  // double xtab,xtab2,xtab3;
  gmx_cycles_t start,stop;

  ID=omp_get_thread_num();
  NID=omp_get_max_threads();

  x=md->state->x;
  q=md->state->q;
  box=md->state->box;
  nqlist=md->state->qqlist->nqlist;
  qlist=md->state->qqlist->qlist;

  fx=md->state->atoms->f->local[ID];
  ft_k=md->state->manningcc_tk->f->local[ID];
  ft_cl=md->state->manningcc_tcl->f->local[ID];
  fe_k=md->state->manningcc_ek->f->local[ID];
  fe_cl=md->state->manningcc_ecl->f->local[ID];

  condens_tk=resetlocal_collate(md->state->qqlist->condens_tk,ID);
  condens_tcl=resetlocal_collate(md->state->qqlist->condens_tcl,ID);
  condens_ek=resetlocal_collate(md->state->qqlist->condens_ek,ID);
  condens_ecl=resetlocal_collate(md->state->qqlist->condens_ecl,ID);
  pot_t=resetlocal_collate(md->state->qqlist->pot_t,ID);
  pot_e=resetlocal_collate(md->state->qqlist->pot_e,ID);
  V1eff_inv=resetlocal_collate(md->state->qqlist->V1eff_inv,ID);
  V2eff_inv=resetlocal_collate(md->state->qqlist->V2eff_inv,ID);

  lB=md->parms->lB;
  kappa=md->parms->kappa;
  conc_KCl=md->parms->conc_KCl;
  // f_KCl=md->parms->f_KCl;
  conc_K=md->parms->conc_K;
  conc_Cl=md->parms->conc_Cl;
  V1=md->parms->V1;
  V2=md->parms->V2;
  kT=md->parms->kT;
  kT0=md->parms->kT0;
  kTr0=md->parms->kTr0;
  rc=md->parms->rcelec;

  start=gmx_cycles_read();

  imin=md->state->nlelec->imin_f[ID];
  imax=md->state->nlelec->imax_f[ID];

  for (i=imin; i<imax; i++) {
    ii=md->state->nlelec->ii[i];
    iii=qlist[ii];
    qi=q[iii];
    ti=theta[ii]-theta_cl[ii];
    ei=eta[ii]-eta_cl[ii];
    if (bP[ii]) {
      Eij=tab->point[0][eT_DH01].A0;
      Gt+=qi*ti*Eij;
      pot_t[ii]+=qi*Eij;

      Eij=tab->point[0][eT_DH11].A0;
      Gt+=0.5*ti*ti*Eij;
      pot_t[ii]+=ti*Eij;
      
      Eij=tab->point[0][eT_DH02].A0;
      Gt+=qi*ei*Eij;
      pot_e[ii]+=qi*Eij;

      Eij=tab->point[0][eT_DH12].A0;
      Gt+=ti*ei*Eij;
      pot_t[ii]+=ei*Eij;
      pot_e[ii]+=ti*Eij;

      Eij=tab->point[0][eT_DH22].A0;
      Gt+=0.5*ei*ei*Eij;
      pot_e[ii]+=ei*Eij;

      // Pij=1.0/V1;
      Pij=tab->point[0][eT_G1].A0;
      condens_tk[ii]+=theta[ii]*Pij;
      condens_tcl[ii]+=theta_cl[ii]*Pij;
      V1eff_inv[ii]+=Pij;

      // Pij=1.0/V2;
      Pij=tab->point[0][eT_G2].A0;
      condens_ek[ii]+=eta[ii]*Pij;
      condens_ecl[ii]+=eta_cl[ii]*Pij;
      V2eff_inv[ii]+=Pij;
    }
    for (j=0; j<md->state->nlelec->jjmax[i]; j++) {
      jj=md->state->nlelec->jj[i][j];
      data=&(md->state->nlelec->nldata[i][j]);
      jjj=qlist[jj];
      shiftij=md->state->nlelec->shiftij[i][j];
      vec_subshift(x+DIM3*iii,x+DIM3*jjj,shift+DIM3*iii,shift+DIM3*jjj,shiftij,data->dr);
      // vec_subquick(x+DIM3*iii,x+DIM3*jjj,box,data->dr);
      // vec_subpbc(x+DIM3*iii,x+DIM3*jjj,box,dr);
      r=vec_mag(data->dr);
      // if (r<=rc) { // TRY
        // itab=((int) (r*hinv));
        // xtab=r*hinv-itab;
        // xtab2=xtab*xtab;
        // xtab3=xtab2*xtab;
        qj=q[jjj];
        tj=theta[jj]-theta_cl[jj];
        ej=eta[jj]-eta_cl[jj];
        fr_buf=0;

        data->r=r;
        tables_interp(tab,data);
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_00,&(data->Eij00),&(data->Frij00));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&(data->Eij01),&(data->Frij01));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&(data->Eij11),&(data->Frij11));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&(data->Eij02),&(data->Frij02));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&(data->Eij12),&(data->Frij12));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&(data->Eij22),&(data->Frij22));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&(data->Pij1),&(data->Qrij1));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&(data->Pij2),&(data->Qrij2));

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_00,&Eij,&Frij);
        Eij=data->Eij[eT_DH00];
        Frij=data->Frij[eT_DH00];
        Gt+=qi*qj*Eij;
        fr_buf+=qi*qj*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&Eij,&Frij);
        Eij=data->Eij[eT_DH01];
        Frij=data->Frij[eT_DH01];
        Gt+=(ti*qj+tj*qi)*Eij;
        fr_buf+=(ti*qj+tj*qi)*Frij;
        pot_t[ii]+=qj*Eij;
        pot_t[jj]+=qi*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&Eij,&Frij);
        Eij=data->Eij[eT_DH11];
        Frij=data->Frij[eT_DH11];
        Gt+=ti*tj*Eij;
        fr_buf+=ti*tj*Frij;
        pot_t[ii]+=tj*Eij;
        pot_t[jj]+=ti*Eij;
       
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&Eij,&Frij);
        Eij=data->Eij[eT_DH02];
        Frij=data->Frij[eT_DH02];
        Gt+=(qi*ej+qj*ei)*Eij;
        fr_buf+=(qi*ej+qj*ei)*Frij;
        pot_e[ii]+=qj*Eij;
        pot_e[jj]+=qi*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&Eij,&Frij);
        Eij=data->Eij[eT_DH12];
        Frij=data->Frij[eT_DH12];
        Gt+=(ti*ej+tj*ei)*Eij;
        fr_buf+=(ti*ej+tj*ei)*Frij;
        pot_t[ii]+=ej*Eij;
        pot_t[jj]+=ei*Eij;
        pot_e[ii]+=tj*Eij;
        pot_e[jj]+=ti*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&Eij,&Frij);
        Eij=data->Eij[eT_DH22];
        Frij=data->Frij[eT_DH22];
        Gt+=ei*ej*Eij;
        fr_buf+=ei*ej*Frij;
        pot_e[ii]+=ej*Eij;
        pot_e[jj]+=ei*Eij;

        // Pij=(1/V1)*exp(-r*r/(2*gauss_01*gauss_01));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&Pij,&Frij);
        Pij=data->Eij[eT_G1];
        Frij=data->Frij[eT_G1];
        condens_tk[ii]+=theta[jj]*Pij;
        condens_tk[jj]+=theta[ii]*Pij;
        condens_tcl[ii]+=theta_cl[jj]*Pij;
        condens_tcl[jj]+=theta_cl[ii]*Pij;
        V1eff_inv[ii]+=bP[ii]*bP[jj]*Pij;
        V1eff_inv[jj]+=bP[ii]*bP[jj]*Pij;
        // V1eff_inv[ii]+=Pij;
        // V1eff_inv[jj]+=Pij;

        // Pij=(1/V2)*exp(-r*r/(2*gauss_02*gauss_02));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&Pij,&Frij);
        Pij=data->Eij[eT_G2];
        Frij=data->Frij[eT_G2];
        condens_ek[ii]+=eta[jj]*Pij;
        condens_ek[jj]+=eta[ii]*Pij;
        condens_ecl[ii]+=eta_cl[jj]*Pij;
        condens_ecl[jj]+=eta_cl[ii]*Pij;
        V2eff_inv[ii]+=bP[ii]*bP[jj]*Pij;
        V2eff_inv[jj]+=bP[ii]*bP[jj]*Pij;
        // V2eff_inv[ii]+=Pij;
        // V2eff_inv[jj]+=Pij;

        vec_scaleinc(fx+DIM3*iii, fr_buf*(kTr0/kT0),data->dr); // Convert units
        vec_scaleinc(fx+DIM3*jjj,-fr_buf*(kTr0/kT0),data->dr); // Convert units
      // }
    }
  }
  
  stop=gmx_cycles_read();
  md->state->nlelec->cycles_force[ID]+=(stop-start);

#pragma omp barrier

  // Wait for all nodes to finish, and coallate things required to compute free energy of mixing
  start=gmx_cycles_read();
  
  condens_tk=sumlocal_collate(md->state->qqlist->condens_tk,ID);
  condens_tcl=sumlocal_collate(md->state->qqlist->condens_tcl,ID);
  condens_ek=sumlocal_collate(md->state->qqlist->condens_ek,ID);
  condens_ecl=sumlocal_collate(md->state->qqlist->condens_ecl,ID);
  pot_t=sumlocal_collate(md->state->qqlist->pot_t,ID);
  pot_e=sumlocal_collate(md->state->qqlist->pot_e,ID);
  V1eff_inv=sumlocal_collate(md->state->qqlist->V1eff_inv,ID);
  V2eff_inv=sumlocal_collate(md->state->qqlist->V2eff_inv,ID);

  // imin=(qqlist->nqlist * ID)/NID;
  // imax=(qqlist->nqlist * (ID+1))/NID;
  imin=Ni+((Nf-Ni)*ID)/NID;
  imax=Ni+((Nf-Ni)*(ID+1))/NID;

  for (i=imin; i<imax; i++) {
    if (bP[i]) { // Otherwise, all these things stay zero.
      dV=(1/V1eff_inv[i]-1/V2eff_inv[i]);

      tdev=condens_tk[i] /V1eff_inv[i]-theta[i];
      Gsoft_tk =0.5*k_soft*kT0*tdev*tdev;
      dGsoftdt_tk[i] =k_soft*kT0*tdev/V1eff_inv[i];

      tdev=condens_tcl[i]/V1eff_inv[i]-theta_cl[i];
      Gsoft_tcl=0.5*k_soft*kT0*tdev*tdev;
      dGsoftdt_tcl[i]=k_soft*kT0*tdev/V1eff_inv[i];

      dGsoftdV1=(dGsoftdt_tk[i]*condens_tk[i]+dGsoftdt_tcl[i]*condens_tcl[i])/(-V1eff_inv[i]);

      tdev=condens_ek[i] /V2eff_inv[i]-eta[i];
      Gsoft_ek =0.5*k_soft*kT0*tdev*tdev;
      dGsoftde_ek[i] =k_soft*kT0*tdev/V2eff_inv[i];

      tdev=condens_ecl[i]/V2eff_inv[i]-eta_cl[i];
      Gsoft_ecl=0.5*k_soft*kT0*tdev*tdev;
      dGsoftde_ecl[i]=k_soft*kT0*tdev/V2eff_inv[i];

      dGsoftdV2=(dGsoftde_ek[i]*condens_ek[i]+dGsoftde_ecl[i]*condens_ecl[i])/(-V2eff_inv[i]);

      dens_tk[i] =condens_tk[i] +conc_KCl-conc_K *pot_t[i]/kT;
      Gmix_tk =kT*dV*conc_K*xlnxmx_soft(dens_tk[i] /conc_K,1.0/k_prohibit);
      dGmixdt_tk =kT*dV*lnx_soft(dens_tk[i] /conc_K,1.0/k_prohibit);

      dens_tcl[i]=condens_tcl[i]+conc_KCl+conc_Cl*pot_t[i]/kT;
      Gmix_tcl=kT*dV*conc_Cl*xlnxmx_soft(dens_tcl[i]/conc_Cl,1.0/k_prohibit);
      dGmixdt_tcl=kT*dV*lnx_soft(dens_tcl[i]/conc_Cl,1.0/k_prohibit);

      dGmixdpot=-(dGmixdt_tk*conc_K-dGmixdt_tcl*conc_Cl)/kT;
      dGmixdV1= (Gmix_tk+Gmix_tcl)/(-dV*V1eff_inv[i]*V1eff_inv[i]);
      dGmixdV2=-(Gmix_tk+Gmix_tcl)/(-dV*V2eff_inv[i]*V2eff_inv[i]);

      dens_ek[i] =condens_ek[i] +condens_tk[i] +conc_KCl-conc_K *pot_e[i]/kT;
      Ghole_ek =0.5*k_prohibit*kT0*V2*V2*dens_ek[i] *dens_ek[i];
      dGholede_ek =k_prohibit*kT0*V2*V2*dens_ek[i];

      dens_ecl[i]=condens_ecl[i]+condens_tcl[i]+conc_KCl+conc_Cl*pot_e[i]/kT;
      Ghole_ecl=0.5*k_prohibit*kT0*V2*V2*dens_ecl[i]*dens_ecl[i];
      dGholede_ecl=k_prohibit*kT0*V2*V2*dens_ecl[i];

      dGholedpot=-(dGholede_ek*conc_K-dGholede_ecl*conc_Cl)/kT;

      Gpot=-0.5*dV*(conc_K+conc_Cl)/kT*pot_t[i]*pot_t[i];
      dGpotdpot=-dV*(conc_K+conc_Cl)/kT*pot_t[i];

      dGpotdV1= Gpot/(-dV*V1eff_inv[i]*V1eff_inv[i]);
      dGpotdV2=-Gpot/(-dV*V2eff_inv[i]*V2eff_inv[i]);

      G[i]=Gmix_tk+Gmix_tcl+Ghole_ek+Ghole_ecl+Gsoft_tk+Gsoft_tcl+Gsoft_ek+Gsoft_ecl+Gpot;
      dGdtk[i] =dGmixdt_tk +dGholede_ek +dGsoftdt_tk[i];
      dGdtcl[i]=dGmixdt_tcl+dGholede_ecl+dGsoftdt_tcl[i];
      dGdek[i] =dGholede_ek +dGsoftde_ek[i];
      dGdecl[i]=dGholede_ecl+dGsoftde_ecl[i];
      dGdtpot[i]=dGmixdpot+dGpotdpot;
      dGdepot[i]=dGholedpot;
      dGdV1[i]=dGmixdV1+dGsoftdV1+dGpotdV1;
      dGdV2[i]=dGmixdV2+dGsoftdV2+dGpotdV2;
    }
  }

  // stop=gmx_cycles_read();
  // md->state->nlelec[ID]->cycles+=(stop-start);

#pragma omp barrier

  // Wait for collation to finish and compute free energy of mixing
  start=gmx_cycles_read();

  imin=md->state->nlelec->imin_f[ID];
  imax=md->state->nlelec->imax_f[ID];

  for (i=imin; i<imax; i++) {
    ii=md->state->nlelec->ii[i];
    iii=qlist[ii];
    qi=q[iii];
    ti=theta[ii]-theta_cl[ii];
    ei=eta[ii]-eta_cl[ii];
    fti_buf=0;
    fei_buf=0;
    if (bP[ii]) {
      Gt+=G[i];
      // Gt+=Gmix_tk[ii]+Gmix_tcl[ii]+Ghole_ek[ii]+Ghole_ecl[ii];
      // Gt+=Gsoft_tk[ii]+Gsoft_tcl[ii]+Gsoft_ek[ii]+Gsoft_ecl[ii];
      // Gt+=Gpot[ii];

      fti_buf+=-pot_t[ii];
      fei_buf+=-pot_e[ii];

      Eij=tab->point[0][eT_DH11].A0;
      // fti_buf+=-(dGmixdpot[ii]+
      //            dGpotdpot[ii])*Eij;
      fti_buf+=-dGdtpot[ii]*Eij;

      Eij=tab->point[0][eT_DH12].A0;
      // fti_buf+=-dGholedpot[ii]*Eij;
      // fei_buf+=-(dGmixdpot[ii]+
      //            dGpotdpot[ii])*Eij;
      fti_buf+=-dGdepot[ii]*Eij;
      fei_buf+=-dGdtpot[ii]*Eij;

      Eij=tab->point[0][eT_DH22].A0;
      // fei_buf+=-dGholedpot[ii]*Eij;
      fei_buf+=-dGdepot[ii]*Eij;
      
      // Pij=1/V1;
      Pij=tab->point[0][eT_G1].A0;
      // ft_k[ii] +=-dGmixdt_tk[ii]*Pij;
      // ft_cl[ii]+=-dGmixdt_tcl[ii]*Pij;
      // ft_k[ii] +=-dGholede_ek[ii]*Pij;
      // ft_cl[ii]+=-dGholede_ecl[ii]*Pij;
      // ft_k[ii] +=-dGsoftdt_tk[ii]*(Pij-V1eff_inv[ii]); // V1eff=dV+V2eff
      // ft_cl[ii]+=-dGsoftdt_tcl[ii]*(Pij-V1eff_inv[ii]); // V1eff=dV+V2eff
      ft_k[ii] +=-dGdtk[ii]*Pij +dGsoftdt_tk[ii]*V1eff_inv[ii];
      ft_cl[ii]+=-dGdtcl[ii]*Pij+dGsoftdt_tcl[ii]*V1eff_inv[ii];

      // Pij=1/V2;
      Pij=tab->point[0][eT_G2].A0;
      // fe_k[ii] +=-dGholede_ek[ii]*Pij;
      // fe_cl[ii]+=-dGholede_ecl[ii]*Pij;
      // fe_k[ii] +=-dGsoftde_ek[ii]*(Pij-V2eff_inv[ii]);
      // fe_cl[ii]+=-dGsoftde_ecl[ii]*(Pij-V2eff_inv[ii]);
      fe_k[ii] +=-dGdek[ii]*Pij +dGsoftde_ek[ii]*V1eff_inv[ii];
      fe_cl[ii]+=-dGdecl[ii]*Pij+dGsoftde_ecl[ii]*V1eff_inv[ii];
    }
    for (j=0; j<md->state->nlelec->jjmax[i]; j++) {
      jj=md->state->nlelec->jj[i][j];
      data=&(md->state->nlelec->nldata[i][j]);
      jjj=qlist[jj];
      // shiftij=md->state->nlelec[ID]->shiftij[j];
      // vec_subshift(x+DIM3*iii,x+DIM3*jjj,shift+DIM3*iii,shift+DIM3*jjj,shiftij,dr);
      // vec_subquick(x+DIM3*iii,x+DIM3*jjj,box,dr);
      // vec_subpbc(x+DIM3*iii,x+DIM3*jjj,box,dr);
      // r=vec_mag(dr);
      // if (data->r<=rc) { // TRY
        qj=q[jjj];
        tj=theta[jj]-theta_cl[jj];
        ej=eta[jj]-eta_cl[jj];
        fr_buf=0;
        ftj_buf=0;
        fej_buf=0;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&Eij,&Frij);
        Eij=data->Eij[eT_DH01];
        Frij=data->Frij[eT_DH01];
        // fr_buf+=(qi*dGmixdpot[jj]+qj*dGmixdpot[ii]+
        //          qi*dGpotdpot[jj]+qj*dGpotdpot[ii])*Frij;
        fr_buf+=(qi*dGdtpot[jj]+qj*dGdtpot[ii])*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&Eij,&Frij);
        Eij=data->Eij[eT_DH11];
        Frij=data->Frij[eT_DH11];
        // fr_buf+=(ti*dGmixdpot[jj]+tj*dGmixdpot[ii]+
        //          ti*dGpotdpot[jj]+tj*dGpotdpot[ii])*Frij;
        // fti_buf+=-(dGmixdpot[jj]+
        //            dGpotdpot[jj])*Eij;
        // ftj_buf+=-(dGmixdpot[ii]+
        //            dGpotdpot[ii])*Eij;
        fr_buf+=(ti*dGdtpot[jj]+tj*dGdtpot[ii])*Frij;
        fti_buf+=-(dGdtpot[jj])*Eij;
        ftj_buf+=-(dGdtpot[ii])*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&Eij,&Frij);
        Eij=data->Eij[eT_DH02];
        Frij=data->Frij[eT_DH02];
        // fr_buf+=(qi*dGholedpot[jj]+qj*dGholedpot[ii])*Frij;
        fr_buf+=(qi*dGdepot[jj]+qj*dGdepot[ii])*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&Eij,&Frij);
        Eij=data->Eij[eT_DH12];
        Frij=data->Frij[eT_DH12];
        // fr_buf+=(ei*dGmixdpot[jj]+ej*dGmixdpot[ii]+
        //          ti*dGholedpot[jj]+tj*dGholedpot[ii]+
        //          ei*dGpotdpot[jj]+ej*dGpotdpot[ii])*Frij;
        // fti_buf+=-dGholedpot[jj]*Eij;
        // ftj_buf+=-dGholedpot[ii]*Eij;
        // fei_buf+=-(dGmixdpot[jj]+
        //            dGpotdpot[jj])*Eij;
        // fej_buf+=-(dGmixdpot[ii]+
        //            dGpotdpot[ii])*Eij;
        fr_buf+=(ei*dGdtpot[jj]+ej*dGdtpot[ii]+ti*dGdepot[jj]+tj*dGdepot[ii])*Frij;
        fti_buf+=-dGdepot[jj]*Eij;
        ftj_buf+=-dGdepot[ii]*Eij;
        fei_buf+=-dGdtpot[jj]*Eij;
        fej_buf+=-dGdtpot[ii]*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&Eij,&Frij);
        Eij=data->Eij[eT_DH22];
        Frij=data->Frij[eT_DH22];
        // fr_buf+=(ei*dGholedpot[jj]+ej*dGholedpot[ii])*Frij;
        // fei_buf+=-dGholedpot[jj]*Eij;
        // fej_buf+=-dGholedpot[ii]*Eij;
        fr_buf+=(ei*dGdepot[jj]+ej*dGdepot[ii])*Frij;
        fei_buf+=-dGdepot[jj]*Eij;
        fej_buf+=-dGdepot[ii]*Eij;

        // if (bP[ii] && bP[jj]) { // TRY
          // Pij=(1/V1)*exp(-r*r/(2*gauss_01*gauss_01));
          // Frij=Pij/(gauss_01*gauss_01);
          // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&Pij,&Frij);
          // Pij=data->Eij[eT_G1];
          // Frij=data->Frij[eT_G1];
          Pij=bP[ii]*bP[jj]*data->Eij[eT_G1];
          Frij=bP[ii]*bP[jj]*data->Frij[eT_G1];
          // Pij=data->Eij[eT_G1];
          // Frij=data->Frij[eT_G1];
          // fr_buf+=(dGmixdt_tk[jj]*theta[ii]+dGmixdt_tk[ii]*theta[jj]+dGmixdt_tcl[jj]*theta_cl[ii]+dGmixdt_tcl[ii]*theta_cl[jj])*Frij;
          // fr_buf+=(dGholede_ek[jj]*theta[ii]+dGholede_ek[ii]*theta[jj]+dGholede_ecl[jj]*theta_cl[ii]+dGholede_ecl[ii]*theta_cl[jj])*Frij;
          // fr_buf+=(dGsoftdt_tk[jj]*theta[ii]+dGsoftdt_tcl[jj]*theta_cl[ii]+dGsoftdt_tk[ii]*theta[jj]+dGsoftdt_tcl[ii]*theta_cl[jj])*Frij;
          // ft_k[ii] +=-dGmixdt_tk[jj]*Pij;
          // ft_k[jj] +=-dGmixdt_tk[ii]*Pij;
          // ft_cl[ii]+=-dGmixdt_tcl[jj]*Pij;
          // ft_cl[jj]+=-dGmixdt_tcl[ii]*Pij;
          // ft_k[ii] +=-dGholede_ek[jj]*Pij;
          // ft_k[jj] +=-dGholede_ek[ii]*Pij;
          // ft_cl[ii]+=-dGholede_ecl[jj]*Pij;
          // ft_cl[jj]+=-dGholede_ecl[ii]*Pij;
          // ft_k[ii] +=-dGsoftdt_tk[jj]*Pij;
          // ft_k[jj] +=-dGsoftdt_tk[ii]*Pij;
          // ft_cl[ii]+=-dGsoftdt_tcl[jj]*Pij;
          // ft_cl[jj]+=-dGsoftdt_tcl[ii]*Pij;
          // fr_buf+=(dGmixdV1[jj]+dGmixdV1[ii])*Frij;
          // fr_buf+=(dGsoftdV1[jj]+dGsoftdV1[ii])*Frij;
          // fr_buf+=(dGpotdV1[jj]+dGpotdV1[ii])*Frij;
          fr_buf+=(dGdtk[jj]*theta[ii]+dGdtk[ii]*theta[jj]+dGdtcl[jj]*theta_cl[ii]+dGdtcl[ii]*theta_cl[jj])*Frij;
          ft_k[ii] +=-dGdtk[jj]*Pij;
          ft_k[jj] +=-dGdtk[ii]*Pij;
          ft_cl[ii]+=-dGdtcl[jj]*Pij;
          ft_cl[jj]+=-dGdtcl[ii]*Pij;
          fr_buf+=(dGdV1[jj]+dGdV1[ii])*Frij;

          // Pij=(1/V2)*exp(-r*r/(2*gauss_02*gauss_02));
          // Frij=Pij/(gauss_02*gauss_02);
          // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&Pij,&Frij);
          // Pij=data->Eij[eT_G2];
          // Frij=data->Frij[eT_G2];
          Pij=bP[ii]*bP[jj]*data->Eij[eT_G2];
          Frij=bP[ii]*bP[jj]*data->Frij[eT_G2];
          // Pij=data->Eij[eT_G2];
          // Frij=data->Frij[eT_G2];
          // fr_buf+=(dGholede_ek[jj]*eta[ii]+dGholede_ek[ii]*eta[jj]+dGholede_ecl[jj]*eta_cl[ii]+dGholede_ecl[ii]*eta_cl[jj])*Frij;
          // fe_k[ii] +=-dGholede_ek[jj]*Pij;
          // fe_k[jj] +=-dGholede_ek[ii]*Pij;
          // fe_cl[ii]+=-dGholede_ecl[jj]*Pij;
          // fe_cl[jj]+=-dGholede_ecl[ii]*Pij;
          // fr_buf+=(dGsoftde_ek[jj]*eta[ii]+dGsoftde_ecl[jj]*eta_cl[ii]+dGsoftde_ek[ii]*eta[jj]+dGsoftde_ecl[ii]*eta_cl[jj])*Frij;
          // fe_k[ii] +=-dGsoftde_ek[jj]*Pij;
          // fe_k[jj] +=-dGsoftde_ek[ii]*Pij;
          // fe_cl[ii]+=-dGsoftde_ecl[jj]*Pij;
          // fe_cl[jj]+=-dGsoftde_ecl[ii]*Pij;
          // fr_buf+=(dGmixdV2[jj]+dGmixdV2[ii])*Frij;
          // fr_buf+=(dGsoftdV2[jj]+dGsoftdV2[ii])*Frij;
          // fr_buf+=(dGpotdV2[jj]+dGpotdV2[ii])*Frij;
          fr_buf+=(dGdek[jj]*eta[ii]+dGdek[ii]*eta[jj]+dGdecl[jj]*eta_cl[ii]+dGdecl[ii]*eta_cl[jj])*Frij;
          fe_k[ii] +=-dGdek[jj]*Pij;
          fe_k[jj] +=-dGdek[ii]*Pij;
          fe_cl[ii]+=-dGdecl[jj]*Pij;
          fe_cl[jj]+=-dGdecl[ii]*Pij;
          fr_buf+=(dGdV2[jj]+dGdV2[ii])*Frij;
        // }

        vec_scaleinc(fx+DIM3*iii, fr_buf*(kTr0/kT0),data->dr); // Convert units
        vec_scaleinc(fx+DIM3*jjj,-fr_buf*(kTr0/kT0),data->dr); // Convert units

        ft_k[jj] += ftj_buf;
        ft_cl[jj]+=-ftj_buf;
        fe_k[jj] += fej_buf;
        fe_cl[jj]+=-fej_buf;
      // }
    }
    ft_k[ii] += fti_buf;
    ft_cl[ii]+=-fti_buf;
    fe_k[ii] += fei_buf;
    fe_cl[ii]+=-fei_buf;
  }

  md->state->Gt->local[ID][0]+=Gt*(kTr0/kT0); // Convert units

  stop=gmx_cycles_read();
  md->state->nlelec->cycles_force[ID]+=(stop-start);
}


void getforce_elec_v2(struct_md* md)
{
  struct_qlist *qqlist=md->state->qqlist;
  int ID,NID,imin,imax;
  int Ni=md->state->manningcc_tk->Ni;
  int Nf=md->state->manningcc_tk->Nf;
  int i,j,ii,jj,iii,jjj;
  vec dr;
  double r,Eij,Frij,cij,Pij;
  struct_nldata *data;
  double qi,qj,ti,tj,ei,ej;
  double tdev;
  double fr_buf,fti_buf,ftj_buf,fei_buf,fej_buf;
  double Gt=0;
  double *x;
  double *shift=md->state->shift;
  double *shiftij;
  double *q;
  double *box;
  double *theta=qqlist->theta;
  double *theta_cl=qqlist->theta_cl;
  double *eta=qqlist->eta;
  double *eta_cl=qqlist->eta_cl;
  double *bP=qqlist->bP;
  double *fx, *ft_k, *ft_cl, *fe_k, *fe_cl;
  double *pot_t, *pot_e;
  double *V1eff_inv,*V2eff_inv;
  // double *condens_tk,*condens_tcl;
  // double *condens_ek,*condens_ecl;
  double *dens_tk=qqlist->dens_tk;
  double *dens_tcl=qqlist->dens_tcl;
  double *dens_ek=qqlist->dens_ek;
  double *dens_ecl=qqlist->dens_ecl;
  double *dGsoftdt_tk=qqlist->dGsoftdt_tk;
  double *dGsoftdt_tcl=qqlist->dGsoftdt_tcl;
  double *dGsoftde_ek=qqlist->dGsoftde_ek;
  double *dGsoftde_ecl=qqlist->dGsoftde_ecl;
  double dV;
  double Gmix_tk,Gmix_tcl,dGmixdt_tk,dGmixdt_tcl;
  double Ghole_ek,Ghole_ecl,dGholede_ek,dGholede_ecl;
  // double Gsoft_tk,Gsoft_tcl,Gsoft_ek,Gsoft_ecl,Gpot;
  double Gpot;
  double dGpotdpot,dGmixdpot,dGholedpot;
  // double dGsoftdV1,dGsoftdV2,dGmixdV1,dGmixdV2,dGpotdV1,dGpotdV2;
  double dGmixdV1,dGmixdV2,dGpotdV1,dGpotdV2;
  double dGholedV1,dGholedV2;
  double *G=qqlist->G;
  double *dGdtk=qqlist->dGdtk;
  double *dGdtcl=qqlist->dGdtcl;
  double *dGdek=qqlist->dGdek;
  double *dGdecl=qqlist->dGdecl;
  double *dGdtpot=qqlist->dGdtpot;
  double *dGdepot=qqlist->dGdepot;
  double *dGdV1=qqlist->dGdV1;
  double *dGdV2=qqlist->dGdV2;
  int nqlist;
  int *qlist;
  // double lB,kappa,conc_KCl,f_KCl,V,kT,kT0,kTr0,rc,V1,V2;
  double lB,kappa,conc_KCl,conc_K,conc_Cl,V,kT,kT0,kTr0,rc,V1,V2;
  // double gauss_00=md->parms->gauss_00;
  // double gauss_01=md->parms->gauss_01;
  // double gauss_02=md->parms->gauss_02;
  // double gauss_11=md->parms->gauss_11;
  // double gauss_12=md->parms->gauss_12;
  // double gauss_22=md->parms->gauss_22;
  double k_prohibit=md->parms->k_prohibit;
  double k_soft=md->parms->k_soft;
  // Table variables
  struct_tables *tab=md->parms->elec_tables;
  // int Ntab=tab->N;
  // double hinv=tab->hinv;
  // int itab;
  // double xtab,xtab2,xtab3;
  gmx_cycles_t start,stop;

  ID=omp_get_thread_num();
  NID=omp_get_max_threads();

  x=md->state->x;
  q=md->state->q;
  box=md->state->box;
  nqlist=md->state->qqlist->nqlist;
  qlist=md->state->qqlist->qlist;

  fx=md->state->atoms->f->local[ID];
  ft_k=md->state->manningcc_tk->f->local[ID];
  ft_cl=md->state->manningcc_tcl->f->local[ID];
  fe_k=md->state->manningcc_ek->f->local[ID];
  fe_cl=md->state->manningcc_ecl->f->local[ID];

  // condens_tk=resetlocal_collate(md->state->qqlist->condens_tk,ID);
  // condens_tcl=resetlocal_collate(md->state->qqlist->condens_tcl,ID);
  // condens_ek=resetlocal_collate(md->state->qqlist->condens_ek,ID);
  // condens_ecl=resetlocal_collate(md->state->qqlist->condens_ecl,ID);
  pot_t=resetlocal_collate(md->state->qqlist->pot_t,ID);
  pot_e=resetlocal_collate(md->state->qqlist->pot_e,ID);
  V1eff_inv=resetlocal_collate(md->state->qqlist->V1eff_inv,ID);
  V2eff_inv=resetlocal_collate(md->state->qqlist->V2eff_inv,ID);

  lB=md->parms->lB;
  kappa=md->parms->kappa;
  conc_KCl=md->parms->conc_KCl;
  // f_KCl=md->parms->f_KCl;
  conc_K=md->parms->conc_K;
  conc_Cl=md->parms->conc_Cl;
  V1=md->parms->V1;
  V2=md->parms->V2;
  kT=md->parms->kT;
  kT0=md->parms->kT0;
  kTr0=md->parms->kTr0;
  rc=md->parms->rcelec;

  start=gmx_cycles_read();

  imin=md->state->nlelec->imin_f[ID];
  imax=md->state->nlelec->imax_f[ID];

  for (i=imin; i<imax; i++) {
    ii=md->state->nlelec->ii[i];
    iii=qlist[ii];
    qi=q[iii];
    ti=theta[ii]-theta_cl[ii];
    ei=eta[ii]-eta_cl[ii];
    if (bP[ii]) {
      Eij=tab->point[0][eT_DH01].A0;
      Gt+=qi*ti*Eij;
      pot_t[ii]+=qi*Eij;

      Eij=tab->point[0][eT_DH11].A0;
      Gt+=0.5*ti*ti*Eij;
      pot_t[ii]+=ti*Eij;
      
      Eij=tab->point[0][eT_DH02].A0;
      Gt+=qi*ei*Eij;
      pot_e[ii]+=qi*Eij;

      Eij=tab->point[0][eT_DH12].A0;
      Gt+=ti*ei*Eij;
      pot_t[ii]+=ei*Eij;
      pot_e[ii]+=ti*Eij;

      Eij=tab->point[0][eT_DH22].A0;
      Gt+=0.5*ei*ei*Eij;
      pot_e[ii]+=ei*Eij;

      // Pij=1.0/V1;
      Pij=tab->point[0][eT_G1].A0;
      // condens_tk[ii]+=theta[ii]*Pij;
      // condens_tcl[ii]+=theta_cl[ii]*Pij;
      V1eff_inv[ii]+=Pij;

      // Pij=1.0/V2;
      Pij=tab->point[0][eT_G2].A0;
      // condens_ek[ii]+=eta[ii]*Pij;
      // condens_ecl[ii]+=eta_cl[ii]*Pij;
      V2eff_inv[ii]+=Pij;
    }
    for (j=0; j<md->state->nlelec->jjmax[i]; j++) {
      jj=md->state->nlelec->jj[i][j];
      data=&(md->state->nlelec->nldata[i][j]);
      jjj=qlist[jj];
      shiftij=md->state->nlelec->shiftij[i][j];
      vec_subshift(x+DIM3*iii,x+DIM3*jjj,shift+DIM3*iii,shift+DIM3*jjj,shiftij,data->dr);
      // vec_subquick(x+DIM3*iii,x+DIM3*jjj,box,data->dr);
      // vec_subpbc(x+DIM3*iii,x+DIM3*jjj,box,dr);
      r=vec_mag(data->dr);
      // if (r<=rc) { // TRY
        // itab=((int) (r*hinv));
        // xtab=r*hinv-itab;
        // xtab2=xtab*xtab;
        // xtab3=xtab2*xtab;
        qj=q[jjj];
        tj=theta[jj]-theta_cl[jj];
        ej=eta[jj]-eta_cl[jj];
        fr_buf=0;

        data->r=r;
        tables_interp(tab,data);
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_00,&(data->Eij00),&(data->Frij00));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&(data->Eij01),&(data->Frij01));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&(data->Eij11),&(data->Frij11));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&(data->Eij02),&(data->Frij02));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&(data->Eij12),&(data->Frij12));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&(data->Eij22),&(data->Frij22));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&(data->Pij1),&(data->Qrij1));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&(data->Pij2),&(data->Qrij2));

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_00,&Eij,&Frij);
        Eij=data->Eij[eT_DH00];
        Frij=data->Frij[eT_DH00];
        Gt+=qi*qj*Eij;
        fr_buf+=qi*qj*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&Eij,&Frij);
        Eij=data->Eij[eT_DH01];
        Frij=data->Frij[eT_DH01];
        Gt+=(ti*qj+tj*qi)*Eij;
        fr_buf+=(ti*qj+tj*qi)*Frij;
        pot_t[ii]+=qj*Eij;
        pot_t[jj]+=qi*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&Eij,&Frij);
        Eij=data->Eij[eT_DH11];
        Frij=data->Frij[eT_DH11];
        Gt+=ti*tj*Eij;
        fr_buf+=ti*tj*Frij;
        pot_t[ii]+=tj*Eij;
        pot_t[jj]+=ti*Eij;
       
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&Eij,&Frij);
        Eij=data->Eij[eT_DH02];
        Frij=data->Frij[eT_DH02];
        Gt+=(qi*ej+qj*ei)*Eij;
        fr_buf+=(qi*ej+qj*ei)*Frij;
        pot_e[ii]+=qj*Eij;
        pot_e[jj]+=qi*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&Eij,&Frij);
        Eij=data->Eij[eT_DH12];
        Frij=data->Frij[eT_DH12];
        Gt+=(ti*ej+tj*ei)*Eij;
        fr_buf+=(ti*ej+tj*ei)*Frij;
        pot_t[ii]+=ej*Eij;
        pot_t[jj]+=ei*Eij;
        pot_e[ii]+=tj*Eij;
        pot_e[jj]+=ti*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&Eij,&Frij);
        Eij=data->Eij[eT_DH22];
        Frij=data->Frij[eT_DH22];
        Gt+=ei*ej*Eij;
        fr_buf+=ei*ej*Frij;
        pot_e[ii]+=ej*Eij;
        pot_e[jj]+=ei*Eij;

        // Pij=(1/V1)*exp(-r*r/(2*gauss_01*gauss_01));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&Pij,&Frij);
        Pij=data->Eij[eT_G1];
        Frij=data->Frij[eT_G1];
        // condens_tk[ii]+=theta[jj]*Pij;
        // condens_tk[jj]+=theta[ii]*Pij;
        // condens_tcl[ii]+=theta_cl[jj]*Pij;
        // condens_tcl[jj]+=theta_cl[ii]*Pij;
        V1eff_inv[ii]+=bP[ii]*bP[jj]*Pij;
        V1eff_inv[jj]+=bP[ii]*bP[jj]*Pij;
        // V1eff_inv[ii]+=Pij;
        // V1eff_inv[jj]+=Pij;

        // Pij=(1/V2)*exp(-r*r/(2*gauss_02*gauss_02));
        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&Pij,&Frij);
        Pij=data->Eij[eT_G2];
        Frij=data->Frij[eT_G2];
        // condens_ek[ii]+=eta[jj]*Pij;
        // condens_ek[jj]+=eta[ii]*Pij;
        // condens_ecl[ii]+=eta_cl[jj]*Pij;
        // condens_ecl[jj]+=eta_cl[ii]*Pij;
        V2eff_inv[ii]+=bP[ii]*bP[jj]*Pij;
        V2eff_inv[jj]+=bP[ii]*bP[jj]*Pij;
        // V2eff_inv[ii]+=Pij;
        // V2eff_inv[jj]+=Pij;

        vec_scaleinc(fx+DIM3*iii, fr_buf*(kTr0/kT0),data->dr); // Convert units
        vec_scaleinc(fx+DIM3*jjj,-fr_buf*(kTr0/kT0),data->dr); // Convert units
      // }
    }
  }
  
  stop=gmx_cycles_read();
  md->state->nlelec->cycles_force[ID]+=(stop-start);

#pragma omp barrier

  // Wait for all nodes to finish, and coallate things required to compute free energy of mixing
  start=gmx_cycles_read();
  
  // condens_tk=sumlocal_collate(md->state->qqlist->condens_tk,ID);
  // condens_tcl=sumlocal_collate(md->state->qqlist->condens_tcl,ID);
  // condens_ek=sumlocal_collate(md->state->qqlist->condens_ek,ID);
  // condens_ecl=sumlocal_collate(md->state->qqlist->condens_ecl,ID);
  pot_t=sumlocal_collate(md->state->qqlist->pot_t,ID);
  pot_e=sumlocal_collate(md->state->qqlist->pot_e,ID);
  V1eff_inv=sumlocal_collate(md->state->qqlist->V1eff_inv,ID);
  V2eff_inv=sumlocal_collate(md->state->qqlist->V2eff_inv,ID);

  // imin=(qqlist->nqlist * ID)/NID;
  // imax=(qqlist->nqlist * (ID+1))/NID;
  imin=Ni+((Nf-Ni)*ID)/NID;
  imax=Ni+((Nf-Ni)*(ID+1))/NID;

  for (i=imin; i<imax; i++) {
    if (bP[i]) { // Otherwise, all these things stay zero.
      dV=(1/V1eff_inv[i]-1/V2eff_inv[i]);

      // tdev=condens_tk[i] /V1eff_inv[i]-theta[i];
      // Gsoft_tk =0.5*k_soft*kT0*tdev*tdev;
      // dGsoftdt_tk[i] =k_soft*kT0*tdev/V1eff_inv[i];

      // tdev=condens_tcl[i]/V1eff_inv[i]-theta_cl[i];
      // Gsoft_tcl=0.5*k_soft*kT0*tdev*tdev;
      // dGsoftdt_tcl[i]=k_soft*kT0*tdev/V1eff_inv[i];

      // dGsoftdV1=(dGsoftdt_tk[i]*condens_tk[i]+dGsoftdt_tcl[i]*condens_tcl[i])/(-V1eff_inv[i]);

      // tdev=condens_ek[i] /V2eff_inv[i]-eta[i];
      // Gsoft_ek =0.5*k_soft*kT0*tdev*tdev;
      // dGsoftde_ek[i] =k_soft*kT0*tdev/V2eff_inv[i];

      // tdev=condens_ecl[i]/V2eff_inv[i]-eta_cl[i];
      // Gsoft_ecl=0.5*k_soft*kT0*tdev*tdev;
      // dGsoftde_ecl[i]=k_soft*kT0*tdev/V2eff_inv[i];

      // dGsoftdV2=(dGsoftde_ek[i]*condens_ek[i]+dGsoftde_ecl[i]*condens_ecl[i])/(-V2eff_inv[i]);

      dens_tk[i] =theta[i]   *V1eff_inv[i]+conc_KCl-conc_K *pot_t[i]/kT;
      Gmix_tk =kT*dV*conc_K*xlnxmx_soft(dens_tk[i] /conc_K,1.0/k_prohibit);
      dGmixdt_tk =kT*dV*lnx_soft(dens_tk[i] /conc_K,1.0/k_prohibit);

      dens_tcl[i]=theta_cl[i]*V1eff_inv[i]+conc_KCl+conc_Cl*pot_t[i]/kT;
      Gmix_tcl=kT*dV*conc_Cl*xlnxmx_soft(dens_tcl[i]/conc_Cl,1.0/k_prohibit);
      dGmixdt_tcl=kT*dV*lnx_soft(dens_tcl[i]/conc_Cl,1.0/k_prohibit);

      dGmixdpot=-(dGmixdt_tk*conc_K-dGmixdt_tcl*conc_Cl)/kT;
      dGmixdV1= (Gmix_tk+Gmix_tcl)/(-dV*V1eff_inv[i]*V1eff_inv[i]);
      dGmixdV1+=(dGmixdt_tk*theta[i]+dGmixdt_tcl*theta_cl[i]);
      dGmixdV2=-(Gmix_tk+Gmix_tcl)/(-dV*V2eff_inv[i]*V2eff_inv[i]);

      dens_ek[i] =eta[i]   *V2eff_inv[i]+theta[i] *V1eff_inv[i]+conc_KCl-conc_K *pot_e[i]/kT;
      Ghole_ek =0.5*k_prohibit*kT0*V2*V2*dens_ek[i] *dens_ek[i];
      dGholede_ek =k_prohibit*kT0*V2*V2*dens_ek[i];

      dens_ecl[i]=eta_cl[i]*V2eff_inv[i]+theta_cl[i]*V1eff_inv[i]+conc_KCl+conc_Cl*pot_e[i]/kT;
      Ghole_ecl=0.5*k_prohibit*kT0*V2*V2*dens_ecl[i]*dens_ecl[i];
      dGholede_ecl=k_prohibit*kT0*V2*V2*dens_ecl[i];

      dGholedpot=-(dGholede_ek*conc_K-dGholede_ecl*conc_Cl)/kT;
      dGholedV1=dGholede_ek*theta[i]+dGholede_ecl*theta_cl[i];
      dGholedV2=dGholede_ek*eta[i]  +dGholede_ecl*eta_cl[i];

      Gpot=-0.5*dV*(conc_K+conc_Cl)/kT*pot_t[i]*pot_t[i];
      dGpotdpot=-dV*(conc_K+conc_Cl)/kT*pot_t[i];

      dGpotdV1= Gpot/(-dV*V1eff_inv[i]*V1eff_inv[i]);
      dGpotdV2=-Gpot/(-dV*V2eff_inv[i]*V2eff_inv[i]);

      // G[i]=Gmix_tk+Gmix_tcl+Ghole_ek+Ghole_ecl+Gsoft_tk+Gsoft_tcl+Gsoft_ek+Gsoft_ecl+Gpot;
      G[i]=Gmix_tk+Gmix_tcl+Ghole_ek+Ghole_ecl+Gpot;
      // dGdtk[i] =dGmixdt_tk +dGholede_ek +dGsoftdt_tk[i];
      // dGdtcl[i]=dGmixdt_tcl+dGholede_ecl+dGsoftdt_tcl[i];
      dGdtk[i] =(dGmixdt_tk +dGholede_ek )*V1eff_inv[i];
      dGdtcl[i]=(dGmixdt_tcl+dGholede_ecl)*V1eff_inv[i];
      // dGdek[i] =dGholede_ek +dGsoftde_ek[i];
      // dGdecl[i]=dGholede_ecl+dGsoftde_ecl[i];
      dGdek[i] =dGholede_ek *V2eff_inv[i];
      dGdecl[i]=dGholede_ecl*V2eff_inv[i];
      dGdtpot[i]=dGmixdpot+dGpotdpot;
      dGdepot[i]=dGholedpot;
      // dGdV1[i]=dGmixdV1+dGsoftdV1+dGpotdV1;
      // dGdV2[i]=dGmixdV2+dGsoftdV2+dGpotdV2;
      dGdV1[i]=dGmixdV1+dGholedV1+dGpotdV1;
      dGdV2[i]=dGmixdV2+dGholedV2+dGpotdV2;
    }
  }

  // stop=gmx_cycles_read();
  // md->state->nlelec[ID]->cycles+=(stop-start);

#pragma omp barrier

  // Wait for collation to finish and compute free energy of mixing
  start=gmx_cycles_read();

  imin=md->state->nlelec->imin_f[ID];
  imax=md->state->nlelec->imax_f[ID];

  for (i=imin; i<imax; i++) {
    ii=md->state->nlelec->ii[i];
    iii=qlist[ii];
    qi=q[iii];
    ti=theta[ii]-theta_cl[ii];
    ei=eta[ii]-eta_cl[ii];
    fti_buf=0;
    fei_buf=0;
    if (bP[ii]) {
      Gt+=G[i];
      // Gt+=Gmix_tk[ii]+Gmix_tcl[ii]+Ghole_ek[ii]+Ghole_ecl[ii];
      // Gt+=Gsoft_tk[ii]+Gsoft_tcl[ii]+Gsoft_ek[ii]+Gsoft_ecl[ii];
      // Gt+=Gpot[ii];

      fti_buf+=-pot_t[ii];
      fei_buf+=-pot_e[ii];

      Eij=tab->point[0][eT_DH11].A0;
      // fti_buf+=-(dGmixdpot[ii]+
      //            dGpotdpot[ii])*Eij;
      fti_buf+=-dGdtpot[ii]*Eij;

      Eij=tab->point[0][eT_DH12].A0;
      // fti_buf+=-dGholedpot[ii]*Eij;
      // fei_buf+=-(dGmixdpot[ii]+
      //            dGpotdpot[ii])*Eij;
      fti_buf+=-dGdepot[ii]*Eij;
      fei_buf+=-dGdtpot[ii]*Eij;

      Eij=tab->point[0][eT_DH22].A0;
      // fei_buf+=-dGholedpot[ii]*Eij;
      fei_buf+=-dGdepot[ii]*Eij;
      
      // Pij=1/V1;
      // Pij=tab->point[0][eT_G1].A0;
      // ft_k[ii] +=-dGmixdt_tk[ii]*Pij;
      // ft_cl[ii]+=-dGmixdt_tcl[ii]*Pij;
      // ft_k[ii] +=-dGholede_ek[ii]*Pij;
      // ft_cl[ii]+=-dGholede_ecl[ii]*Pij;
      // ft_k[ii] +=-dGsoftdt_tk[ii]*(Pij-V1eff_inv[ii]); // V1eff=dV+V2eff
      // ft_cl[ii]+=-dGsoftdt_tcl[ii]*(Pij-V1eff_inv[ii]); // V1eff=dV+V2eff
      // ft_k[ii] +=-dGdtk[ii]*Pij +dGsoftdt_tk[ii]*V1eff_inv[ii];
      // ft_cl[ii]+=-dGdtcl[ii]*Pij+dGsoftdt_tcl[ii]*V1eff_inv[ii];
      ft_k[ii] +=-dGdtk[ii];
      ft_cl[ii]+=-dGdtcl[ii];

      // Pij=1/V2;
      // Pij=tab->point[0][eT_G2].A0;
      // fe_k[ii] +=-dGholede_ek[ii]*Pij;
      // fe_cl[ii]+=-dGholede_ecl[ii]*Pij;
      // fe_k[ii] +=-dGsoftde_ek[ii]*(Pij-V2eff_inv[ii]);
      // fe_cl[ii]+=-dGsoftde_ecl[ii]*(Pij-V2eff_inv[ii]);
      // fe_k[ii] +=-dGdek[ii]*Pij +dGsoftde_ek[ii]*V1eff_inv[ii];
      // fe_cl[ii]+=-dGdecl[ii]*Pij+dGsoftde_ecl[ii]*V1eff_inv[ii];
      fe_k[ii] +=-dGdek[ii];
      fe_cl[ii]+=-dGdecl[ii];
    }
    for (j=0; j<md->state->nlelec->jjmax[i]; j++) {
      jj=md->state->nlelec->jj[i][j];
      data=&(md->state->nlelec->nldata[i][j]);
      jjj=qlist[jj];
      // shiftij=md->state->nlelec[ID]->shiftij[j];
      // vec_subshift(x+DIM3*iii,x+DIM3*jjj,shift+DIM3*iii,shift+DIM3*jjj,shiftij,dr);
      // vec_subquick(x+DIM3*iii,x+DIM3*jjj,box,dr);
      // vec_subpbc(x+DIM3*iii,x+DIM3*jjj,box,dr);
      // r=vec_mag(dr);
      // if (data->r<=rc) { // TRY
        qj=q[jjj];
        tj=theta[jj]-theta_cl[jj];
        ej=eta[jj]-eta_cl[jj];
        fr_buf=0;
        ftj_buf=0;
        fej_buf=0;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_01,&Eij,&Frij);
        Eij=data->Eij[eT_DH01];
        Frij=data->Frij[eT_DH01];
        // fr_buf+=(qi*dGmixdpot[jj]+qj*dGmixdpot[ii]+
        //          qi*dGpotdpot[jj]+qj*dGpotdpot[ii])*Frij;
        fr_buf+=(qi*dGdtpot[jj]+qj*dGdtpot[ii])*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_11,&Eij,&Frij);
        Eij=data->Eij[eT_DH11];
        Frij=data->Frij[eT_DH11];
        // fr_buf+=(ti*dGmixdpot[jj]+tj*dGmixdpot[ii]+
        //          ti*dGpotdpot[jj]+tj*dGpotdpot[ii])*Frij;
        // fti_buf+=-(dGmixdpot[jj]+
        //            dGpotdpot[jj])*Eij;
        // ftj_buf+=-(dGmixdpot[ii]+
        //            dGpotdpot[ii])*Eij;
        fr_buf+=(ti*dGdtpot[jj]+tj*dGdtpot[ii])*Frij;
        fti_buf+=-(dGdtpot[jj])*Eij;
        ftj_buf+=-(dGdtpot[ii])*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_02,&Eij,&Frij);
        Eij=data->Eij[eT_DH02];
        Frij=data->Frij[eT_DH02];
        // fr_buf+=(qi*dGholedpot[jj]+qj*dGholedpot[ii])*Frij;
        fr_buf+=(qi*dGdepot[jj]+qj*dGdepot[ii])*Frij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_12,&Eij,&Frij);
        Eij=data->Eij[eT_DH12];
        Frij=data->Frij[eT_DH12];
        // fr_buf+=(ei*dGmixdpot[jj]+ej*dGmixdpot[ii]+
        //          ti*dGholedpot[jj]+tj*dGholedpot[ii]+
        //          ei*dGpotdpot[jj]+ej*dGpotdpot[ii])*Frij;
        // fti_buf+=-dGholedpot[jj]*Eij;
        // ftj_buf+=-dGholedpot[ii]*Eij;
        // fei_buf+=-(dGmixdpot[jj]+
        //            dGpotdpot[jj])*Eij;
        // fej_buf+=-(dGmixdpot[ii]+
        //            dGpotdpot[ii])*Eij;
        fr_buf+=(ei*dGdtpot[jj]+ej*dGdtpot[ii]+ti*dGdepot[jj]+tj*dGdepot[ii])*Frij;
        fti_buf+=-dGdepot[jj]*Eij;
        ftj_buf+=-dGdepot[ii]*Eij;
        fei_buf+=-dGdtpot[jj]*Eij;
        fej_buf+=-dGdtpot[ii]*Eij;

        // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->DH_22,&Eij,&Frij);
        Eij=data->Eij[eT_DH22];
        Frij=data->Frij[eT_DH22];
        // fr_buf+=(ei*dGholedpot[jj]+ej*dGholedpot[ii])*Frij;
        // fei_buf+=-dGholedpot[jj]*Eij;
        // fej_buf+=-dGholedpot[ii]*Eij;
        fr_buf+=(ei*dGdepot[jj]+ej*dGdepot[ii])*Frij;
        fei_buf+=-dGdepot[jj]*Eij;
        fej_buf+=-dGdepot[ii]*Eij;

        // if (bP[ii] && bP[jj]) { // TRY
          // Pij=(1/V1)*exp(-r*r/(2*gauss_01*gauss_01));
          // Frij=Pij/(gauss_01*gauss_01);
          // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_1,&Pij,&Frij);
          // Pij=data->Eij[eT_G1];
          // Frij=data->Frij[eT_G1];
          // Pij=bP[ii]*bP[jj]*data->Eij[eT_G1];
          Frij=bP[ii]*bP[jj]*data->Frij[eT_G1];
          // Pij=data->Eij[eT_G1];
          // Frij=data->Frij[eT_G1];
          // fr_buf+=(dGmixdt_tk[jj]*theta[ii]+dGmixdt_tk[ii]*theta[jj]+dGmixdt_tcl[jj]*theta_cl[ii]+dGmixdt_tcl[ii]*theta_cl[jj])*Frij;
          // fr_buf+=(dGholede_ek[jj]*theta[ii]+dGholede_ek[ii]*theta[jj]+dGholede_ecl[jj]*theta_cl[ii]+dGholede_ecl[ii]*theta_cl[jj])*Frij;
          // fr_buf+=(dGsoftdt_tk[jj]*theta[ii]+dGsoftdt_tcl[jj]*theta_cl[ii]+dGsoftdt_tk[ii]*theta[jj]+dGsoftdt_tcl[ii]*theta_cl[jj])*Frij;
          // ft_k[ii] +=-dGmixdt_tk[jj]*Pij;
          // ft_k[jj] +=-dGmixdt_tk[ii]*Pij;
          // ft_cl[ii]+=-dGmixdt_tcl[jj]*Pij;
          // ft_cl[jj]+=-dGmixdt_tcl[ii]*Pij;
          // ft_k[ii] +=-dGholede_ek[jj]*Pij;
          // ft_k[jj] +=-dGholede_ek[ii]*Pij;
          // ft_cl[ii]+=-dGholede_ecl[jj]*Pij;
          // ft_cl[jj]+=-dGholede_ecl[ii]*Pij;
          // ft_k[ii] +=-dGsoftdt_tk[jj]*Pij;
          // ft_k[jj] +=-dGsoftdt_tk[ii]*Pij;
          // ft_cl[ii]+=-dGsoftdt_tcl[jj]*Pij;
          // ft_cl[jj]+=-dGsoftdt_tcl[ii]*Pij;
          // fr_buf+=(dGmixdV1[jj]+dGmixdV1[ii])*Frij;
          // fr_buf+=(dGsoftdV1[jj]+dGsoftdV1[ii])*Frij;
          // fr_buf+=(dGpotdV1[jj]+dGpotdV1[ii])*Frij;
          // fr_buf+=(dGdtk[jj]*theta[ii]+dGdtk[ii]*theta[jj]+dGdtcl[jj]*theta_cl[ii]+dGdtcl[ii]*theta_cl[jj])*Frij;
          // ft_k[ii] +=-dGdtk[jj]*Pij;
          // ft_k[jj] +=-dGdtk[ii]*Pij;
          // ft_cl[ii]+=-dGdtcl[jj]*Pij;
          // ft_cl[jj]+=-dGdtcl[ii]*Pij;
          fr_buf+=(dGdV1[jj]+dGdV1[ii])*Frij;

          // Pij=(1/V2)*exp(-r*r/(2*gauss_02*gauss_02));
          // Frij=Pij/(gauss_02*gauss_02);
          // table_interp(r,itab,xtab,xtab2,xtab3,hinv,tab->G_2,&Pij,&Frij);
          // Pij=data->Eij[eT_G2];
          // Frij=data->Frij[eT_G2];
          // Pij=bP[ii]*bP[jj]*data->Eij[eT_G2];
          Frij=bP[ii]*bP[jj]*data->Frij[eT_G2];
          // Pij=data->Eij[eT_G2];
          // Frij=data->Frij[eT_G2];
          // fr_buf+=(dGholede_ek[jj]*eta[ii]+dGholede_ek[ii]*eta[jj]+dGholede_ecl[jj]*eta_cl[ii]+dGholede_ecl[ii]*eta_cl[jj])*Frij;
          // fe_k[ii] +=-dGholede_ek[jj]*Pij;
          // fe_k[jj] +=-dGholede_ek[ii]*Pij;
          // fe_cl[ii]+=-dGholede_ecl[jj]*Pij;
          // fe_cl[jj]+=-dGholede_ecl[ii]*Pij;
          // fr_buf+=(dGsoftde_ek[jj]*eta[ii]+dGsoftde_ecl[jj]*eta_cl[ii]+dGsoftde_ek[ii]*eta[jj]+dGsoftde_ecl[ii]*eta_cl[jj])*Frij;
          // fe_k[ii] +=-dGsoftde_ek[jj]*Pij;
          // fe_k[jj] +=-dGsoftde_ek[ii]*Pij;
          // fe_cl[ii]+=-dGsoftde_ecl[jj]*Pij;
          // fe_cl[jj]+=-dGsoftde_ecl[ii]*Pij;
          // fr_buf+=(dGmixdV2[jj]+dGmixdV2[ii])*Frij;
          // fr_buf+=(dGsoftdV2[jj]+dGsoftdV2[ii])*Frij;
          // fr_buf+=(dGpotdV2[jj]+dGpotdV2[ii])*Frij;
          // fr_buf+=(dGdek[jj]*eta[ii]+dGdek[ii]*eta[jj]+dGdecl[jj]*eta_cl[ii]+dGdecl[ii]*eta_cl[jj])*Frij;
          // fe_k[ii] +=-dGdek[jj]*Pij;
          // fe_k[jj] +=-dGdek[ii]*Pij;
          // fe_cl[ii]+=-dGdecl[jj]*Pij;
          // fe_cl[jj]+=-dGdecl[ii]*Pij;
          fr_buf+=(dGdV2[jj]+dGdV2[ii])*Frij;
        // }

        vec_scaleinc(fx+DIM3*iii, fr_buf*(kTr0/kT0),data->dr); // Convert units
        vec_scaleinc(fx+DIM3*jjj,-fr_buf*(kTr0/kT0),data->dr); // Convert units

        ft_k[jj] += ftj_buf;
        ft_cl[jj]+=-ftj_buf;
        fe_k[jj] += fej_buf;
        fe_cl[jj]+=-fej_buf;
      // }
    }
    ft_k[ii] += fti_buf;
    ft_cl[ii]+=-fti_buf;
    fe_k[ii] += fei_buf;
    fe_cl[ii]+=-fei_buf;
  }

  md->state->Gt->local[ID][0]+=Gt*(kTr0/kT0); // Convert units

  stop=gmx_cycles_read();
  md->state->nlelec->cycles_force[ID]+=(stop-start);
}


void getforce_other(struct_md* md)
{
  int ID,imin,imax;
  int i,j,ii,jj;
  double r2,sor2,r6,Eij;
  double Gt=0;
  vec dr;
  double *x=md->state->x;
  double *shift=md->state->shift;
  double *box=md->state->box;
  double *f;
  double *shiftij;

  double k12=md->parms->k12;
  double rc2;
  double (*s2)[2][2]=&(md->parms->s2);

  gmx_cycles_t start,stop;

  start=gmx_cycles_read();

  ID=omp_get_thread_num();
  imin=md->state->nlother->imin_f[ID];
  imax=md->state->nlother->imax_f[ID];
  f=md->state->atoms->f->local[ID];

  rc2=md->parms->rcother*md->parms->rcother;

  for (i=imin; i<imax; i++) {
    ii=md->state->nlother->ii[i];
    for (j=0; j<md->state->nlother->jjmax[i]; j++) {
      jj=md->state->nlother->jj[i][j];
      shiftij=md->state->nlother->shiftij[i][j];
      vec_subshift(x+DIM3*ii,x+DIM3*jj,shift+DIM3*ii,shift+DIM3*jj,shiftij,dr);
      // vec_subquick(x+DIM3*ii,x+DIM3*jj,box,dr);
      r2=vec_mag2(dr);
      if (r2<=rc2) {
      // KLUDGE
      sor2=(*s2)[ii < md->state->N_rna ? 0 : 1][jj < md->state->N_rna ? 0 : 1]/r2; // CONST
      r6=sor2*sor2*sor2;
      Eij=k12*r6*r6;
      Gt+=Eij;
      // assert(Eij>-1e6);
      vec_scaleinc(f+DIM3*ii, 12*Eij/r2,dr);
      vec_scaleinc(f+DIM3*jj,-12*Eij/r2,dr);
      }
    }
  }

  md->state->Gt->local[ID][0]+=Gt;
  
  stop=gmx_cycles_read();
  md->state->nlother->cycles_force[ID]+=(stop-start);
}


void getforce_bond(struct_md* md)
{
  int i,ii,jj,imin,imax;
  struct_bondparms *bondparms=md->parms->bondparms;
  double k0,r0;
  double r;
  vec dr;
  double Gt=0;
  double *x=md->state->x;
  double *f;
  int ID,NID;
  
  ID=omp_get_thread_num();
  NID=omp_get_max_threads();
  imin=(md->parms->N_bond * ID)/NID;
  imax=(md->parms->N_bond * (ID+1))/NID;
  f=md->state->atoms->f->local[ID];

  for (i=imin; i<imax; i++) {
    ii=bondparms[i].i;
    jj=bondparms[i].j;
    k0=bondparms[i].k0;
    r0=bondparms[i].r0;
    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,dr);
    r=vec_mag(dr);
    Gt+=0.5*k0*(r-r0)*(r-r0);
    // assert((k0*(r-r0)/r)>-1e6);
    vec_scaleinc(f+DIM3*ii,-k0*(r-r0)/r,dr);
    vec_scaleinc(f+DIM3*jj, k0*(r-r0)/r,dr);
  }

  md->state->Gt->local[ID][0]+=Gt;
}


void getforce_angle(struct_md* md)
{
  int i,j,ii,jj,kk,imin,imax;
  struct_angleparms *angleparms=md->parms->angleparms;
  double k0,t0;
  double rij,rkj;
  vec drij,drkj;
  double dt,cost,fsint,fsincost;
  vec fi,fj,fk;
  double Gt=0;
  double *x=md->state->x;
  double *f;
  int ID,NID;
  
  ID=omp_get_thread_num();
  NID=omp_get_max_threads();
  imin=(md->parms->N_angle * ID)/NID;
  imax=(md->parms->N_angle * (ID+1))/NID;
  f=md->state->atoms->f->local[ID];

  for (i=imin; i<imax; i++) {
    ii=angleparms[i].i;
    jj=angleparms[i].j;
    kk=angleparms[i].k;
    k0=angleparms[i].k0;
    t0=angleparms[i].t0;
    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,drij);
    rij=vec_mag(drij);
    vec_subquick(x+DIM3*kk,x+DIM3*jj,md->state->box,drkj);
    rkj=vec_mag(drkj);
    cost=vec_dot(drij,drkj)/(rij*rkj);
    dt=acos(cost)-t0;
    Gt+=0.5*k0*dt*dt;
    // if (cost<1) { // Avoid NaN
      fsint=k0*dt/sqrt(1-cost*cost); // Negatives cancel
      fsincost=fsint*cost;
      for (j=0; j<DIM3; j++) {
        fi[j]=drkj[j]*(fsint/(rij*rkj))-drij[j]*(fsincost/(rij*rij));
        fk[j]=drij[j]*(fsint/(rij*rkj))-drkj[j]*(fsincost/(rkj*rkj));
        fj[j]=-fi[j]-fk[j];
        // assert(fi[j]>-1e6);
        // assert(fk[j]>-1e6);
      }
      vec_inc(f+DIM3*ii,fi);
      vec_inc(f+DIM3*jj,fj);
      vec_inc(f+DIM3*kk,fk);
    // }
  }

  md->state->Gt->local[ID][0]+=Gt;
}


void getforce_dih(struct_md* md)
{
  int i,j,ii,jj,kk,ll,imin,imax;
  struct_dihparms *dihparms=md->parms->dihparms;
  double k0,p0,n;
  double rij,rjk,rkl;
  vec drij,drjk,drkl;
  vec mvec,nvec,uvec,vvec,svec;
  double phi,sign,ipr,dp,dGdp;
  double cosp,sinp;
  vec dsinp;
  // double mmag,nmag;
  double mmag2,nmag2;
  double a,b,p,q;
  vec fi,fj,fk,fl;
  double Gt=0;
  double *x=md->state->x;
  double *f;
  int ID,NID;
  
  ID=omp_get_thread_num();
  NID=omp_get_max_threads();
  imin=(md->parms->N_dih * ID)/NID;
  imax=(md->parms->N_dih * (ID+1))/NID;
  f=md->state->atoms->f->local[ID];

  for (i=imin; i<imax; i++) {
    ii=dihparms[i].i;
    jj=dihparms[i].j;
    kk=dihparms[i].k;
    ll=dihparms[i].l;
    k0=dihparms[i].k0;
    p0=dihparms[i].p0;
    n=dihparms[i].n;
/* GROMACS
// inside dih_angle
    *t1 = pbc_rvec_sub(pbc, xi, xj, r_ij);
    *t2 = pbc_rvec_sub(pbc, xk, xj, r_kj);
    *t3 = pbc_rvec_sub(pbc, xk, xl, r_kl);

    cprod(r_ij, r_kj, m);
    cprod(r_kj, r_kl, n);
    phi     = gmx_angle(m, n);
    ipr     = iprod(r_ij, n);
    (*sign) = (ipr < 0.0) ? -1.0 : 1.0;
    phi     = (*sign)*phi;

// inside dih_do_fup
    iprm  = iprod(m, m);
    iprn  = iprod(n, n);
    nrkj2 = iprod(r_kj, r_kj);
    toler = nrkj2*GMX_REAL_EPS;
    if ((iprm > toler) && (iprn > toler))
    {
        nrkj_1 = gmx_invsqrt(nrkj2);
        nrkj_2 = nrkj_1*nrkj_1;
        nrkj   = nrkj2*nrkj_1;
        a      = -ddphi*nrkj/iprm;
        svmul(a, m, f_i);
        b     = ddphi*nrkj/iprn;
        svmul(b, n, f_l);
        p     = iprod(r_ij, r_kj);
        p    *= nrkj_2;
        q     = iprod(r_kl, r_kj);
        q    *= nrkj_2;
        svmul(p, f_i, uvec);
        svmul(q, f_l, vvec);
        rvec_sub(uvec, vvec, svec);
        rvec_sub(f_i, svec, f_j);
        rvec_add(f_l, svec, f_k);
        rvec_inc(f[i], f_i);
        rvec_dec(f[j], f_j);
        rvec_dec(f[k], f_k);
        rvec_inc(f[l], f_l);
    }
*/

    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,drij);
    vec_subquick(x+DIM3*jj,x+DIM3*kk,md->state->box,drjk);
    vec_subquick(x+DIM3*kk,x+DIM3*ll,md->state->box,drkl);
    vec_cross(drij,drjk,mvec);
    vec_cross(drjk,drkl,nvec);
    // mmag=vec_mag(mvec);
    // nmag=vec_mag(nvec);
    // phi=acos(vec_dot(mvec,nvec)/(mmag*nmag)); // Need sign still
    // Use gmx_angle style instead, acos is unstable
    vec_cross(mvec,nvec,dsinp);
    sinp=vec_mag(dsinp);
    cosp=vec_dot(mvec,nvec);
    phi=atan2(sinp,cosp);
    ipr=vec_dot(drij,nvec);
    sign=(ipr > 0.0) ? -1.0 : 1.0; // Opposite of gromacs because m and n are opposite
    phi=sign*phi;

    if (n==0) {
      dp=phi-p0;
      dp-=(2*M_PI)*floor((dp+M_PI)/(2*M_PI));
      // if (i==36) {
      //  fprintf(stderr,"%5d %5d %5d %5d %g %g\n",ii,jj,kk,ll,phi,dp);
      // }
      Gt+=0.5*k0*dp*dp;
      // assert(0.5*k0*dp*dp>-1e6);
      dGdp=k0*dp;
    } else {
      dp=n*phi-p0;
      Gt+=k0*cos(dp);
      dGdp=-k0*n*sin(dp);
      // assert(k0*cos(dp)>-1e6);
    }

    mmag2=vec_mag2(mvec);
    nmag2=vec_mag2(nvec);
    rjk=vec_mag(drjk);
    // a=-dGdp*rjk/(mmag*mmag);
    // a=dGdp*rjk/(mmag*mmag);
    a=dGdp*rjk/mmag2;
    vec_scale(fi,a,mvec);
    // b=dGdp*rjk/(nmag*nmag);
    // b=-dGdp*rjk/(nmag*nmag);
    b=-dGdp*rjk/nmag2;
    vec_scale(fl,b,nvec);
    p=-vec_dot(drij,drjk)/(rjk*rjk);
    q=-vec_dot(drkl,drjk)/(rjk*rjk);
    vec_scale(uvec,p,fi);
    vec_scale(vvec,q,fl);
    vec_subtract(uvec,vvec,svec);
    vec_subtract(fi,svec,fj);
    vec_add(fl,svec,fk);

    vec_inc(f+DIM3*ii,fi);
    vec_scaleinc(f+DIM3*jj,-1,fj);
    vec_scaleinc(f+DIM3*kk,-1,fk);
    vec_inc(f+DIM3*ll,fl);
  }

  md->state->Gt->local[ID][0]+=Gt;
}


void getforce_pair(struct_md* md)
{
  int i,ii,jj,imin,imax;
  struct_pairparms *pairparms=md->parms->pairparms;
  double C6,C12;
  double r2,r6,r12;
  vec dr;
  double Gt=0;
  double *x=md->state->x;
  double *f;
  int ID,NID;
  
  ID=omp_get_thread_num();
  NID=omp_get_max_threads();
  imin=(md->parms->N_pair * ID)/NID;
  imax=(md->parms->N_pair * (ID+1))/NID;
  f=md->state->atoms->f->local[ID];

  for (i=imin; i<imax; i++) {
    ii=pairparms[i].i;
    jj=pairparms[i].j;
    C6=pairparms[i].C6;
    C12=pairparms[i].C12;
    vec_subquick(x+DIM3*ii,x+DIM3*jj,md->state->box,dr);
    r2=vec_mag2(dr);
    r6=r2*r2*r2;
    r12=r6*r6;
    Gt+=C12/r12-C6/r6;
    // assert(((12*(C12/r12)/r2-6*(C6/r6)/r2))>-1e6);
    vec_scaleinc(f+DIM3*ii, (12*(C12/r12)/r2-6*(C6/r6)/r2),dr);
    vec_scaleinc(f+DIM3*jj,-(12*(C12/r12)/r2-6*(C6/r6)/r2),dr);
  }

  md->state->Gt->local[ID][0]+=Gt;
}


void getkineticcontribution(struct_atoms *atoms,struct_collate *Kt,double unit)
{
  int i,imin,imax;
  int ID,NID;
  int Ni,Nf;
  double *m;
  double *v;
  double *KtL;

  ID=omp_get_thread_num();
  NID=omp_get_max_threads();

  m=atoms->m;
  v=atoms->v;
  Ni=atoms->Ni;
  Nf=atoms->Nf;
  imin=Ni+((Nf-Ni) * ID)/NID;
  imax=Ni+((Nf-Ni) * (ID+1))/NID;

  KtL=Kt->local[ID];
  for (i=imin; i<imax; i++) {
    KtL[0]+=0.5*unit*m[i]*v[i]*v[i];
  }
  
}


void getkinetic(struct_md *md)
{
  double unit=md->parms->kTr0/md->parms->kT0;

  getkineticcontribution(md->state->atoms,md->state->Kt,1.0);
  getkineticcontribution(md->state->manningcc_tk,md->state->Kt,unit);
  getkineticcontribution(md->state->manningcc_tcl,md->state->Kt,unit);
  getkineticcontribution(md->state->manningcc_ek,md->state->Kt,unit);
  getkineticcontribution(md->state->manningcc_ecl,md->state->Kt,unit);
}


void sumforce(struct_md* md)
{
  int ID;

  ID=omp_get_thread_num();

  sumlocal_collate(md->state->atoms->f,ID);

  sumlocal_collate(md->state->manningcc_tk->f,ID);
  sumlocal_collate(md->state->manningcc_tcl->f,ID);
  sumlocal_collate(md->state->manningcc_ek->f,ID);
  sumlocal_collate(md->state->manningcc_ecl->f,ID);

  sumlocal_collate(md->state->Gt,ID);
  sumlocal_collate(md->state->Kt,ID);
}


void getforce(struct_md* md)
{
  #pragma omp master
    md->times->start=gmx_cycles_read();
  #pragma omp sections
  {
    #pragma omp section
      loadbalance_f(md->state->nlelec);
    #pragma omp section
      loadbalance_f(md->state->nlother);
  }
  // There is an implied barrier at the end of a SECTIONS directive, unless the NOWAIT/nowait clause is used
  resetforce(md);
  getforce_elec(md);
  // getforce_elec_v2(md);
  getforce_other(md);

  if (md->parms->flexible) {
    getforce_bond(md);
    getforce_angle(md);
    getforce_dih(md);
    getforce_pair(md);
  }
  getkinetic(md);
  #pragma omp barrier
  sumforce(md);
  #pragma omp master
    md->times->force+=(gmx_cycles_read()-md->times->start);
  #pragma omp barrier
}


void leapfrog(struct_md* md,struct_atoms* atoms,struct_leapparms* leapparms)
{
  int i,imin,imax;
  int ID,NID;
  double nu[2];
  double Vs, Vr, Xr, Xs;
  double *x=atoms->x;
  double *v=atoms->v;
  double *f=atoms->f->master;
  double *m=atoms->m;
  double *msqrt=atoms->msqrt;
  double *Vs_delay=atoms->Vs_delay;

  double SigmaVsVs=leapparms->SigmaVsVs;
  double XsVsCoeff=leapparms->XsVsCoeff;
  double CondSigmaXsXs=leapparms->CondSigmaXsXs;
  double SigmaVrVr=leapparms->SigmaVrVr;
  double XrVrCoeff=leapparms->XrVrCoeff;
  double CondSigmaXrXr=leapparms->CondSigmaXrXr;
  double v_vscale=leapparms->v_vscale;
  double v_ascale=leapparms->v_ascale;
  double v_Vsscale=leapparms->v_Vsscale;
  double x_vscale=leapparms->x_vscale;
  double x_Xrscale=leapparms->x_Xrscale;

  ID=omp_get_thread_num();
  NID=omp_get_num_threads();

  imin=atoms->Ni+((atoms->Nf-atoms->Ni)*ID)/NID;
  imax=atoms->Ni+((atoms->Nf-atoms->Ni)*(ID+1))/NID;

  for (i=imin; i<imax; i++) {
    /*if (isnan(f[i])) {
      arrested_development();
    }*/

    // Compute noise
    rand_normal(nu,md->state->mtstate[ID]);
    // Vs=SigmaVsVs*nu(:,:,1);
    Vs=Vs_delay[i];
    Vs_delay[i]=SigmaVsVs*nu[0]/msqrt[i];
    // Xs=CondSigmaXsXs*nu(:,:,2)+XsVsCoeff*[Vs(2:end,:);zeros([1,N])];
    // Correlate Xs with Velocity noise Vs from next leapfrog step
    Xs=CondSigmaXsXs*nu[1]/msqrt[i]+XsVsCoeff*Vs_delay[i];
    rand_normal(nu,md->state->mtstate[ID]);
    // Vr=SigmaVrVr*nu(:,:,3);
    Vr=SigmaVrVr*nu[0]/msqrt[i];
    // Xr=CondSigmaXrXr*nu(:,:,4)+XrVrCoeff*Vr;
    Xr=CondSigmaXrXr*nu[1]/msqrt[i]+XrVrCoeff*Vr;
  
    // Update v from t-0.5*dt to t+0.5*dt
    v[i]=v_vscale*v[i]+v_ascale*f[i]/m[i]+v_Vsscale*Vs+Vr;
    // Update x from t to t+dt
    x[i]=x[i]+x_vscale*v[i]+x_Xrscale*Xr+Xs;
  }
}


void boundaryconditions(struct_md* md)
{
  int i,j;
  int N,imin,imax;
  int ID,NID;
  double x;
  double shiftbuf;
  double *box=md->state->box;
  struct_atoms *atoms;

  ID=omp_get_thread_num();
  NID=omp_get_num_threads();

  atoms=md->state->atoms;
  N=atoms->N;

  imin=atoms->Ni+((atoms->Nf-atoms->Ni)*ID)/NID;
  imax=atoms->Ni+((atoms->Nf-atoms->Ni)*(ID+1))/NID;
  for (i=imin; i<imax; i++) {
    j=i%DIM3;
    x=atoms->x[i];
    shiftbuf=-box[j]*floor(x/box[j]);
    atoms->shift[i]-=shiftbuf;
    atoms->x[i]+=shiftbuf;
  }
}


void incstep(struct_md* md)
{
  #pragma omp barrier
  #pragma omp master
  md->state->step++;
  #pragma omp barrier
}


void update_anneal(struct_md* md,struct_leapparms* leapparms)
{
  #pragma omp master
  md->times->start=gmx_cycles_read();

  leapfrog(md,md->state->manningcc_tk,leapparms);
  leapfrog(md,md->state->manningcc_tcl,leapparms);
  leapfrog(md,md->state->manningcc_ek,leapparms);
  leapfrog(md,md->state->manningcc_ecl,leapparms);
  #pragma omp master
    md->times->update+=(gmx_cycles_read()-md->times->start);
  incstep(md); // barrier wrapped
}


void update(struct_md* md)
{
  #pragma omp master
  md->times->start=gmx_cycles_read();

  leapfrog(md,md->state->atoms,md->parms->leapparms);

  leapfrog(md,md->state->manningcc_tk,md->parms->leapparms_mcc);
  leapfrog(md,md->state->manningcc_tcl,md->parms->leapparms_mcc);
  leapfrog(md,md->state->manningcc_ek,md->parms->leapparms_mcc);
  leapfrog(md,md->state->manningcc_ecl,md->parms->leapparms_mcc);

  boundaryconditions(md);
  #pragma omp master
    md->times->update+=(gmx_cycles_read()-md->times->start);
  incstep(md); // barrier wrapped
}


void resetstep(struct_md* md)
{
  #pragma omp barrier
  #pragma omp master
    md->state->step=0;
  #pragma omp barrier
}


void eqtheta(struct_md* md,int lim,struct_leapparms* leapparms)
{
  resetstep(md);
  while (md->state->step < lim) {
    getforce(md);
    // if (md->state->step % md->parms->t_output == 0)
    //   printoutput(md);
    update_anneal(md,leapparms);
  }
}


void resetcumcycles(struct_md* md)
{
  int ID;
  ID=omp_get_thread_num();
  md->state->nlelec->cycles_sort[ID]=0;
  md->state->nlelec->cycles_check[ID]=0;
  md->state->nlelec->cycles_force[ID]=0;
  md->state->nlother->cycles_sort[ID]=0;
  md->state->nlother->cycles_check[ID]=0;
  md->state->nlother->cycles_force[ID]=0;
  md->state->nlelec->cumcycles_sort[ID]=0;
  md->state->nlelec->cumcycles_check[ID]=0;
  md->state->nlelec->cumcycles_force[ID]=0;
  md->state->nlother->cumcycles_sort[ID]=0;
  md->state->nlother->cumcycles_check[ID]=0;
  md->state->nlother->cumcycles_force[ID]=0;
#pragma omp barrier
}


// Main function
int main(int argc, char *argv[])
{
  struct_md *md;
  gmx_cycles_t start,stop;

  #ifdef MPI
  MPI_Init(&argc,&argv);
  #ifdef DEBUG
  arrested_development();
  #endif
  #endif

  md=alloc_md(argc,argv);
  printheader(md);
  start=gmx_cycles_read();

  #pragma omp parallel
  {
    neighborsearch(md);
    eqtheta(md,md->parms->anneal1lim,md->parms->leapparms_anneal1);
    eqtheta(md,md->parms->anneal2lim,md->parms->leapparms_anneal2);
    resetstep(md); // md->state->step=0;
    resetcumcycles(md);
    // #pragma omp master
    // {
    // set_velocities(md->state->manningcc_tk,md->state->mtstate,md->parms->kTr);
    // set_velocities(md->state->manningcc_tcl,md->state->mtstate,md->parms->kTr);
    // set_velocities(md->state->manningcc_ek,md->state->mtstate,md->parms->kTr);
    // set_velocities(md->state->manningcc_ecl,md->state->mtstate,md->parms->kTr);
    // }
    while (md->state->step < md->parms->steplim) {
      if (md->state->step % md->parms->t_ns == 0)
        neighborsearch(md);
      getforce(md);
      if (md->state->step % md->parms->t_output == 0)
        printoutput(md);
      update(md);
    }
  }

  printsummary(md,start);
  free_md(md);

  #ifdef MPI
  MPI_Finalize();
  #endif

  return 0;
}
