#! /bin/bash -l

module load intel/2013.1.039
module load openmpi/1.6.5-intel

# mpicc -DDEBUG -lm -fopenmp -g md_rnaions.c -o md_rnaions.cex
mpicc -lm -fopenmp -O3 md_rnaions.c -o md_rnaions.cex
