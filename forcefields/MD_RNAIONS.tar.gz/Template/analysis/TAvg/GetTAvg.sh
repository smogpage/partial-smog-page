#! /bin/bash

QRNA=100
DIR=../../outfiles

for i in `awk 'BEGIN {for (i=0;i<8;i++) {print i}}'`
do

for SP in theta theta_cl eta eta_cl
do

awk 'BEGIN {
  for (i=1; i<='$QRNA'; i++) {
    MEAN[i]=0;
  }
  COUNT=0;
} {
  for (i=1; i<='$QRNA'; i++) {
    MEAN[i]+=$i;
  }
  COUNT+=1;
} END {
  for (i=1; i<='$QRNA'; i++) {
    printf "%g ",MEAN[i]/COUNT;
  }
}' $DIR/$SP.$i.dat > ${SP}_t.$i.dat

done
done
