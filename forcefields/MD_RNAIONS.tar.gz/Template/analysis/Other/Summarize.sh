#! /bin/bash
# Summarize the averages from GetAvg.sh

for i in `awk 'BEGIN {for (i=0;i<5;i++) {print i}}'`
do

TK=`awk 'BEGIN {C=0; S=0} {C++; S+=$1} END {print S/C}' theta_t.$i.dat`
TCL=`awk 'BEGIN {C=0; S=0} {C++; S+=$1} END {print S/C}' theta_cl_t.$i.dat`
EK=`awk 'BEGIN {C=0; S=0} {C++; S+=$1} END {print S/C}' eta_t.$i.dat`
ECL=`awk 'BEGIN {C=0; S=0} {C++; S+=$1} END {print S/C}' eta_cl_t.$i.dat`
awk 'BEGIN {print ('$TK'+'$EK')-('$TCL'+'$ECL')}'

done
