TH=load('theta.0.dat');
TH_CL=load('theta_cl.0.dat');
for i=1:size(TH,1)
    plot(1:100,TH(i,:)-TH_CL(i,:),'k',1:100,TH(i,:),'b',1:100,TH_CL(i,:),'r')
    pause(0.5)
end