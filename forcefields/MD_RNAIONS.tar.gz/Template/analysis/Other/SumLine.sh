#! /bin/bash

LINE=$1
FILE=$2

awk '{if (NR=='$LINE') {
  SUM=0;
  for (i=1; i<=NF; i++) {
    SUM=SUM+$i;
  }
  print SUM
}}' $FILE
