t=[0:0.1:0.4,0.5:1:5099.5];

tk=load('../outfiles/theta.0.dat');
tcl=load('../outfiles/theta_cl.0.dat');
ek=load('../outfiles/eta.0.dat');
ecl=load('../outfiles/eta_cl.0.dat');

pot_t=load('../outfiles/pot_t.0.dat');
dens_tk=load('../outfiles/dens_tk.0.dat');

pot_e=load('../outfiles/pot_e.0.dat');
dens_ek=load('../outfiles/dens_ek.0.dat');

dV=load('../outfiles/dV.0.dat');

% Plot to check for glassiness
figure(1)
plot(pot_t(300:end,:),dens_tk(300:end,:))
hold on
plot(pot_t((end-1):end,:),dens_tk((end-1):end,:),'.')
hold off
xlabel('Potential')
ylabel('K+ Density')
xlabel('Potential [kV/mol]')
ylabel('K+ Density [1/nm^3]')

% Plot to see how quickly individual ion counts are dispersing
figure(2)
plot(t,var(tk,1,2),'k',t,var(ek,1,2),':k',t,var(tcl,1,2),'r',t,var(ecl,1,2),':r')
xlabel('Time [ps]')
ylabel('Variance')
legend('tk','ek','tcl','ecl','location','best')

% Look to see how trapped individual ion counts are
figure(3)
plot(t,tk,t,tk(:,2),'.')

% Plot to check for glassiness
figure(4)
plot(pot_t(300:end,:),dV(300:end,:).*dens_tk(300:end,:))
hold on
plot(pot_t((end-1):end,:),dV((end-1):end,:).*dens_tk((end-1):end,:),'.')
hold off
xlabel('Potential')
ylabel('K+ Number')
xlabel('Potential [kV/mol]')
ylabel('K+ Density [1/nm^3]')

figure(5)
b=0.167;
N=size(tk,2);
x=b*(1:N);
s=size(tk,1);
plot(x,tk(s,:),'k',x,tcl(s,:),'r',x,ek(s,:),':k',x,ecl(s,:),':r',...
    x,pot_t(end,:),'b-',x,pot_e(end,:),'b:')

figure(6)
Gt=load('../outfiles/Gt.0.dat');
plot(Gt)