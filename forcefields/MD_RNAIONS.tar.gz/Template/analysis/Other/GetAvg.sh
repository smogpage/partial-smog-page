#! /bin/bash

QRNA=70

for i in `awk 'BEGIN {for (i=0;i<5;i++) {print i}}'`
do

awk 'BEGIN {
  AVG=0;
} {
  MEAN=0;
  for (i=0; i<'$QRNA'; i++) {
    MEAN=MEAN+$i
  }
  print MEAN
}' ../outfiles/theta.$i.dat > theta_t.$i.dat

awk 'BEGIN {
  AVG=0;
} {
  MEAN=0;
  for (i=0; i<'$QRNA'; i++) {
    MEAN=MEAN+$i
  }
  print MEAN
}' ../outfiles/theta_cl.$i.dat > theta_cl_t.$i.dat

awk 'BEGIN {
  AVG=0;
} {
  MEAN=0;
  for (i=0; i<'$QRNA'; i++) {
    MEAN=MEAN+$i
  }
  print MEAN
}' ../outfiles/eta.$i.dat > eta_t.$i.dat

awk 'BEGIN {
  AVG=0;
} {
  MEAN=0;
  for (i=0; i<'$QRNA'; i++) {
    MEAN=MEAN+$i
  }
  print MEAN
}' ../outfiles/eta_cl.$i.dat > eta_cl_t.$i.dat

# awk 'BEGIN {
#   AVG=0;
# } {
#   MEAN=0;
#   for (i=0; i<'$QRNA'; i++) {
#     MEAN=MEAN+$i
#   }
#   print MEAN
# }' ../outfiles/mtheta.$i.dat > mtheta_t.$i.dat

done
