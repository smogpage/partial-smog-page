#! /bin/bash -l

module load intel/2013.1.039
module load openmpi/1.6.5-intel

# GDIR=/Users/ryanduck/Programs/gromacs-5.0/float/bin
GDIR=/home/rlh6/Programs/gromacs-4.6.5/float/bin

RNA=1499
MG=250

for i in `awk 'BEGIN {for (i=0;i<16;i++) {print i}}'`
do

TRJ=../outfiles/traj.$i.gro
NDX=ndx.ndx

# awk 'BEGIN {
#   print "[ RNA ]"
#   for (i=0; i<'$RNA'; i++) {
#     print i
#   }
#   for (j=0; j<'$MG'; j++) {
#     print "[ MG" j " ]"
#     print i+j
#   }}' > $NDX
# 
# awk 'BEGIN {
#   for (i=0; i<('$MG'+1); i++) {
#     print i
#   }}' > input
# 
# # cat input | $GDIR/g_mindist -f $TRJ -n ndx.ndx -ng $MG
# cat input | $GDIR/g_mindist -f $TRJ -n ndx.ndx -ng $MG -on mcmg.xvg -d 1.0 -xvg none -group

awk 'BEGIN {
  print "[ RNA ]"
  for (i=0; i<'$RNA'; i++) {
    print i+1
  }
    print "[ MG ]"
  for (j=0; j<'$MG'; j++) {
    print i+j+1
  }}' > $NDX

awk 'BEGIN {
  print 0
  print 1
  }' > input

cat input | $GDIR/g_mindist -f $TRJ -n ndx.ndx -ng 1 -on mcmg.$i.xvg -d 1.0 -xvg none -group
# rm mindist.xvg
rm \#*

done
