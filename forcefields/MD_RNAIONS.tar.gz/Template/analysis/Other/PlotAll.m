is={'0','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15'};

for ii=1:8
    mg{ii}=load(['mcmg.',is{ii},'.xvg']);
    k{ii}=load(['theta_t.',is{ii},'.dat']);
    mk{ii}=load(['mtheta_t.',is{ii},'.dat']);
    figure(ii)
    % plot(mg{ii}(:,1),mg{ii}(:,2),'g',mg{ii}(:,1),k{ii},'k')
    % plot(mg{ii}(:,1),mg{ii}(:,2),'g')
    plot(1:length(k{ii}),k{ii},'g',1:length(mk{ii}),mk{ii},'k')
    t(ii,1)=mean(k{ii}(end/2:end));
    % t(ii,2)=mean(mg{ii}(end/2:end,2));
    t(ii,2)=mean(mk{ii}(end/2:end));
end
% figure(16)
% plot(t(7:15,1),t(7:15,2),'.',t(1:6,1),t(1:6,2),'o')
