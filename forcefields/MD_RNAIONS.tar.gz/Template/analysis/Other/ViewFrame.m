tk=load('../outfiles/theta.0.dat');
tcl=load('../outfiles/theta_cl.0.dat');
ek=load('../outfiles/eta.0.dat');
ecl=load('../outfiles/eta_cl.0.dat');
N=size(tk,2);

s=1;
while (s>0 & s<size(tk,1))
    plot(1:N,tk(s,:),'k',1:N,tcl(s,:),'r',1:N,ek(s,:),':k',1:N,ecl(s,:),':r')
    ylim([-1 1.5])
    s=input('Which frame?');
end