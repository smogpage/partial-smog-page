#! /bin/bash -l
# Written by Ryan Hayes 2015-01-12 to do WHAM on Q.

module load intel/2013.1.039
module load openmpi/1.6.5-intel

QUEUE=commons

export GROMDIR="/home/rlh6/Programs/gromacs-4.5.4.SBM/float/bin"
export MPI=`which mpiexec`

SYS=PK
# Ts="105 110 115 120 125 130 135 140 145"
Ts="0 1" # 90 120
PDIR=`pwd`
SDIR=../../outfiles

GRO=../../system/PK/PK.gro
TOP=../../system/PK/PK.top
MDP=$PDIR/vsbm105.mdp
TPR=$PDIR/PK.tpr
$GROMDIR/grompp -c $GRO -p $TOP -f $MDP -o $TPR -maxwarn 1

CONTACTS=$PDIR/PK.contacts.ndx

for T in $Ts
do

XTC=$SDIR/traj.$T.gro
QOUT=$PDIR/Q.$T.out
# EXVG=$SDIR/E.xvg
# EOUT=$SDIR/E.out
# WIN=$SDIR/WHAM.in

$GROMDIR/g_kuh -s $GRO -f $XTC -n $CONTACTS -o $QOUT -cut 1.5 -noabscut
# echo -e "Potential\n\n" | $GROMDIR/g_energy -f $EDR -s $TPR -o $EXVG -xvg none
# awk '{if (FILENAME=="'$EXVG'") {E[NR]=$2; NR0=NR} else {print E[NR-NR0],$1}}' $EXVG $QOUT > $WIN

rm $SDIR/\#*

done

