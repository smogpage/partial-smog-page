#! /bin/bash -l
# Written by Ryan Hayes on 2010-10-01 to submit scripts for all the different files
# Adapted by Ryan Hayes on 2011-04-13 to run on conejo

module load intel/2013.1.039
module load openmpi/1.6.5-intel

JOBNAME=debuggage
# QUEUE=commons
QUEUE=interactive
NODES=2
PPN=8
# WALLTIME=86400
WALLTIME=1800

WORKDIR=`pwd`
WALLTIME_M=`awk 'BEGIN {print '$WALLTIME'/60}'`

export PROCS=`awk 'BEGIN {print '$NODES'*'$PPN'}'`

# SCRIPT=script_md_rnaions.sh
# QSUBOPTIONS="--job-name=$JOBNAME --partition=$QUEUE --nodes=$NODES --ntasks-per-node=$PPN --time=$WALLTIME_M --workdir=$WORKDIR --export=ALL"
# JOBID=`sbatch $QSUBOPTIONS $SCRIPT`
# JOBID=`echo $JOBID | awk '{print $4}'`

# SCRIPT="/bin/bash -i"
# QSUBOPTIONS="--job-name=$JOBNAME --partition=$QUEUE --nodes=$NODES --ntasks-per-node=$PPN --time=$WALLTIME_M --export=ALL"
# srun -pty $QSUBOPTIONS $SCRIPT

QSUBOPTIONS="--job-name=$JOBNAME --partition=$QUEUE --nodes=$NODES --ntasks-per-node=$PPN --time=$WALLTIME_M"
salloc $QSUBOPTIONS
