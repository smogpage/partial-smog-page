#! /bin/bash -l

HOST=`hostname | awk -F. '{print $1}'`
HOSTPIDFILE=pid.$HOST.dat

PIDs=(`awk '{print $2}' $HOSTPIDFILE`)
RANKs=(`awk '{print $4}' $HOSTPIDFILE`)

for i in `awk 'BEGIN {for (i=0;i<'${#PIDs[@]}';i++) {print i}}'`
do
  RANK=${RANKs[$i]}
  screen -S "P$RANK" -p 0 -X stuff "$1
"
done
